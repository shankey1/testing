package com.booking.util;

/**
 * Utility class for string operations
 * Provides common string manipulation methods used across tests
 * 
 * Best Practice: Keep utility classes in util package
 */
public class StringUtils {

    /**
     * Normalizes string - converts empty strings to null
     * Useful for handling empty values from feature files
     *
     * @param value the string to normalize
     * @return null if empty or whitespace, otherwise the trimmed value
     */
    public static String normalizeString(String value) {
        if (value == null || value.trim().isEmpty()) {
            return null;
        }
        return value.trim();
    }
}

