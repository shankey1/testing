# BDD Feature File Best Practices: Scenario Outline Organization

## When to Use ONE Scenario Outline vs MULTIPLE Scenario Outlines

### ✅ Use ONE Scenario Outline When:

1. **Same Step Pattern & Same Test Type**
   - All scenarios follow the exact same step definition pattern
   - All scenarios test the same type of validation/behavior
   - Examples: All field validation errors, all boundary values

2. **Related Test Cases**
   - Test cases are logically related and test the same aspect
   - Examples: All email validation tests, all date validation tests

3. **Small to Medium Examples Table (< 20 rows)**
   - Easy to read and maintain in a single table
   - Clear column headers make it understandable

4. **Same Expected Behavior**
   - All scenarios expect the same response (same status code, same validation)
   - Examples: All 400 errors, all 200 success responses

### ✅ Use MULTIPLE Scenario Outlines When:

1. **Different Step Patterns**
   - Scenarios require different step definitions
   - Examples: 
     - "I create a booking with <field> <value>" (simple field validation)
     - "I create a booking with checkin <date> and checkout <date>" (date validation)
     - "I create a booking without <field>" (missing field validation)

2. **Different Test Types**
   - Positive vs Negative scenarios
   - Different business logic flows
   - Examples: Success scenarios vs Error scenarios

3. **Large Examples Table (> 30 rows)**
   - Becomes hard to read and maintain
   - Better to split by logical groups

4. **Different Expected Behaviors**
   - Different status codes
   - Different response validations
   - Examples: 200 success vs 400 validation errors vs 401 unauthorized

5. **Different Test Categories**
   - Group by business domain
   - Group by feature area
   - Examples: Field validation vs Business rule validation

## Recommended Approach for Your Booking Feature

### Option 1: Current Approach (Single Outline) - ✅ Good for Small Projects
**Pros:**
- All negative tests in one place
- Easy to see all test cases at once
- Single step definition handles everything

**Cons:**
- Large Examples table (28 rows) - harder to scan
- Mixed test types (invalid, missing, empty, dates) - less clear
- Requires complex step definition with switch/case logic
- Harder to understand test intent at a glance

### Option 2: Grouped by Test Type (Recommended) - ✅ Best Practice
**Structure:**
```
@negative
Scenario Outline: Create booking with invalid field values
  When I create a booking with <field> "<value>"
  Then the response status code should be 400
  And the response should contain validation error "<expected_error>"
  Examples: [invalid firstname, lastname, phone, email]

@negative
Scenario Outline: Create booking with missing required fields
  When I create a booking without <field>
  Then the response status code should be 400
  And the response should contain validation error "<expected_error>"
  Examples: [all required fields]

@negative
Scenario Outline: Create booking with empty required fields
  When I create a booking with empty <field>
  Then the response status code should be 400
  And the response should contain validation error "<expected_error>"
  Examples: [firstname, lastname, email, phone]

@negative
Scenario Outline: Create booking with invalid dates
  When I create a booking with checkin "<checkin>" and checkout "<checkout>"
  Then the response status code should be 400
  And the response should contain validation error "<expected_error>"
  Examples: [all date scenarios]

@negative
Scenario: Create booking with invalid roomid
  When I create a booking with roomid 0
  Then the response status code should be 400
  And the response should contain validation error "must not be null"
```

**Pros:**
- ✅ Clear separation of concerns
- ✅ Easy to understand test intent
- ✅ Simple step definitions (no complex logic)
- ✅ Easy to add new test cases to relevant group
- ✅ Better readability - smaller, focused tables
- ✅ Easier for non-technical stakeholders to understand
- ✅ Better test reporting - can see which category failed

**Cons:**
- More Scenario Outlines to maintain
- Slightly more code (but simpler step definitions)

### Option 3: Hybrid Approach - ✅ Best for Large Projects
**Structure:**
- Group by business domain/feature area
- Use Scenario Outline for data-driven tests
- Use regular Scenario for unique test cases

```
@positive
Scenario Outline: Create booking with valid boundary values
  ...

@negative
Scenario Outline: Field validation errors
  ...

@negative
Scenario Outline: Required field validation
  ...

@negative
Scenario Outline: Date validation
  ...

@negative
Scenario: Create booking with invalid roomid (zero)
  ...

@negative
Scenario: Create booking with invalid roomid (negative)
  ...
```

## Industry Best Practices Summary

### 1. **Readability First**
   - Feature files should be readable by business stakeholders
   - Clear, descriptive scenario names
   - Logical grouping of related tests

### 2. **Maintainability**
   - Easy to add new test cases
   - Easy to find and update existing tests
   - Clear structure that scales

### 3. **Test Organization**
   - Group by business logic, not technical implementation
   - Separate positive and negative scenarios
   - Use tags (@positive, @negative) for filtering

### 4. **Step Definition Simplicity**
   - Keep step definitions simple and focused
   - Avoid complex switch/case logic when possible
   - One step definition = one clear purpose

### 5. **Examples Table Size**
   - Keep Examples tables manageable (< 20-25 rows)
   - If larger, consider splitting by logical groups
   - Use descriptive column names

### 6. **Balance**
   - Don't over-consolidate (hard to read)
   - Don't over-separate (too many files/scenarios)
   - Find the sweet spot for your project size

## Recommendation for Your Project

**For your booking feature, I recommend Option 2 (Grouped by Test Type):**

1. **Separate Scenario Outlines for:**
   - Invalid field values (firstname, lastname, phone, email)
   - Missing required fields
   - Empty required fields
   - Invalid dates
   - Invalid roomid (can be 2 separate scenarios or 1 outline)

2. **Benefits:**
   - Better readability
   - Simpler step definitions
   - Easier maintenance
   - Clear test organization
   - Better test reports

3. **When to Consolidate:**
   - If you have < 10 test cases total
   - If all tests follow exact same pattern
   - If tests are tightly related

4. **When to Split:**
   - If Examples table > 25 rows
   - If different step patterns needed
   - If different test categories
   - If readability suffers

## Example: Ideal Structure

```gherkin
Feature: Booking API

  Background:
    Given the booking API is available

  @positive
  Scenario: Create booking with valid data
    ...

  @positive
  Scenario Outline: Create booking with boundary values
    ...

  @negative
  Scenario Outline: Create booking with invalid field values
    When I create a booking with <field> "<value>"
    Then the response status code should be 400
    And the response should contain validation error "<expected_error>"
    Examples:
      | field     | value                                          | expected_error                        |
      | firstname | Jo                                             | size must be between 3 and 18        |
      | firstname | ThisIsAVeryLongFirstNameThatExceedsLimit      | size must be between 3 and 18        |
      | lastname  | Do                                             | size must be between 3 and 18        |
      | email     | invalidemail                                   | must be a well-formed email address  |

  @negative
  Scenario Outline: Create booking with missing required fields
    When I create a booking without <field>
    Then the response status code should be 400
    And the response should contain validation error "<expected_error>"
    Examples:
      | field        | expected_error   |
      | roomid       | must not be null |
      | firstname    | must not be null |
      | bookingdates | must not be null |

  @negative
  Scenario Outline: Create booking with invalid dates
    When I create a booking with checkin "<checkin>" and checkout "<checkout>"
    Then the response status code should be 400
    And the response should contain validation error "<expected_error>"
    Examples:
      | checkin    | checkout   | expected_error            |
      | 2025-10-15 | 2025-10-13 | Failed to create booking |
      | 2025-10-15 | 2025-10-15 | Failed to create booking |
```

## Conclusion

**For most projects: Use 3-5 Scenario Outlines grouped by test type/category**

This provides the best balance of:
- ✅ Readability
- ✅ Maintainability  
- ✅ Simplicity
- ✅ Scalability

Your current single Scenario Outline works, but splitting into logical groups would be more maintainable and readable, especially as the test suite grows.

