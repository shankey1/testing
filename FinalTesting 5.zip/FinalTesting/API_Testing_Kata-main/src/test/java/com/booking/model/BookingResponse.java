package com.booking.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * Model class representing the booking API response
 * Note: The API returns booking fields at root level along with bookingid, not nested under "booking"
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class BookingResponse {
    @JsonProperty("bookingid")
    private Integer bookingid;
    
    // Booking fields are at root level in the API response, not nested under "booking"
    @JsonProperty("roomid")
    private Integer roomid;
    
    @JsonProperty("firstname")
    private String firstname;
    
    @JsonProperty("lastname")
    private String lastname;
    
    @JsonProperty("depositpaid")
    private Boolean depositpaid;
    
    @JsonProperty("bookingdates")
    private BookingDates bookingdates;
    
    @JsonProperty("email")
    private String email;
    
    @JsonProperty("phone")
    private String phone;
    
    @JsonProperty("errors")
    private List<String> errors;
    
    /**
     * Helper method to get booking object from response fields
     * This maintains backward compatibility with code that expects a Booking object
     */
    public Booking getBooking() {
        if (roomid == null && firstname == null && lastname == null) {
            return null;
        }
        return Booking.builder()
                .roomid(roomid)
                .firstname(firstname)
                .lastname(lastname)
                .depositpaid(depositpaid)
                .bookingdates(bookingdates)
                .email(email)
                .phone(phone)
                .build();
    }
}

