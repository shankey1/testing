package com.booking.stepdefinitions;

import com.booking.service.BookingService;
import io.cucumber.java.en.When;
import io.restassured.response.Response;

/**
 * Step definitions for booking health check feature
 * Maps to steps in booking-health.feature
 */
public class BookingHealthStepDefinitions {
    
    private BookingService bookingService;

    public BookingHealthStepDefinitions() {
        bookingService = new BookingService();
    }

    @When("I check the health of the booking API")
    public void i_check_the_health_of_the_booking_api() {
        Response response = bookingService.healthCheck();
        CommonStepDefinitions.setResponse(response);
    }
}

