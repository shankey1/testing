package com.booking.util;

import com.booking.model.Booking;
import com.booking.model.BookingDates;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Utility class for building test data objects
 * Provides factory methods to create booking objects with default or custom values
 * This centralizes test data creation so it can be reused across all test cases
 */
public class TestDataBuilder {

    /**
     * Creates a valid booking object with all required fields
     * Each call generates unique data to avoid duplicate booking errors
     * Can be used as a base and then modified for specific test scenarios
     *
     * @return Booking object with valid unique data
     */
    public static Booking createValidBooking() {
        // Generate unique identifier to avoid duplicate booking errors
        long uniqueId = System.currentTimeMillis() % 100000; // Use last 5 digits of timestamp
        int randomSuffix = ThreadLocalRandom.current().nextInt(100, 999); // Random 3-digit number
        
        // Generate unique email, phone, and dates
        String uniqueEmail = "john.doe" + uniqueId + randomSuffix + "@example.com";
        String uniquePhone = "123456789" + String.format("%02d", randomSuffix % 100);
        
        // Generate random room ID from valid range (1-10) - common room IDs that likely exist
        int randomRoomId = ThreadLocalRandom.current().nextInt(1, 9);
        
        // Generate dates starting from today + 30 days to ensure future dates
        LocalDate baseDate = LocalDate.now().plusDays(30);
        String checkin = baseDate.format(DateTimeFormatter.ISO_DATE);
        String checkout = baseDate.plusDays(2).format(DateTimeFormatter.ISO_DATE);
        
        return Booking.builder()
                .roomid(randomRoomId)
                .firstname("John")
                .lastname("Doe")
                .depositpaid(true)
                .bookingdates(BookingDates.builder()
                        .checkin(checkin)
                        .checkout(checkout)
                        .build())
                .email(uniqueEmail)
                .phone(uniquePhone)
                .build();
    }

    /**
     * Creates a booking with custom firstname
     *
     * @param firstname the firstname value
     * @return Booking object with custom firstname
     */
    public static Booking createBookingWithFirstname(String firstname) {
        Booking booking = createValidBooking();
        booking.setFirstname(firstname);
        return booking;
    }

    /**
     * Creates a booking with custom lastname
     *
     * @param lastname the lastname value
     * @return Booking object with custom lastname
     */
    public static Booking createBookingWithLastname(String lastname) {
        Booking booking = createValidBooking();
        booking.setLastname(lastname);
        return booking;
    }

    /**
     * Creates a booking with custom email
     *
     * @param email the email value
     * @return Booking object with custom email
     */
    public static Booking createBookingWithEmail(String email) {
        Booking booking = createValidBooking();
        booking.setEmail(email);
        return booking;
    }

    /**
     * Creates a booking with custom phone
     *
     * @param phone the phone value
     * @return Booking object with custom phone
     */
    public static Booking createBookingWithPhone(String phone) {
        Booking booking = createValidBooking();
        booking.setPhone(phone);
        return booking;
    }

    /**
     * Creates a booking with custom dates
     *
     * @param checkin  the checkin date
     * @param checkout the checkout date
     * @return Booking object with custom dates
     */
    public static Booking createBookingWithDates(String checkin, String checkout) {
        Booking booking = createValidBooking();
        booking.setBookingdates(BookingDates.builder()
                .checkin(checkin)
                .checkout(checkout)
                .build());
        return booking;
    }

    /**
     * Creates a booking with custom roomid
     *
     * @param roomid the roomid value
     * @return Booking object with custom roomid
     */
    public static Booking createBookingWithRoomid(Integer roomid) {
        Booking booking = createValidBooking();
        booking.setRoomid(roomid);
        return booking;
    }

    /**
     * Creates a booking without a specific field (sets it to null)
     *
     * @param fieldName the field name to exclude
     * @return Booking object without the specified field
     */
    public static Booking createBookingWithoutField(String fieldName) {
        Booking booking = createValidBooking();
        switch (fieldName.toLowerCase()) {
            case "roomid":
                booking.setRoomid(null);
                break;
            case "firstname":
                booking.setFirstname(null);
                break;
            case "lastname":
                booking.setLastname(null);
                break;
            case "depositpaid":
                booking.setDepositpaid(null);
                break;
            case "bookingdates":
                booking.setBookingdates(null);
                break;
            case "email":
                booking.setEmail(null);
                break;
            case "phone":
                booking.setPhone(null);
                break;
            default:
                throw new IllegalArgumentException("Unknown field: " + fieldName);
        }
        return booking;
    }

    /**
     * Creates a booking with empty string for a specific field
     *
     * @param fieldName the field name to set as empty
     * @return Booking object with empty field
     */
    public static Booking createBookingWithEmptyField(String fieldName) {
        Booking booking = createValidBooking();
        switch (fieldName.toLowerCase()) {
            case "firstname":
                booking.setFirstname("");
                break;
            case "lastname":
                booking.setLastname("");
                break;
            case "email":
                booking.setEmail("");
                break;
            case "phone":
                booking.setPhone("");
                break;
            default:
                throw new IllegalArgumentException("Field cannot be set as empty: " + fieldName);
        }
        return booking;
    }

    /**
     * Creates a partial booking update object (for PATCH requests)
     * Only includes the fields that can be updated
     *
     * @param firstname    the firstname (can be null)
     * @param lastname     the lastname (can be null)
     * @param depositpaid  the depositpaid (can be null)
     * @return Booking object with only updatable fields
     */
    public static Booking createPartialBookingUpdate(String firstname, String lastname, Boolean depositpaid) {
        Booking booking = Booking.builder().build();
        if (firstname != null) {
            booking.setFirstname(firstname);
        }
        if (lastname != null) {
            booking.setLastname(lastname);
        }
        if (depositpaid != null) {
            booking.setDepositpaid(depositpaid);
        }
        return booking;
    }
}

