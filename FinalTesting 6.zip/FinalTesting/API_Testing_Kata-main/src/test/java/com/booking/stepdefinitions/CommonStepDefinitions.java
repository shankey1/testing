package com.booking.stepdefinitions;

import com.booking.config.ConfigManager;
import com.booking.model.Booking;
import com.booking.model.BookingResponse;
import com.booking.model.ErrorResponse;
import com.booking.service.AuthService;
import com.booking.service.BookingService;
import com.booking.util.TestDataBuilder;
import io.restassured.response.Response;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import org.junit.jupiter.api.Assertions;

import java.util.List;

/**
 * Common step definitions shared across multiple features
 * Contains reusable validation methods that can be used by all API test cases
 * Uses ThreadLocal to store response objects for thread-safe parallel execution
 */
public class CommonStepDefinitions {
    
    // ThreadLocal to store response objects from different step definition classes
    private static final ThreadLocal<Response> responseHolder = new ThreadLocal<>();
    
    // ThreadLocal to store authentication token for the current thread
    private static final ThreadLocal<String> tokenHolder = new ThreadLocal<>();
    
    // ThreadLocal to store created booking ID for the current thread
    private static final ThreadLocal<Integer> createdBookingIdHolder = new ThreadLocal<>();
    
    /**
     * Set the response object - called by feature-specific step definitions
     */
    public static void setResponse(Response response) {
        responseHolder.set(response);
    }
    
    /**
     * Get the response object
     */
    public static Response getResponse() {
        return responseHolder.get();
    }
    
    /**
     * Set the authentication token - called by step definitions
     */
    public static void setToken(String token) {
        tokenHolder.set(token);
    }
    
    /**
     * Get the authentication token
     */
    public static String getToken() {
        return tokenHolder.get();
    }
    
    /**
     * Set the created booking ID - called by step definitions
     */
    public static void setCreatedBookingId(Integer bookingId) {
        createdBookingIdHolder.set(bookingId);
    }
    
    /**
     * Get the created booking ID
     */
    public static Integer getCreatedBookingId() {
        return createdBookingIdHolder.get();
    }
    
    // ==================== COMMON STEP DEFINITIONS ====================
    
    /**
     * Common step definition for checking booking API availability
     * This will be used by all booking feature files
     */
    @Given("the booking API is available")
    public void the_booking_api_is_available() {
        // Check that configuration is loaded
        Assertions.assertNotNull(ConfigManager.BASE_URL, "Base URL should be configured");
        Assertions.assertNotNull(ConfigManager.BOOKING_ENDPOINT, "Booking endpoint should be configured");
    }
    
    /**
     * Common step definition for getting authentication token
     * Uses AuthService.getToken() method for simplicity and reusability
     * Optimized to check for existing token before making API call to avoid redundant requests
     * This will be used by all booking feature files that require authentication
     */
    @Given("I have a valid authentication token")
    public void i_have_a_valid_authentication_token() {
        // Check if token already exists in ThreadLocal to avoid redundant API calls
        String existingToken = getToken();
        
        if (existingToken == null || existingToken.isEmpty()) {
            // Token doesn't exist or is empty, so fetch a new one
            AuthService authService = new AuthService();
            String token = authService.getToken();
            Assertions.assertNotNull(token, "Authentication token should not be null");
            Assertions.assertFalse(token.isEmpty(), "Authentication token should not be empty");
            
            // Store token in ThreadLocal for use across step definitions
            setToken(token);
        }
        // If token already exists, reuse it without making another API call
    }
    
    /**
     * Common step definition for creating a booking
     * Creates a booking and stores its ID in ThreadLocal for use across step definitions
     * Includes retry logic to handle 409 Conflict errors (duplicate booking)
     * This will be used by all booking feature files that need a booking setup
     */
    @Given("I have created a booking")
    public void i_have_created_a_booking() {
        BookingService bookingService = new BookingService();
        int maxRetries = 3;
        int attempt = 0;
        Integer bookingId = null;
        
        // Retry logic to handle 409 Conflict errors
        while (attempt < maxRetries && bookingId == null) {
            attempt++;
            
            // Generate unique booking data for each attempt
            Booking bookingRequest = TestDataBuilder.createValidBooking();
            Response createResponse = bookingService.createBooking(bookingRequest);
            int statusCode = createResponse.getStatusCode();
            
            if (statusCode == 201) {
                // Success - extract booking ID
                BookingResponse bookingResponse = safeDeserializeBookingResponse(createResponse);
                bookingId = bookingResponse.getBookingid();
                Assertions.assertNotNull(bookingId, "Booking ID should not be null");
            } else if (statusCode == 409) {
                // Conflict - duplicate booking, try again with new data
                if (attempt < maxRetries) {
                    // Wait a small amount to ensure different timestamp/nanoTime
                    try {
                        Thread.sleep(10);
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                    }
                    continue;
                }
            } else {
                // Other error - fail the test
                String errorBody = createResponse.getBody().asString();
                Assertions.fail("Failed to create booking. Status code: " + statusCode + ", Response: " + errorBody);
            }
        }
        
        // If we still don't have a booking ID after retries, fail the test
        Assertions.assertNotNull(bookingId, "Failed to create booking after " + maxRetries + " attempts due to 409 conflicts");
        
        // Store booking ID in ThreadLocal for use across step definitions
        setCreatedBookingId(bookingId);
    }
    
    /**
     * Common step definition for status code validation
     * This will be used by both Auth and Booking features
     */
    @Then("the response status code should be {int}")
    public void the_response_status_code_should_be(int expectedStatusCode) {
        Response response = getResponse();
        Assertions.assertNotNull(response, "Response should not be null. Make sure to set response using CommonStepDefinitions.setResponse()");
        
        int actualStatusCode = response.getStatusCode();
        Assertions.assertEquals(expectedStatusCode, actualStatusCode,
                String.format("Expected status code %d but got %d. Response body: %s", 
                        expectedStatusCode, actualStatusCode, response.getBody().asString()));
    }
    
    // ==================== REUSABLE VALIDATION METHODS ====================
    
    /**
     * Validates that a booking response contains a booking ID
     * This method can be reused for all booking API responses
     *
     * @param bookingResponse the booking response object
     */
    public static void validateBookingIdExists(BookingResponse bookingResponse) {
        Assertions.assertNotNull(bookingResponse, "BookingResponse should not be null");
        
        // First check if we got a successful response
        Response response = getResponse();
        int statusCode = response.getStatusCode();
        
        if (statusCode != 201) {
            String responseBody = response.getBody().asString();
            Assertions.fail(String.format("Expected status code 201 but got %d. Response body: %s", statusCode, responseBody));
        }
        
        Integer bookingId = bookingResponse.getBookingid();
        Assertions.assertNotNull(bookingId, 
                String.format("Response should contain a booking id. Status: %d, Response body: %s", 
                        statusCode, response.getBody().asString()));
    }
    
    /**
     * Validates that booking details in response match the request
     * This method can be reused for create and update operations
     *
     * @param bookingResponse the booking response object
     * @param expectedBooking the expected booking object from request
     */
    public static void validateBookingDetailsMatch(BookingResponse bookingResponse, Booking expectedBooking) {
        Assertions.assertNotNull(bookingResponse, "BookingResponse should not be null");
        Booking returnedBooking = bookingResponse.getBooking();
        Assertions.assertNotNull(returnedBooking, "Booking should be present in response");
        
        // Validate fields that are returned in the API response
        // Note: email and phone are not returned in create booking response, so we skip those
        Assertions.assertEquals(expectedBooking.getFirstname(), returnedBooking.getFirstname(), "Firstname should match");
        Assertions.assertEquals(expectedBooking.getLastname(), returnedBooking.getLastname(), "Lastname should match");
        Assertions.assertEquals(expectedBooking.getRoomid(), returnedBooking.getRoomid(), "Roomid should match");
        Assertions.assertEquals(expectedBooking.getDepositpaid(), returnedBooking.getDepositpaid(), "Depositpaid should match");
        
        // Validate booking dates
        Assertions.assertNotNull(returnedBooking.getBookingdates(), "Booking dates should be present");
        Assertions.assertEquals(expectedBooking.getBookingdates().getCheckin(), 
                               returnedBooking.getBookingdates().getCheckin(), 
                               "Checkin date should match");
        Assertions.assertEquals(expectedBooking.getBookingdates().getCheckout(), 
                               returnedBooking.getBookingdates().getCheckout(), 
                               "Checkout date should match");
    }
    
    /**
     * Validates that response contains validation errors
     * This method handles both errors array and raw response body
     *
     * @param bookingResponse the booking response object
     * @param expectedError   the expected error message
     */
    public static void validateValidationError(BookingResponse bookingResponse, String expectedError) {
        Assertions.assertNotNull(bookingResponse, "BookingResponse should not be null");
        Response response = getResponse();
        
        List<String> errors = bookingResponse.getErrors();
        
        // Check if errors list exists and contains expected error
        if (errors != null && !errors.isEmpty()) {
            Assertions.assertTrue(errors.contains(expectedError),
                    String.format("Expected error '%s' not found in errors: %s", expectedError, errors));
        } else {
            // If errors list is null or empty, check the raw response body
            String responseBody = response.getBody().asString();
            Assertions.assertTrue(responseBody.contains(expectedError),
                    String.format("Expected error '%s' not found in response body: %s. Errors list: %s", 
                            expectedError, responseBody, errors));
        }
    }
    
    /**
     * Validates that response contains an error message (for 401 Unauthorized)
     * This method can be reused for all authentication error responses
     *
     * @param expectedError the expected error message
     */
    public static void validateErrorResponse(String expectedError) {
        Response response = getResponse();
        try {
            ErrorResponse errorResponse = response.as(ErrorResponse.class);
            String actualError = errorResponse.getError();
            Assertions.assertNotNull(actualError, "Response should contain an error message");
            Assertions.assertEquals(expectedError, actualError,
                    String.format("Expected error message '%s' but got '%s'", expectedError, actualError));
        } catch (Exception e) {
            // If deserialization fails, check raw response body
            String responseBody = response.getBody().asString();
            Assertions.assertTrue(responseBody.contains(expectedError),
                    String.format("Expected error '%s' not found in response body: %s", expectedError, responseBody));
        }
    }
    
    /**
     * Safely deserializes response to BookingResponse
     * Handles deserialization errors gracefully
     *
     * @param response the RestAssured Response object
     * @return BookingResponse object (or empty if deserialization fails)
     */
    public static BookingResponse safeDeserializeBookingResponse(Response response) {
        try {
            BookingResponse bookingResponse = response.as(BookingResponse.class);
            return bookingResponse;
        } catch (Exception e) {
            // If deserialization fails, return empty BookingResponse
            return BookingResponse.builder().build();
        }
    }
    
    /**
     * Safely deserializes response to Booking
     * Handles deserialization errors gracefully
     *
     * @param response the RestAssured Response object
     * @return Booking object (or null if deserialization fails)
     */
    public static Booking safeDeserializeBooking(Response response) {
        try {
            return response.as(Booking.class);
        } catch (Exception e) {
            return null;
        }
    }
    
    /**
     * Common step definition for validating booking details are returned
     * Used for GET operations that return complete booking objects
     * GET API response includes bookingid, so we deserialize as BookingResponse
     * Response structure: {"bookingid":4,"roomid":100,"firstname":"John","lastname":"Doe",
     *                     "depositpaid":true,"bookingdates":{"checkin":"2026-10-13","checkout":"2026-10-15"}}
     * Note: email and phone are NOT returned by GET API
     */
    @Then("the booking details should be returned")
    public void the_booking_details_should_be_returned() {
        Response response = getResponse();
        
        // GET API response includes bookingid, so deserialize as BookingResponse
        BookingResponse bookingResponse = safeDeserializeBookingResponse(response);
        Assertions.assertNotNull(bookingResponse, "BookingResponse should be present in response");
        
        // Extract booking from BookingResponse
        Booking returnedBooking = bookingResponse.getBooking();
        Assertions.assertNotNull(returnedBooking, "Booking should be present in response");
        
        // Basic validation - only check fields that are present in GET response
        Assertions.assertNotNull(returnedBooking.getRoomid(), "Roomid should not be null");
        Assertions.assertNotNull(returnedBooking.getFirstname(), "Firstname should not be null");
        Assertions.assertNotNull(returnedBooking.getLastname(), "Lastname should not be null");
        Assertions.assertNotNull(returnedBooking.getDepositpaid(), "Depositpaid should not be null");
        Assertions.assertNotNull(returnedBooking.getBookingdates(), "Booking dates should not be null");
        Assertions.assertNotNull(returnedBooking.getBookingdates().getCheckin(), "Checkin date should not be null");
        Assertions.assertNotNull(returnedBooking.getBookingdates().getCheckout(), "Checkout date should not be null");
    }
    
    /**
     * Common step definition for validating partial booking details are returned
     * Used for PATCH operations that return booking objects
     * More lenient validation - only checks that booking object exists and basic fields are present
     * PATCH may return only updated fields or all fields depending on API implementation,
     * so we validate only the most essential fields that should always be present
     */
    @Then("the partial booking details should be returned")
    public void the_partial_booking_details_should_be_returned() {
        Response response = getResponse();
        Booking returnedBooking = safeDeserializeBooking(response);
        Assertions.assertNotNull(returnedBooking, "Booking should be present in response");
        
        // Lenient validation for PATCH - only check essential fields that should always be present
        // PATCH response structure may vary, so we validate minimally
        Assertions.assertNotNull(returnedBooking, "Booking should be present in response");
        
        // At minimum, firstname and lastname should be present (most common fields in PATCH)
        // Other fields may or may not be present depending on what was updated
        if (returnedBooking.getFirstname() != null) {
            Assertions.assertFalse(returnedBooking.getFirstname().isEmpty(), "Firstname should not be empty if present");
        }
        if (returnedBooking.getLastname() != null) {
            Assertions.assertFalse(returnedBooking.getLastname().isEmpty(), "Lastname should not be empty if present");
        }
    }
    
    /**
     * Common step definition for validating error messages
     * Used across all booking API operations for error validation
     */
    @Then("the response should contain error message {string}")
    public void the_response_should_contain_error_message(String expectedError) {
        validateErrorResponse(expectedError);
    }

    /**
     * Common step definition for validating validation errors
     * Used for create and update operations that return validation errors
     */
    @Then("the response should contain validation error {string}")
    public void the_response_should_contain_validation_error(String expectedError) {
        Response response = getResponse();
        BookingResponse bookingResponse = safeDeserializeBookingResponse(response);
        validateValidationError(bookingResponse, expectedError);
    }
}

