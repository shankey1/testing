package com.booking.service;

import com.booking.config.ConfigManager;
import com.booking.model.AuthRequest;
import com.booking.model.AuthResponse;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

import static io.restassured.RestAssured.given;

/**
 * Simple service class for authentication API calls
 * This class handles all login requests to the authentication endpoint
 */
public class AuthService {

    /**
     * Login with username and password
     * Sends a POST request to the login endpoint and returns the Response
     *
     * @param username the username
     * @param password the password
     * @return Response object containing status code and body
     */
    public Response loginRequest(String username, String password) {
        // Create request object with username and password
        AuthRequest request = new AuthRequest(username, password);

        // Send POST request to login endpoint and return Response
        return given()
                .baseUri(ConfigManager.BASE_URL)
                .contentType(ContentType.JSON)
                .body(request)
                .when()
                .post(ConfigManager.AUTH_ENDPOINT)
                .then()
                .extract()
                .response();
    }

    /**
     * Login with username and password
     * Sends a POST request to the login endpoint and returns the AuthResponse
     *
     * @param username the username
     * @param password the password
     * @return AuthResponse with token (if successful) or error message (if failed)
     */
    public AuthResponse login(String username, String password) {
        Response response = loginRequest(username, password);
        return response.as(AuthResponse.class);
    }

    /**
     * Login with default credentials from configuration
     * Uses username and password from application.properties
     *
     * @return AuthResponse with token
     */
    public AuthResponse login() {
        return login(ConfigManager.USERNAME, ConfigManager.PASSWORD);
    }

    /**
     * Get token using default credentials
     * Convenience method to get just the token string
     *
     * @return token as string
     */
    public String getToken() {
        return login().getToken();
    }
}

