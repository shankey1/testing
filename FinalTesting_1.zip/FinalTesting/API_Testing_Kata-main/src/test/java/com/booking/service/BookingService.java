package com.booking.service;

import com.booking.config.ConfigManager;
import com.booking.model.Booking;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

import static io.restassured.RestAssured.given;

/**
 * Service class for booking API operations
 * Handles all CRUD operations for bookings
 */
public class BookingService {

    /**
     * Create a new booking
     *
     * @param booking the booking object with all booking details
     * @return Response object containing status code and body
     */
    public Response createBooking(Booking booking) {
        return given()
                .baseUri(ConfigManager.BASE_URL)
                .contentType(ContentType.JSON)
                .body(booking)
                .when()
                .post(ConfigManager.BOOKING_ENDPOINT)
                .then()
                .extract()
                .response();
    }

    /**
     * Get booking by ID
     *
     * @param bookingId the booking ID
     * @param token      the authentication token
     * @return Response object containing status code and body
     */
    public Response getBookingById(Integer bookingId, String token) {
        return given()
                .baseUri(ConfigManager.BASE_URL)
                .cookie("token", token)
                .when()
                .get(ConfigManager.BOOKING_ENDPOINT + "/" + bookingId)
                .then()
                .extract()
                .response();
    }

    /**
     * Get booking by ID without authentication
     *
     * @param bookingId the booking ID
     * @return Response object containing status code and body
     */
    public Response getBookingByIdWithoutAuth(Integer bookingId) {
        return given()
                .baseUri(ConfigManager.BASE_URL)
                .when()
                .get(ConfigManager.BOOKING_ENDPOINT + "/" + bookingId)
                .then()
                .extract()
                .response();
    }

    /**
     * Get booking by ID with invalid token
     *
     * @param bookingId the booking ID
     * @param invalidToken the invalid authentication token
     * @return Response object containing status code and body
     */
    public Response getBookingByIdWithInvalidToken(Integer bookingId, String invalidToken) {
        return given()
                .baseUri(ConfigManager.BASE_URL)
                .cookie("token", invalidToken)
                .when()
                .get(ConfigManager.BOOKING_ENDPOINT + "/" + bookingId)
                .then()
                .extract()
                .response();
    }

    /**
     * Get booking by ID with empty token
     *
     * @param bookingId the booking ID
     * @return Response object containing status code and body
     */
    public Response getBookingByIdWithEmptyToken(Integer bookingId) {
        return given()
                .baseUri(ConfigManager.BASE_URL)
                .cookie("token", "")
                .when()
                .get(ConfigManager.BOOKING_ENDPOINT + "/" + bookingId)
                .then()
                .extract()
                .response();
    }

    /**
     * Update entire booking
     *
     * @param bookingId the booking ID
     * @param booking   the updated booking object
     * @param token     the authentication token
     * @return Response object containing status code and body
     */
    public Response updateBooking(Integer bookingId, Booking booking, String token) {
        return given()
                .baseUri(ConfigManager.BASE_URL)
                .contentType(ContentType.JSON)
                .cookie("token", token)
                .body(booking)
                .when()
                .put(ConfigManager.BOOKING_ENDPOINT + "/" + bookingId)
                .then()
                .extract()
                .response();
    }

    /**
     * Update entire booking without authentication
     *
     * @param bookingId the booking ID
     * @param booking   the updated booking object
     * @return Response object containing status code and body
     */
    public Response updateBookingWithoutAuth(Integer bookingId, Booking booking) {
        return given()
                .baseUri(ConfigManager.BASE_URL)
                .contentType(ContentType.JSON)
                .body(booking)
                .when()
                .put(ConfigManager.BOOKING_ENDPOINT + "/" + bookingId)
                .then()
                .extract()
                .response();
    }

    /**
     * Update booking with invalid token
     *
     * @param bookingId the booking ID
     * @param booking   the updated booking object
     * @param invalidToken the invalid authentication token
     * @return Response object containing status code and body
     */
    public Response updateBookingWithInvalidToken(Integer bookingId, Booking booking, String invalidToken) {
        return given()
                .baseUri(ConfigManager.BASE_URL)
                .contentType(ContentType.JSON)
                .cookie("token", invalidToken)
                .body(booking)
                .when()
                .put(ConfigManager.BOOKING_ENDPOINT + "/" + bookingId)
                .then()
                .extract()
                .response();
    }

    /**
     * Update booking with empty token
     *
     * @param bookingId the booking ID
     * @param booking   the updated booking object
     * @return Response object containing status code and body
     */
    public Response updateBookingWithEmptyToken(Integer bookingId, Booking booking) {
        return given()
                .baseUri(ConfigManager.BASE_URL)
                .contentType(ContentType.JSON)
                .cookie("token", "")
                .body(booking)
                .when()
                .put(ConfigManager.BOOKING_ENDPOINT + "/" + bookingId)
                .then()
                .extract()
                .response();
    }

    /**
     * Partially update booking (PATCH)
     *
     * @param bookingId the booking ID
     * @param booking   the partial booking object with only fields to update
     * @param token     the authentication token
     * @return Response object containing status code and body
     */
    public Response partialUpdateBooking(Integer bookingId, Booking booking, String token) {
        return given()
                .baseUri(ConfigManager.BASE_URL)
                .contentType(ContentType.JSON)
                .cookie("token", token)
                .body(booking)
                .when()
                .patch(ConfigManager.BOOKING_ENDPOINT + "/" + bookingId)
                .then()
                .extract()
                .response();
    }

    /**
     * Partially update booking without authentication
     *
     * @param bookingId the booking ID
     * @param booking   the partial booking object
     * @return Response object containing status code and body
     */
    public Response partialUpdateBookingWithoutAuth(Integer bookingId, Booking booking) {
        return given()
                .baseUri(ConfigManager.BASE_URL)
                .contentType(ContentType.JSON)
                .body(booking)
                .when()
                .patch(ConfigManager.BOOKING_ENDPOINT + "/" + bookingId)
                .then()
                .extract()
                .response();
    }

    /**
     * Partially update booking with invalid token
     *
     * @param bookingId the booking ID
     * @param booking   the partial booking object
     * @param invalidToken the invalid authentication token
     * @return Response object containing status code and body
     */
    public Response partialUpdateBookingWithInvalidToken(Integer bookingId, Booking booking, String invalidToken) {
        return given()
                .baseUri(ConfigManager.BASE_URL)
                .contentType(ContentType.JSON)
                .cookie("token", invalidToken)
                .body(booking)
                .when()
                .patch(ConfigManager.BOOKING_ENDPOINT + "/" + bookingId)
                .then()
                .extract()
                .response();
    }

    /**
     * Partially update booking with empty token
     *
     * @param bookingId the booking ID
     * @param booking   the partial booking object
     * @return Response object containing status code and body
     */
    public Response partialUpdateBookingWithEmptyToken(Integer bookingId, Booking booking) {
        return given()
                .baseUri(ConfigManager.BASE_URL)
                .contentType(ContentType.JSON)
                .cookie("token", "")
                .body(booking)
                .when()
                .patch(ConfigManager.BOOKING_ENDPOINT + "/" + bookingId)
                .then()
                .extract()
                .response();
    }

    /**
     * Delete booking
     *
     * @param bookingId the booking ID
     * @param token     the authentication token
     * @return Response object containing status code and body
     */
    public Response deleteBooking(Integer bookingId, String token) {
        return given()
                .baseUri(ConfigManager.BASE_URL)
                .cookie("token", token)
                .when()
                .delete(ConfigManager.BOOKING_ENDPOINT + "/" + bookingId)
                .then()
                .extract()
                .response();
    }

    /**
     * Delete booking without authentication
     *
     * @param bookingId the booking ID
     * @return Response object containing status code and body
     */
    public Response deleteBookingWithoutAuth(Integer bookingId) {
        return given()
                .baseUri(ConfigManager.BASE_URL)
                .when()
                .delete(ConfigManager.BOOKING_ENDPOINT + "/" + bookingId)
                .then()
                .extract()
                .response();
    }

    /**
     * Delete booking with invalid token
     *
     * @param bookingId the booking ID
     * @param invalidToken the invalid authentication token
     * @return Response object containing status code and body
     */
    public Response deleteBookingWithInvalidToken(Integer bookingId, String invalidToken) {
        return given()
                .baseUri(ConfigManager.BASE_URL)
                .cookie("token", invalidToken)
                .when()
                .delete(ConfigManager.BOOKING_ENDPOINT + "/" + bookingId)
                .then()
                .extract()
                .response();
    }

    /**
     * Delete booking with empty token
     *
     * @param bookingId the booking ID
     * @return Response object containing status code and body
     */
    public Response deleteBookingWithEmptyToken(Integer bookingId) {
        return given()
                .baseUri(ConfigManager.BASE_URL)
                .cookie("token", "")
                .when()
                .delete(ConfigManager.BOOKING_ENDPOINT + "/" + bookingId)
                .then()
                .extract()
                .response();
    }

    /**
     * Health check endpoint
     *
     * @return Response object containing status code and body
     */
    public Response healthCheck() {
        return given()
                .baseUri(ConfigManager.BASE_URL)
                .when()
                .get(ConfigManager.BOOKING_ENDPOINT + "/actuator/health")
                .then()
                .extract()
                .response();
    }
}

