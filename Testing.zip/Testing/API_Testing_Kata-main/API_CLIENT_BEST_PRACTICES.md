# API Client Best Practices - BookingClient

## 🎯 Recommended Approach: **Single Method with Response + Optional Helpers**

### **Best Practice: Always Return Response as Primary Method**

The optimal approach is to have **one primary method that always returns `Response`**, with optional helper methods for convenience in success scenarios.

---

## 📊 Comparison of Approaches

### ❌ **Approach 1: Separate Methods (Current - Not Optimal)**
```java
// Problem: Too many methods, duplication
public Booking getBookingById(Integer id, String token)
public Response getBookingByIdWithResponse(Integer id, String token)
public Response getBookingByIdWithoutAuth(Integer id)
```

**Issues:**
- Method proliferation (3x methods per operation)
- Code duplication
- Inconsistent API
- Hard to maintain

### ✅ **Approach 2: Single Method with Response (Recommended)**
```java
// Primary method - always returns Response
public Response getBookingById(Integer id, String token)
public Response getBookingById(Integer id) // Optional: without auth

// Optional helper for convenience (if needed)
public Booking getBookingByIdAsObject(Integer id, String token) {
    Response response = getBookingById(id, token);
    if (response.getStatusCode() == 200) {
        return response.as(Booking.class);
    }
    throw new RuntimeException("Failed to get booking: " + response.getStatusCode());
}
```

**Benefits:**
- ✅ Single source of truth
- ✅ Always handles errors
- ✅ Flexible - caller decides what to do
- ✅ Less code duplication
- ✅ Easier to maintain

---

## 🏆 **Recommended Implementation**

### **Pattern: Response-First Design**

```java
public class BookingClient {
    
    // ============================================
    // PRIMARY METHODS - Always return Response
    // ============================================
    
    /**
     * Create a booking
     * @param booking Booking object
     * @return Response - caller handles success/error
     */
    public Response createBooking(Booking booking) {
        return given()
                .contentType(ContentType.JSON)
                .body(booking)
                .when()
                .post(Config.BOOKING_ENDPOINT)
                .then()
                .extract()
                .response();
    }
    
    /**
     * Get booking by ID
     * @param bookingId Booking ID
     * @param token Authentication token (optional - null for no auth)
     * @return Response - caller handles success/error
     */
    public Response getBookingById(Integer bookingId, String token) {
        if (token != null) {
            return given()
                    .cookie("token", token)
                    .when()
                    .get(Config.BOOKING_ENDPOINT + "/" + bookingId)
                    .then()
                    .extract()
                    .response();
        } else {
            return given()
                    .when()
                    .get(Config.BOOKING_ENDPOINT + "/" + bookingId)
                    .then()
                    .extract()
                    .response();
        }
    }
    
    /**
     * Update booking
     * @param bookingId Booking ID
     * @param booking Updated booking
     * @param token Authentication token (optional)
     * @return Response
     */
    public Response updateBooking(Integer bookingId, Booking booking, String token) {
        if (token != null) {
            return given()
                    .contentType(ContentType.JSON)
                    .cookie("token", token)
                    .body(booking)
                    .when()
                    .put(Config.BOOKING_ENDPOINT + "/" + bookingId)
                    .then()
                    .extract()
                    .response();
        } else {
            return given()
                    .contentType(ContentType.JSON)
                    .body(booking)
                    .when()
                    .put(Config.BOOKING_ENDPOINT + "/" + bookingId)
                    .then()
                    .extract()
                    .response();
        }
    }
    
    /**
     * Partially update booking
     */
    public Response partialUpdateBooking(Integer bookingId, Booking booking, String token) {
        // Similar pattern...
    }
    
    /**
     * Delete booking
     */
    public Response deleteBooking(Integer bookingId, String token) {
        // Similar pattern...
    }
    
    // ============================================
    // OPTIONAL: Helper methods for convenience
    // ============================================
    
    /**
     * Helper: Get booking as object (throws exception on error)
     * Use only when you're certain it will succeed
     */
    public Booking getBookingByIdAsObject(Integer bookingId, String token) {
        Response response = getBookingById(bookingId, token);
        response.then().statusCode(200);
        return response.as(Booking.class);
    }
    
    /**
     * Helper: Create booking and return parsed response
     */
    public CreateBookingResponse createBookingAsObject(Booking booking) {
        Response response = createBooking(booking);
        response.then().statusCode(200);
        return response.as(CreateBookingResponse.class);
    }
}
```

---

## 📝 **Usage Examples**

### **Success Case (Positive Testing)**
```java
// Option 1: Using Response (Recommended)
@When("I get the booking by id")
public void iGetTheBookingById() {
    Response response = bookingClient.getBookingById(bookingId, token);
    response.then().statusCode(200);
    
    Booking booking = response.as(Booking.class);
    testContext.setBooking(booking);
}

// Option 2: Using helper (if you're certain of success)
@When("I get the booking by id")
public void iGetTheBookingById() {
    Booking booking = bookingClient.getBookingByIdAsObject(bookingId, token);
    testContext.setBooking(booking);
}
```

### **Error Case (Negative Testing)**
```java
@When("I try to get booking with id {int} without authentication")
public void iTryToGetBookingWithIdWithoutAuthentication(Integer bookingId) {
    // Pass null for token = no authentication
    Response response = bookingClient.getBookingById(bookingId, null);
    testContext.setResponse(response);
}

@Then("I should receive an unauthorized error")
public void iShouldReceiveAnUnauthorizedError() {
    Response response = testContext.getResponse();
    response.then()
            .statusCode(401)
            .body("error", notNullValue());
}
```

### **Error Handling with Status Check**
```java
@When("I create a booking")
public void iCreateABooking() {
    Booking booking = testContext.getBooking();
    Response response = bookingClient.createBooking(booking);
    testContext.setResponse(response);
    
    if (response.getStatusCode() == 200) {
        CreateBookingResponse createResponse = response.as(CreateBookingResponse.class);
        testContext.setCreateBookingResponse(createResponse);
        testContext.setBookingId(createResponse.getBookingid());
    }
    // Error cases handled in Then steps
}
```

---

## 🎯 **Key Principles**

### **1. Response-First Design**
- ✅ Primary methods always return `Response`
- ✅ Caller has full control over error handling
- ✅ Can check status codes, error messages, headers

### **2. Optional Token Parameter**
- ✅ Pass `token` for authenticated requests
- ✅ Pass `null` for unauthenticated requests (negative testing)
- ✅ Single method handles both cases

### **3. Optional Helper Methods**
- ✅ Provide convenience methods for common success cases
- ✅ Helpers throw exceptions on error (fail fast)
- ✅ Use only when certain of success

### **4. Consistent API**
- ✅ All methods follow same pattern
- ✅ Easy to understand and maintain
- ✅ Less code duplication

---

## 📊 **Method Count Comparison**

| Approach | Methods per Operation | Total Methods (5 ops) |
|----------|----------------------|----------------------|
| **Current (Separate)** | 3 methods | 15 methods |
| **Recommended (Response-First)** | 1 primary + 1 optional helper | 5-10 methods |

**Result: 50% less code, more maintainable**

---

## ✅ **Final Recommendation**

**Use Response-First Design:**
1. ✅ Primary method always returns `Response`
2. ✅ Optional `token` parameter (null = no auth)
3. ✅ Optional helper methods for convenience
4. ✅ Single method per operation
5. ✅ Consistent across all operations

This approach provides:
- **Flexibility**: Handle all cases (success, error, unauthorized)
- **Simplicity**: Less code, easier to maintain
- **Consistency**: Same pattern everywhere
- **Testability**: Easy to test both positive and negative cases

