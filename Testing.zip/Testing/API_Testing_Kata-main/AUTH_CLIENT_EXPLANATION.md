# AuthClient.java - Complete Code Explanation

## Overview

`AuthClient` is an **API client class** that encapsulates all authentication-related API calls. It provides a clean, reusable interface for authenticating users and obtaining authentication tokens.

---

## Class Structure

```java
package com.booking.api;

import com.booking.config.Config;
import com.booking.models.AuthRequest;
import com.booking.models.AuthResponse;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

import static io.restassured.RestAssured.given;

public class AuthClient {
    // Methods for authentication
}
```

### Imports Explained

1. **`com.booking.config.Config`** - Configuration class containing API endpoints and credentials
2. **`com.booking.models.AuthRequest`** - Model class for authentication request payload
3. **`com.booking.models.AuthResponse`** - Model class for authentication response
4. **`io.restassured.http.ContentType`** - RestAssured enum for content types (JSON, XML, etc.)
5. **`io.restassured.response.Response`** - RestAssured response object
6. **`static io.restassured.RestAssured.given`** - RestAssured static import for building HTTP requests

---

## Method 1: `login(String username, String password)`

### Code
```java
public AuthResponse login(String username, String password) {
    AuthRequest authRequest = new AuthRequest(username, password);
    
    Response response = given()
            .contentType(ContentType.JSON)
            .body(authRequest)
            .when()
            .post(Config.AUTH_ENDPOINT)
            .then()
            .extract()
            .response();
    
    return response.as(AuthResponse.class);
}
```

### Step-by-Step Explanation

#### Step 1: Create Request Object
```java
AuthRequest authRequest = new AuthRequest(username, password);
```
- Creates an `AuthRequest` object with username and password
- This object will be serialized to JSON automatically

**Example**:
```java
AuthRequest authRequest = new AuthRequest("admin", "password");
// Will be converted to JSON: {"username":"admin","password":"password"}
```

#### Step 2: Build HTTP Request
```java
Response response = given()
```
- `given()` - Starts building a RestAssured HTTP request
- Returns a request specification builder

#### Step 3: Set Content Type
```java
.contentType(ContentType.JSON)
```
- Sets the HTTP header `Content-Type: application/json`
- Tells the server we're sending JSON data

#### Step 4: Set Request Body
```java
.body(authRequest)
```
- Sets the request body to the `AuthRequest` object
- RestAssured automatically converts Java object to JSON using Jackson
- The JSON will look like:
  ```json
  {
    "username": "admin",
    "password": "password"
  }
  ```

#### Step 5: Specify HTTP Method and Endpoint
```java
.when()
.post(Config.AUTH_ENDPOINT)
```
- `.when()` - Separates request setup from action
- `.post()` - Specifies HTTP POST method
- `Config.AUTH_ENDPOINT` - The endpoint URL: `"https://automationintesting.online/api/auth/login"`

**Complete HTTP Request**:
```
POST https://automationintesting.online/api/auth/login
Content-Type: application/json

{
  "username": "admin",
  "password": "password"
}
```

#### Step 6: Extract Response
```java
.then()
.extract()
.response();
```
- `.then()` - Starts response validation/extraction
- `.extract()` - Extracts data from response
- `.response()` - Gets the full Response object

#### Step 7: Convert Response to Java Object
```java
return response.as(AuthResponse.class);
```
- Converts JSON response to `AuthResponse` Java object
- RestAssured uses Jackson to deserialize JSON to Java object

**Example Response**:
```json
{
  "token": "abc123token"
}
```

**Becomes**:
```java
AuthResponse {
    token: "abc123token"
}
```

### Complete Flow Diagram

```
1. Create AuthRequest object
   ↓
2. Build HTTP request with RestAssured
   ↓
3. Set Content-Type: application/json
   ↓
4. Set request body (AuthRequest → JSON)
   ↓
5. POST to /api/auth/login
   ↓
6. Receive JSON response
   ↓
7. Convert JSON → AuthResponse object
   ↓
8. Return AuthResponse
```

---

## Method 2: `login()` - Overloaded Method

### Code
```java
public AuthResponse login() {
    return login(Config.USERNAME, Config.PASSWORD);
}
```

### Explanation

This is a **convenience method** (method overloading) that:
- Calls the main `login()` method with default credentials
- Uses credentials from `Config` class:
  - `Config.USERNAME = "admin"`
  - `Config.PASSWORD = "password"`

### Usage

**Without default credentials**:
```java
AuthClient authClient = new AuthClient();
AuthResponse response = authClient.login("admin", "password");
```

**With default credentials** (easier):
```java
AuthClient authClient = new AuthClient();
AuthResponse response = authClient.login();  // Uses default credentials
```

### Benefits

1. **Less code** - Don't need to pass credentials every time
2. **Consistency** - Always uses same default credentials
3. **Convenience** - Quick authentication for most test scenarios

---

## Method 3: `getToken()` - Quick Token Retrieval

### Code
```java
public String getToken() {
    return login().getToken();
}
```

### Explanation

This is a **helper method** that:
1. Calls `login()` with default credentials
2. Extracts the token from the response
3. Returns just the token string (not the full response object)

### Usage Comparison

**Without `getToken()` method**:
```java
AuthClient authClient = new AuthClient();
AuthResponse response = authClient.login();
String token = response.getToken();
```

**With `getToken()` method** (simpler):
```java
AuthClient authClient = new AuthClient();
String token = authClient.getToken();  // One line!
```

### Benefits

1. **Simpler** - One method call instead of two
2. **Focused** - Returns only what you need (the token)
3. **Cleaner code** - Less verbose in step definitions

---

## Complete Usage Examples

### Example 1: Basic Authentication

```java
AuthClient authClient = new AuthClient();

// Method 1: With custom credentials
AuthResponse response = authClient.login("admin", "password");
String token = response.getToken();
System.out.println("Token: " + token);  // Output: Token: abc123token

// Method 2: With default credentials
AuthResponse response2 = authClient.login();
String token2 = response2.getToken();

// Method 3: Quick token retrieval
String token3 = authClient.getToken();
```

### Example 2: In Step Definitions

```java
public class AuthStepDefinitions {
    private AuthClient authClient;
    private TestContext testContext;
    
    public AuthStepDefinitions() {
        authClient = new AuthClient();
        testContext = TestContext.getInstance();
    }
    
    @Given("I am authenticated with valid credentials")
    public void iAmAuthenticatedWithValidCredentials() {
        // Use the convenient getToken() method
        String token = authClient.getToken();
        testContext.setAuthToken(token);
        assertNotNull(token, "Authentication token should not be null");
    }
    
    @When("I authenticate with username {string} and password {string}")
    public void iAuthenticateWithUsernameAndPassword(String username, String password) {
        // Use login() with custom credentials
        AuthResponse response = authClient.login(username, password);
        String token = response.getToken();
        testContext.setAuthToken(token);
    }
}
```

### Example 3: Error Handling (Potential Enhancement)

```java
public AuthResponse login(String username, String password) {
    AuthRequest authRequest = new AuthRequest(username, password);
    
    Response response = given()
            .contentType(ContentType.JSON)
            .body(authRequest)
            .when()
            .post(Config.AUTH_ENDPOINT)
            .then()
            .extract()
            .response();
    
    // Check status code
    if (response.getStatusCode() == 200) {
        return response.as(AuthResponse.class);
    } else {
        // Handle error (throw exception, log, etc.)
        throw new RuntimeException("Authentication failed: " + response.getStatusCode());
    }
}
```

---

## Design Patterns Used

### 1. **Client Pattern**
- Encapsulates API calls in a dedicated class
- Provides a clean interface for authentication operations
- Hides implementation details (RestAssured, HTTP details)

### 2. **Method Overloading**
- `login()` - Default credentials
- `login(String, String)` - Custom credentials
- Same method name, different parameters

### 3. **Fluent Interface**
- RestAssured's builder pattern
- Method chaining: `.given().contentType().body().when().post()`

### 4. **Separation of Concerns**
- **AuthClient**: Handles API calls
- **AuthRequest/AuthResponse**: Handle data structures
- **Config**: Handles configuration
- **Step Definitions**: Use AuthClient for testing

---

## HTTP Request/Response Details

### Request Details

**URL**: `https://automationintesting.online/api/auth/login`  
**Method**: `POST`  
**Headers**:
```
Content-Type: application/json
```

**Body**:
```json
{
  "username": "admin",
  "password": "password"
}
```

### Response Details

**Success Response (200 OK)**:
```json
{
  "token": "abc123token"
}
```

**Error Response (401 Unauthorized)**:
```json
{
  "error": "Invalid credentials"
}
```

---

## Key Concepts

### 1. **RestAssured Framework**
- Java library for testing REST APIs
- Provides fluent API for HTTP requests
- Handles JSON serialization/deserialization

### 2. **JSON Serialization**
- Java object → JSON: `body(authRequest)` automatically converts
- Uses Jackson library under the hood

### 3. **JSON Deserialization**
- JSON → Java object: `response.as(AuthResponse.class)`
- Maps JSON fields to Java object properties

### 4. **Static Import**
```java
import static io.restassured.RestAssured.given;
```
- Allows using `given()` directly instead of `RestAssured.given()`
- Makes code more readable

---

## Benefits of This Design

### ✅ **Reusability**
- Use `AuthClient` in multiple step definitions
- No code duplication

### ✅ **Maintainability**
- If API changes, update only `AuthClient`
- Other code doesn't need changes

### ✅ **Testability**
- Easy to mock `AuthClient` in unit tests
- Clear separation of concerns

### ✅ **Readability**
- Method names are self-documenting
- `getToken()` is clearer than making HTTP call directly

### ✅ **Flexibility**
- Multiple ways to authenticate (default or custom)
- Can extend with more methods if needed

---

## Potential Enhancements

### 1. **Error Handling**
```java
public AuthResponse login(String username, String password) {
    // ... existing code ...
    
    if (response.getStatusCode() != 200) {
        throw new AuthenticationException("Login failed: " + response.getBody().asString());
    }
    
    return response.as(AuthResponse.class);
}
```

### 2. **Logging**
```java
public AuthResponse login(String username, String password) {
    logger.info("Attempting to login with username: " + username);
    // ... existing code ...
    logger.info("Login successful, token received");
    return response.as(AuthResponse.class);
}
```

### 3. **Token Caching**
```java
private String cachedToken;
private long tokenExpiryTime;

public String getToken() {
    if (cachedToken != null && System.currentTimeMillis() < tokenExpiryTime) {
        return cachedToken;  // Return cached token
    }
    // Get new token and cache it
    cachedToken = login().getToken();
    tokenExpiryTime = System.currentTimeMillis() + 3600000; // 1 hour
    return cachedToken;
}
```

---

## Summary

**AuthClient** is a well-designed API client that:
- ✅ Encapsulates authentication API calls
- ✅ Provides multiple convenient methods
- ✅ Uses RestAssured for HTTP requests
- ✅ Handles JSON serialization/deserialization
- ✅ Follows good design patterns
- ✅ Makes authentication simple and reusable

**Key Methods**:
1. `login(username, password)` - Authenticate with custom credentials
2. `login()` - Authenticate with default credentials
3. `getToken()` - Quick token retrieval

**Usage**: Simple and intuitive - just create an instance and call the methods!

