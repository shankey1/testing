# auth.feature File - Complete Explanation

## Overview

The `auth.feature` file contains **Gherkin** test scenarios for testing the Authentication API. It uses **BDD (Behavior-Driven Development)** syntax to describe authentication test cases in plain English.

---

## File Structure

```
auth.feature
├── Feature Header (Lines 1-5)
├── Positive Scenarios (Lines 7-24)
│   ├── Login with default credentials
│   └── Login with valid credentials (Scenario Outline)
├── Negative Scenarios (Lines 25-89)
│   ├── Invalid credentials (Scenario Outline)
│   ├── Boundary values (Scenario Outline)
│   ├── SQL injection attempts (Scenario Outline)
│   └── XSS attempts (Scenario Outline)
```

---

## Section 1: Feature Header

```gherkin
@auth
Feature: Authentication API - Comprehensive Test Coverage
  As a user
  I want to authenticate
  So that I can access protected endpoints
```

### Explanation

1. **`@auth`** - **Tag**: Categorizes this feature file
   - Used to filter tests: `mvn test -Dcucumber.filter.tags="@auth"`
   - Groups all authentication-related tests

2. **`Feature:`** - **Keyword**: Defines the feature being tested
   - Name: "Authentication API - Comprehensive Test Coverage"
   - Describes what this file tests

3. **`As a user`** - **User Story Format**: Who benefits from this feature
   - Written in user story format (As a... I want... So that...)

4. **`I want to authenticate`** - **Goal**: What the user wants to do

5. **`So that I can access protected endpoints`** - **Benefit**: Why it's needed

### Purpose
- Documents the feature being tested
- Provides context for test scenarios
- Helps non-technical stakeholders understand tests

---

## Section 2: Positive Scenarios

### Scenario 1: Login with Valid Default Credentials

```gherkin
@sanity @regression @login @positive @critical
Scenario: Login with valid default credentials
  When I authenticate with default credentials
  Then I should receive an authentication token
```

#### Tags Explained

- **`@sanity`** - Part of sanity test suite (quick validation)
- **`@regression`** - Part of regression test suite (comprehensive)
- **`@login`** - Login operation tag
- **`@positive`** - Positive test scenario
- **`@critical`** - Critical path test

#### Steps Explained

1. **`When I authenticate with default credentials`**
   - **Action step**: Performs authentication
   - **Maps to**: `AuthStepDefinitions.iAuthenticateWithDefaultCredentials()`
   - **What it does**:
     ```java
     String token = authClient.login().getToken();
     testContext.setAuthToken(token);
     ```
   - Uses default credentials: `admin` / `password`

2. **`Then I should receive an authentication token`**
   - **Assertion step**: Validates the result
   - **Maps to**: `AuthStepDefinitions.iShouldReceiveAnAuthenticationToken()`
   - **What it validates**:
     - Status code is 200
     - Response contains a token
     - Token is not null or empty

#### Test Flow

```
1. Authenticate with default credentials
   ↓
2. API returns token
   ↓
3. Validate token exists and is valid
   ↓
4. Test passes ✅
```

---

### Scenario 2: Login with Valid Credentials (Scenario Outline)

```gherkin
@regression @login @positive
Scenario Outline: Login with valid credentials
  When I authenticate with username "<username>" and password "<password>"
  Then I should receive an authentication token

  Examples: Valid Credentials
    | username | password |
    | admin    | password |
```

#### Scenario Outline Explained

**Scenario Outline** allows **data-driven testing** - same scenario runs with different data.

#### How It Works

1. **Template Steps** (with placeholders):
   ```gherkin
   When I authenticate with username "<username>" and password "<password>"
   ```
   - `<username>` and `<password>` are placeholders
   - Will be replaced with actual values from Examples table

2. **Examples Table**:
   ```
   | username | password |
   | admin    | password |
   ```
   - Defines test data
   - Each row = one test execution

#### Execution

The scenario runs **once** for each row in Examples:

**Test 1**:
```
When I authenticate with username "admin" and password "password"
Then I should receive an authentication token
```

#### Tags

- **`@regression`** - Only in regression suite (not sanity)
- **`@login @positive`** - Login positive test

---

## Section 3: Negative Scenarios

### Scenario 3: Login with Invalid Credentials

```gherkin
@regression @login @negative
Scenario Outline: Login with invalid credentials
  When I authenticate with username "<username>" and password "<password>"
  Then I should receive an authentication error

  Examples: Invalid Credentials
    | username      | password      | description                    |
    | invalid       | invalid       | Wrong username and password   |
    | admin         | wrongpass     | Correct username, wrong pass  |
    | wronguser     | password      | Wrong username, correct pass  |
    | ADMIN         | PASSWORD      | Case sensitive mismatch       |
    | admin123      | password123   | Username with numbers         |
    |               | password      | Empty username                |
    | admin         |               | Empty password                 |
    |               |               | Both empty                     |
    | null          | null          | Null values                   |
    | test@user.com | test123       | Email format as username      |
    | admin         | password123   | Password with numbers         |
    | admin!@#      | password!@#   | Special characters            |
    | verylongusernamethatexceedsnormallimits | password | Very long username |
    | admin         | verylongpasswordthatexceedsnormallimits | Very long password |
```

#### Purpose

Tests that authentication **fails correctly** with invalid credentials.

#### Test Cases Covered

1. **Wrong credentials**: `invalid` / `invalid`
2. **Wrong password**: `admin` / `wrongpass`
3. **Wrong username**: `wronguser` / `password`
4. **Case sensitivity**: `ADMIN` / `PASSWORD` (should fail)
5. **Numbers in credentials**: `admin123` / `password123`
6. **Empty username**: `""` / `password`
7. **Empty password**: `admin` / `""`
8. **Both empty**: `""` / `""`
9. **Null values**: `null` / `null`
10. **Email format**: `test@user.com` / `test123`
11. **Special characters**: `admin!@#` / `password!@#`
12. **Very long username**: Tests length limits
13. **Very long password**: Tests length limits

#### Expected Result

All should return **401 Unauthorized** with error message.

#### Step Mapping

- **`When`** step maps to: `iAuthenticateWithUsernameAndPassword(username, password)`
- **`Then`** step maps to: `iShouldReceiveAnAuthenticationError()`
  - Validates: Status code = 401
  - Validates: Response contains error message

---

### Scenario 4: Login with Boundary Value Credentials

```gherkin
@regression @login @negative @boundary
Scenario Outline: Login with boundary value credentials
  When I authenticate with username "<username>" and password "<password>"
  Then I should receive an authentication error

  Examples: Boundary Values
    | username | password | description        |
    | a        | a        | Single character   |
    | ab       | ab       | Two characters      |
    |          |          | Empty strings      |
    | " "      | " "      | Whitespace only    |
    | admin    | " "      | Valid user, space  |
    | " "      | password | Space user, valid   |
```

#### Purpose

Tests **boundary values** - edge cases at limits of valid input.

#### Test Cases

1. **Single character**: `a` / `a` - Minimum length
2. **Two characters**: `ab` / `ab` - Just above minimum
3. **Empty strings**: `""` / `""` - No input
4. **Whitespace only**: `" "` / `" "` - Only spaces
5. **Valid user, space password**: `admin` / `" "` - Valid username, invalid password
6. **Space user, valid password**: `" "` / `password` - Invalid username, valid password

#### Why Test Boundary Values?

- Finds edge case bugs
- Validates input validation works correctly
- Tests minimum/maximum length handling

---

### Scenario 5: SQL Injection Attempts

```gherkin
@regression @login @negative @security @sql_injection
Scenario Outline: Login with SQL injection attempts
  When I authenticate with username "<username>" and password "<password>"
  Then I should receive an authentication error

  Examples: SQL Injection Attempts
    | username                    | password                    | description              |
    | admin' OR '1'='1            | password                    | SQL injection in username|
    | admin                       | password' OR '1'='1         | SQL injection in password|
    | admin'--                    | password                    | SQL comment in username  |
    | admin'; DROP TABLE users;--| password                    | SQL drop in username     |
    | admin' UNION SELECT * FROM users-- | password           | SQL union in username    |
```

#### Purpose

**Security testing** - Ensures API is protected against SQL injection attacks.

#### SQL Injection Attacks Tested

1. **`admin' OR '1'='1`** - Classic SQL injection
   - Attempts to bypass authentication
   - Should be rejected, not executed

2. **`password' OR '1'='1`** - SQL injection in password field

3. **`admin'--`** - SQL comment injection
   - `--` comments out rest of SQL query

4. **`admin'; DROP TABLE users;--`** - Destructive SQL injection
   - Attempts to delete database table
   - Critical security test

5. **`admin' UNION SELECT * FROM users--`** - Data extraction attempt
   - Tries to extract user data

#### Expected Behavior

- API should **reject** these inputs
- Should return **401 Unauthorized**
- Should **NOT** execute SQL code
- Should **NOT** expose database errors

#### Security Importance

✅ **Prevents**: Database manipulation  
✅ **Prevents**: Data theft  
✅ **Prevents**: System compromise  

---

### Scenario 6: XSS (Cross-Site Scripting) Attempts

```gherkin
@regression @login @negative @security @xss
Scenario Outline: Login with XSS attempts
  When I authenticate with username "<username>" and password "<password>"
  Then I should receive an authentication error

  Examples: XSS Attempts
    | username              | password              | description           |
    | <script>alert(1)</script> | password         | XSS in username       |
    | admin                | <script>alert(1)</script> | XSS in password |
    | <img src=x onerror=alert(1)> | password      | XSS img tag in username|
    | admin                | javascript:alert(1)  | XSS protocol in password|
```

#### Purpose

**Security testing** - Ensures API is protected against XSS attacks.

#### XSS Attacks Tested

1. **`<script>alert(1)</script>`** - Basic script injection
   - Attempts to execute JavaScript
   - Should be sanitized/rejected

2. **`<img src=x onerror=alert(1)>`** - Image tag XSS
   - Uses image error handler to execute code
   - Alternative XSS vector

3. **`javascript:alert(1)`** - Protocol handler XSS
   - Uses JavaScript protocol
   - Another XSS technique

#### Expected Behavior

- API should **reject** or **sanitize** these inputs
- Should return **401 Unauthorized**
- Should **NOT** execute JavaScript
- Should **NOT** reflect malicious code in response

#### Security Importance

✅ **Prevents**: Client-side code execution  
✅ **Prevents**: Session hijacking  
✅ **Prevents**: Cookie theft  

---

## Complete Test Coverage Summary

| Category | Scenarios | Test Cases | Purpose |
|----------|-----------|------------|---------|
| **Positive** | 2 | 2 | Verify valid authentication works |
| **Negative - Invalid** | 1 | 13 | Test various invalid inputs |
| **Negative - Boundary** | 1 | 6 | Test edge cases |
| **Negative - SQL Injection** | 1 | 5 | Security: SQL injection protection |
| **Negative - XSS** | 1 | 4 | Security: XSS protection |
| **TOTAL** | **6** | **30** | Comprehensive authentication testing |

---

## How Scenarios Map to Step Definitions

### Step Definition Mapping

```gherkin
When I authenticate with username "<username>" and password "<password>"
```
↓ Maps to ↓
```java
@When("I authenticate with username {string} and password {string}")
public void iAuthenticateWithUsernameAndPassword(String username, String password) {
    // Makes HTTP POST request to /api/auth/login
    // Stores response in TestContext
}
```

```gherkin
When I authenticate with default credentials
```
↓ Maps to ↓
```java
@When("I authenticate with default credentials")
public void iAuthenticateWithDefaultCredentials() {
    // Uses AuthClient.login() with default credentials
    // Stores token in TestContext
}
```

```gherkin
Then I should receive an authentication token
```
↓ Maps to ↓
```java
@Then("I should receive an authentication token")
public void iShouldReceiveAnAuthenticationToken() {
    // Validates status code = 200
    // Validates token exists and is not empty
    // Stores token in TestContext
}
```

```gherkin
Then I should receive an authentication error
```
↓ Maps to ↓
```java
@Then("I should receive an authentication error")
public void iShouldReceiveAnAuthenticationError() {
    // Validates status code = 401
    // Validates error message exists
}
```

---

## Execution Examples

### Running All Authentication Tests

```bash
mvn test -Dcucumber.filter.tags="@auth"
```

**Executes**: All 6 scenarios (30 test cases total)

### Running Only Sanity Tests

```bash
mvn test -Dcucumber.filter.tags="@sanity and @auth"
```

**Executes**: Only Scenario 1 (Login with default credentials)

### Running Only Security Tests

```bash
mvn test -Dcucumber.filter.tags="@security and @auth"
```

**Executes**: SQL injection and XSS scenarios (9 test cases)

### Running Only Positive Tests

```bash
mvn test -Dcucumber.filter.tags="@positive and @auth"
```

**Executes**: Both positive scenarios (2 test cases)

### Running Only Negative Tests

```bash
mvn test -Dcucumber.filter.tags="@negative and @auth"
```

**Executes**: All negative scenarios (28 test cases)

---

## Test Execution Flow Example

### Example: Invalid Credentials Test

```gherkin
Scenario Outline: Login with invalid credentials
  When I authenticate with username "invalid" and password "invalid"
  Then I should receive an authentication error
```

**Execution Steps**:

1. **Cucumber reads scenario**
   - Identifies it's a Scenario Outline
   - Reads Examples table
   - Replaces placeholders with values

2. **Step 1: When I authenticate...**
   ```java
   iAuthenticateWithUsernameAndPassword("invalid", "invalid")
   ```
   - Makes HTTP POST request
   - Sends: `{"username":"invalid","password":"invalid"}`
   - Receives: `{"error":"Invalid credentials"}` with status 401
   - Stores response in TestContext

3. **Step 2: Then I should receive...**
   ```java
   iShouldReceiveAnAuthenticationError()
   ```
   - Gets response from TestContext
   - Validates status code = 401 ✅
   - Validates error message exists ✅
   - Test passes ✅

---

## Key Concepts

### 1. **Gherkin Syntax**

- **Feature**: Describes what's being tested
- **Scenario**: Individual test case
- **Scenario Outline**: Template for multiple test cases
- **Given/When/Then**: Test steps
- **Examples**: Test data table

### 2. **Tags**

- **Purpose**: Categorize and filter tests
- **Usage**: `@tag1 @tag2` - Multiple tags per scenario
- **Filtering**: `mvn test -Dcucumber.filter.tags="@tag"`

### 3. **Scenario Outline**

- **Purpose**: Data-driven testing
- **Placeholders**: `<variable>` in steps
- **Examples Table**: Provides test data
- **Execution**: Runs once per row in Examples

### 4. **Step Definitions**

- **Mapping**: Gherkin steps → Java methods
- **Parameters**: `{string}`, `{int}` in Gherkin → Method parameters
- **Implementation**: Actual test logic in Java

---

## Benefits of This Structure

### ✅ **Readability**
- Plain English scenarios
- Non-technical stakeholders can understand
- Self-documenting tests

### ✅ **Maintainability**
- Easy to add new test cases (add row to Examples)
- Clear organization (positive/negative/security)
- Tags for easy filtering

### ✅ **Comprehensive Coverage**
- Positive scenarios (happy path)
- Negative scenarios (error handling)
- Security scenarios (SQL injection, XSS)
- Boundary scenarios (edge cases)

### ✅ **Reusability**
- Step definitions used across scenarios
- Examples table for multiple test cases
- DRY (Don't Repeat Yourself) principle

---

## Summary

The `auth.feature` file provides:

1. **6 Scenarios** covering:
   - ✅ Valid authentication (2 scenarios)
   - ✅ Invalid credentials (13 test cases)
   - ✅ Boundary values (6 test cases)
   - ✅ SQL injection protection (5 test cases)
   - ✅ XSS protection (4 test cases)

2. **30 Total Test Cases** ensuring:
   - Authentication works correctly
   - Invalid inputs are rejected
   - Security vulnerabilities are protected
   - Edge cases are handled

3. **Well-Organized** with:
   - Clear tags for filtering
   - Comprehensive test coverage
   - Security-focused scenarios
   - Easy to understand and maintain

This feature file ensures the Authentication API is **robust, secure, and properly tested**! 🔒✅

