# Configuration Management Best Practices

## 🎯 When to Use Properties Files vs Java Classes

### ✅ **Use Properties Files (.properties) When:**
1. **Environment-specific values** (dev, test, staging, prod)
2. **Sensitive credentials** (passwords, API keys)
3. **Values change frequently** without code changes
4. **CI/CD pipeline integration** (different configs per environment)
5. **Team collaboration** (non-developers can update configs)
6. **External configuration** (can be overridden at runtime)

### ✅ **Use Java Class When:**
1. **Constants that never change** (mathematical constants, fixed URLs)
2. **Simple test projects** with single environment
3. **Compile-time constants** (better performance)
4. **Type safety** is critical
5. **No external configuration needed**

---

## 📊 Comparison

| Aspect | Properties File | Java Class |
|--------|----------------|------------|
| **Environment Support** | ✅ Excellent | ❌ Poor |
| **Security** | ✅ Can externalize secrets | ⚠️ Hardcoded in code |
| **Flexibility** | ✅ Easy to change | ❌ Requires recompilation |
| **CI/CD Integration** | ✅ Easy | ⚠️ Harder |
| **Type Safety** | ⚠️ Strings only | ✅ Type-safe |
| **Performance** | ⚠️ Runtime loading | ✅ Compile-time |
| **Maintainability** | ✅ High | ⚠️ Medium |

---

## 🏆 **Recommended Approach: Hybrid**

**Best Practice**: Use **Properties File** for configurable values + **Java Class** for constants

### Structure:
```
config/
  ├── application.properties (default values)
  ├── application-dev.properties (dev environment)
  ├── application-test.properties (test environment)
  └── application-prod.properties (prod environment)
```

---

## 📝 Implementation Examples

### Option 1: Properties File (Recommended for Test Automation)

**application.properties**
```properties
# API Configuration
api.base.url=https://automationintesting.online
api.booking.endpoint=/api/booking
api.auth.endpoint=/api/auth/login
api.message.endpoint=/api/message
api.health.endpoint=/api/booking/actuator/health

# Authentication
auth.username=admin
auth.password=password

# Timeouts
api.timeout=30000
api.connection.timeout=10000

# Retry Configuration
api.retry.count=3
api.retry.delay=1000
```

**Config.java** (reads from properties)
```java
package com.booking.config;

import java.io.InputStream;
import java.util.Properties;

public class Config {
    private static final Properties properties = new Properties();
    
    static {
        loadProperties();
    }
    
    private static void loadProperties() {
        try (InputStream input = Config.class.getClassLoader()
                .getResourceAsStream("application.properties")) {
            if (input == null) {
                throw new RuntimeException("Unable to find application.properties");
            }
            properties.load(input);
        } catch (Exception e) {
            throw new RuntimeException("Error loading properties", e);
        }
    }
    
    // API URLs
    public static String getBaseUrl() {
        return properties.getProperty("api.base.url");
    }
    
    public static String getBookingEndpoint() {
        return getBaseUrl() + properties.getProperty("api.booking.endpoint");
    }
    
    public static String getAuthEndpoint() {
        return getBaseUrl() + properties.getProperty("api.auth.endpoint");
    }
    
    // Authentication
    public static String getUsername() {
        return properties.getProperty("auth.username");
    }
    
    public static String getPassword() {
        return properties.getProperty("auth.password");
    }
    
    // Timeouts
    public static int getTimeout() {
        return Integer.parseInt(properties.getProperty("api.timeout", "30000"));
    }
}
```

### Option 2: Environment-Specific Properties

**application.properties** (default)
```properties
api.base.url=https://automationintesting.online
auth.username=admin
auth.password=password
```

**application-dev.properties**
```properties
api.base.url=https://dev.automationintesting.online
auth.username=dev_admin
auth.password=dev_password
```

**application-test.properties**
```properties
api.base.url=https://test.automationintesting.online
auth.username=test_admin
auth.password=test_password
```

**Config.java** (loads based on environment)
```java
public class Config {
    private static final Properties properties = new Properties();
    private static final String ENV = System.getProperty("env", "test");
    
    static {
        loadProperties();
    }
    
    private static void loadProperties() {
        // Load default properties
        loadPropertiesFile("application.properties");
        
        // Load environment-specific properties (overrides defaults)
        loadPropertiesFile("application-" + ENV + ".properties");
        
        // System properties override everything
        properties.putAll(System.getProperties());
    }
    
    private static void loadPropertiesFile(String filename) {
        try (InputStream input = Config.class.getClassLoader()
                .getResourceAsStream(filename)) {
            if (input != null) {
                properties.load(input);
            }
        } catch (Exception e) {
            // Ignore if file doesn't exist
        }
    }
    
    // ... getter methods
}
```

**Usage:**
```bash
# Run with test environment
mvn test -Denv=test

# Run with dev environment
mvn test -Denv=dev
```

### Option 3: System Properties Override

**Config.java** (supports system properties)
```java
public class Config {
    private static final Properties properties = new Properties();
    
    static {
        loadProperties();
    }
    
    private static void loadProperties() {
        // Load from properties file
        loadPropertiesFile("application.properties");
        
        // System properties override file properties
        for (String key : System.getProperties().stringPropertyNames()) {
            if (key.startsWith("api.") || key.startsWith("auth.")) {
                properties.setProperty(key, System.getProperty(key));
            }
        }
    }
    
    public static String getBaseUrl() {
        return getProperty("api.base.url", "https://automationintesting.online");
    }
    
    private static String getProperty(String key, String defaultValue) {
        return properties.getProperty(key, defaultValue);
    }
}
```

**Usage:**
```bash
# Override at runtime
mvn test -Dapi.base.url=https://custom-url.com -Dauth.username=custom_user
```

---

## 🔒 Security Best Practices

### ❌ **DON'T** (Hardcoded in Java)
```java
public static final String PASSWORD = "password"; // ❌ Bad!
```

### ✅ **DO** (Externalized)
```properties
# application.properties
auth.password=${AUTH_PASSWORD}
```

**Load from environment variable:**
```java
public static String getPassword() {
    return System.getenv("AUTH_PASSWORD") != null 
        ? System.getenv("AUTH_PASSWORD")
        : properties.getProperty("auth.password");
}
```

**Or use .gitignore for sensitive files:**
```properties
# application-local.properties (not in git)
auth.password=secret_password
```

---

## 📁 Recommended File Structure

```
src/test/resources/
  ├── application.properties          # Default config
  ├── application-dev.properties      # Dev environment
  ├── application-test.properties     # Test environment
  ├── application-prod.properties      # Prod environment
  └── application-local.properties    # Local overrides (gitignored)
```

---

## 🎯 **Recommendation for Your Project**

### For Test Automation Framework:

**✅ Use Properties File** because:
1. You may need different environments (dev, test, prod)
2. Credentials should be externalized
3. Easy to update without recompiling
4. Better for CI/CD pipelines
5. Can override at runtime

**Implementation:**
1. Create `application.properties` in `src/test/resources/`
2. Update `Config.java` to read from properties
3. Support environment-specific configs
4. Allow system property overrides

---

## 📝 Quick Start Implementation

See the improved `Config.java` implementation that:
- ✅ Reads from properties file
- ✅ Supports environment-specific configs
- ✅ Allows system property overrides
- ✅ Falls back to defaults
- ✅ Type-safe getters

