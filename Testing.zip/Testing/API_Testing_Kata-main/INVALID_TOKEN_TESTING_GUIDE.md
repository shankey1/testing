# Testing Invalid Token Scenarios with BookingClientOptimized

## Overview

`BookingClientOptimized` supports three authentication scenarios:
1. **Valid token** - `token = "valid_token_string"`
2. **No token** - `token = null`
3. **Invalid token** - `token = "invalid_token_string"` or `token = "expired_token"`

---

## How It Works

The current implementation handles all three cases:

```java
public Response getBookingById(Integer bookingId, String token) {
    if (token != null) {
        // Sends token as cookie (valid OR invalid - API decides)
        return given()
                .cookie("token", token)
                .when()
                .get(Config.BOOKING_ENDPOINT + "/" + bookingId)
                ...
    } else {
        // No token sent
        return given()
                .when()
                .get(Config.BOOKING_ENDPOINT + "/" + bookingId)
                ...
    }
}
```

**Key Point**: When `token != null`, the method sends whatever token you provide. The API server validates it and returns:
- `200 OK` if token is valid
- `401 Unauthorized` if token is invalid/expired/missing

---

## Testing Invalid Token Scenarios

### Method 1: Pass Invalid Token String Directly

```java
// Test with invalid token
String invalidToken = "invalid_token_12345";
Response response = bookingClient.getBookingById(123, invalidToken);

// Validate unauthorized response
response.then()
    .statusCode(401)
    .body("error", notNullValue());
```

### Method 2: Test Different Invalid Token Types

```java
// Test cases for invalid tokens
String[] invalidTokens = {
    "invalid_token",
    "expired_token",
    "wrong_token",
    "",
    " ",
    "token_with_special_chars!@#",
    "very_long_invalid_token_that_exceeds_normal_length"
};

for (String invalidToken : invalidTokens) {
    Response response = bookingClient.getBookingById(123, invalidToken);
    response.then().statusCode(401);
}
```

### Method 3: Compare Valid vs Invalid

```java
// Valid token (should succeed)
String validToken = authClient.getToken();
Response validResponse = bookingClient.getBookingById(123, validToken);
validResponse.then().statusCode(200);

// Invalid token (should fail)
String invalidToken = "invalid_token";
Response invalidResponse = bookingClient.getBookingById(123, invalidToken);
invalidResponse.then().statusCode(401);
```

---

## Step Definition Examples

### Example 1: Test Invalid Token for GET

```java
@When("I try to get booking with id {int} using invalid token")
public void iTryToGetBookingWithIdUsingInvalidToken(Integer bookingId) {
    String invalidToken = "invalid_token_12345";
    Response response = bookingClient.getBookingById(bookingId, invalidToken);
    testContext.setResponse(response);
}

@Then("I should receive an unauthorized error")
public void iShouldReceiveAnUnauthorizedError() {
    Response response = testContext.getResponse();
    response.then()
            .statusCode(401)
            .body("error", notNullValue());
}
```

### Example 2: Test Invalid Token for UPDATE

```java
@When("I try to update booking with id {int} using invalid token")
public void iTryToUpdateBookingWithIdUsingInvalidToken(Integer bookingId) {
    Booking booking = testContext.getBooking();
    if (booking == null) {
        booking = new BookingBuilder().withDefaultValues().build();
    }
    
    String invalidToken = "expired_token";
    Response response = bookingClient.updateBooking(bookingId, booking, invalidToken);
    testContext.setResponse(response);
}
```

### Example 3: Test Invalid Token for DELETE

```java
@When("I try to delete booking with id {int} using invalid token")
public void iTryToDeleteBookingWithIdUsingInvalidToken(Integer bookingId) {
    String invalidToken = "wrong_token";
    Response response = bookingClient.deleteBooking(bookingId, invalidToken);
    testContext.setResponse(response);
}
```

### Example 4: Test Invalid Token for PATCH

```java
@When("I try to partially update booking with id {int} using invalid token")
public void iTryToPartiallyUpdateBookingWithIdUsingInvalidToken(Integer bookingId) {
    Booking partialUpdate = new Booking();
    partialUpdate.setFirstname("Updated");
    
    String invalidToken = "invalid_token";
    Response response = bookingClient.partialUpdateBooking(bookingId, partialUpdate, invalidToken);
    testContext.setResponse(response);
}
```

---

## Feature File Examples

### Scenario: Test Invalid Token for GET

```gherkin
@regression @read @negative @unauthorized @invalid_token
Scenario: Prevent access when using invalid token to retrieve booking
  Given I have a valid booking
  When I create a booking
  And I try to get booking with id 123 using invalid token
  Then I should receive an unauthorized error
  And the error message should indicate invalid token
```

### Scenario: Test Invalid Token for UPDATE

```gherkin
@regression @update @negative @unauthorized @invalid_token
Scenario: Prevent access when using invalid token to update booking
  Given I have a valid booking
  When I create a booking
  And I try to update booking with id 123 using invalid token
  Then I should receive an unauthorized error
```

### Scenario Outline: Test Multiple Invalid Token Types

```gherkin
@regression @negative @unauthorized @invalid_token
Scenario Outline: Reject requests with various invalid tokens
  Given I have a valid booking
  When I create a booking
  And I try to get booking with id 123 using token "<token>"
  Then I should receive an unauthorized error

  Examples: Invalid Tokens
    | token              | description           |
    | invalid_token     | Plain invalid token   |
    | expired_token     | Expired token         |
    | wrong_token       | Wrong token format    |
    |                   | Empty token           |
    | " "               | Whitespace token      |
    | null              | Null token string     |
```

---

## Complete Test Example

```java
public class InvalidTokenTest {
    private BookingClientOptimized bookingClient;
    private AuthClient authClient;
    
    @Test
    public void testGetBookingWithInvalidToken() {
        // Setup: Get valid token for comparison
        String validToken = authClient.getToken();
        
        // Test 1: Valid token (should succeed)
        Response validResponse = bookingClient.getBookingById(123, validToken);
        validResponse.then().statusCode(200);
        
        // Test 2: Invalid token (should fail)
        String invalidToken = "invalid_token_12345";
        Response invalidResponse = bookingClient.getBookingById(123, invalidToken);
        invalidResponse.then()
                .statusCode(401)
                .body("error", notNullValue());
        
        // Test 3: No token (should fail)
        Response noTokenResponse = bookingClient.getBookingById(123, null);
        noTokenResponse.then().statusCode(401);
    }
    
    @Test
    public void testUpdateBookingWithInvalidToken() {
        Booking booking = new BookingBuilder()
                .withDefaultValues()
                .withFirstName("Updated")
                .build();
        
        String invalidToken = "expired_token";
        Response response = bookingClient.updateBooking(123, booking, invalidToken);
        
        response.then()
                .statusCode(401)
                .body("error", containsString("Unauthorized"));
    }
    
    @Test
    public void testDeleteBookingWithInvalidToken() {
        String invalidToken = "wrong_token";
        Response response = bookingClient.deleteBooking(123, invalidToken);
        
        response.then().statusCode(401);
    }
}
```

---

## Enhanced BookingClientOptimized (Optional)

If you want to make invalid token testing more explicit, you could add helper methods:

```java
// Optional: Helper method for invalid token testing
public Response getBookingByIdWithInvalidToken(Integer bookingId) {
    return getBookingById(bookingId, "invalid_token");
}

// But this is NOT necessary - you can just pass invalid token directly
```

**Recommendation**: Keep it simple. Just pass the invalid token string directly - it's clearer and more flexible.

---

## Summary

### To Test Invalid Token:

1. **Pass invalid token string** to any method:
   ```java
   bookingClient.getBookingById(id, "invalid_token")
   ```

2. **Validate 401 response**:
   ```java
   response.then().statusCode(401)
   ```

3. **Check error message** (if needed):
   ```java
   response.then().body("error", notNullValue())
   ```

### Three Token Scenarios:

| Scenario | Token Value | Expected Response |
|----------|------------|-------------------|
| Valid token | `"valid_token_string"` | 200 OK |
| Invalid token | `"invalid_token"` | 401 Unauthorized |
| No token | `null` | 401 Unauthorized |

---

## Key Takeaways

✅ **Current implementation already supports invalid token testing**
✅ **Just pass invalid token string as parameter**
✅ **API validates and returns 401 if invalid**
✅ **No code changes needed in BookingClientOptimized**
✅ **Works for all operations: GET, PUT, PATCH, DELETE**

The beauty of the Response-First design is that it handles all cases (valid, invalid, null) without needing separate methods!

