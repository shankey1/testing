# @JsonProperty Annotation - Complete Explanation

## 🎯 Why @JsonProperty is Needed

### The Problem: API vs Java Naming Conventions

**API Response (JSON):**
```json
{
  "roomid": 1,
  "firstname": "John",
  "lastname": "Doe",
  "depositpaid": true,
  "bookingdates": {
    "checkin": "2025-01-15",
    "checkout": "2025-01-20"
  }
}
```

**Java Best Practice (camelCase):**
```java
private Integer roomId;        // ✅ camelCase
private String firstName;     // ✅ camelCase
private String lastName;      // ✅ camelCase
private Boolean depositPaid;  // ✅ camelCase
```

**The Mismatch:**
- API uses: `roomid`, `firstname`, `lastname` (lowercase, no camelCase)
- Java uses: `roomId`, `firstName`, `lastName` (camelCase)

**Solution:** `@JsonProperty` maps between them!

---

## 📊 What Happens With and Without @JsonProperty

### ❌ **Without @JsonProperty** (Field Name Mismatch)

```java
public class Booking {
    private Integer roomId;      // Java: roomId
    private String firstName;    // Java: firstName
}
```

**API Response:**
```json
{
  "roomid": 1,        // API: roomid (lowercase)
  "firstname": "John"  // API: firstname (lowercase)
}
```

**Result:** ❌ **Jackson can't map the fields!**
- Jackson looks for `roomId` in JSON → finds `roomid` → **mismatch!**
- Jackson looks for `firstName` in JSON → finds `firstname` → **mismatch!**
- Fields remain `null` → **deserialization fails!**

### ✅ **With @JsonProperty** (Field Name Mapping)

```java
public class Booking {
    @JsonProperty("roomid")
    private Integer roomId;      // Java: roomId → maps to JSON: "roomid"
    
    @JsonProperty("firstname")
    private String firstName;    // Java: firstName → maps to JSON: "firstname"
}
```

**API Response:**
```json
{
  "roomid": 1,        // Maps to roomId
  "firstname": "John" // Maps to firstName
}
```

**Result:** ✅ **Jackson maps correctly!**
- `@JsonProperty("roomid")` tells Jackson: "When you see `roomid` in JSON, map it to `roomId` field"
- `@JsonProperty("firstname")` tells Jackson: "When you see `firstname` in JSON, map it to `firstName` field"
- Fields are populated correctly → **deserialization succeeds!**

---

## 🔄 How @JsonProperty Works

### Serialization (Java Object → JSON)

```java
Booking booking = new Booking();
booking.setRoomId(1);
booking.setFirstName("John");

// Jackson serializes using @JsonProperty
// Output JSON:
{
  "roomid": 1,      // Uses @JsonProperty value, not field name
  "firstname": "John"
}
```

### Deserialization (JSON → Java Object)

```json
{
  "roomid": 1,
  "firstname": "John"
}
```

```java
// Jackson deserializes using @JsonProperty
Booking booking = response.as(Booking.class);
// booking.getRoomId() = 1 ✅
// booking.getFirstName() = "John" ✅
```

---

## 🌍 Real-World Examples

### Example 1: Legacy API with Non-Standard Naming

**Scenario:** Working with a legacy API that uses snake_case or lowercase

**API Response:**
```json
{
  "user_id": 123,
  "first_name": "John",
  "last_name": "Doe",
  "created_at": "2025-01-15"
}
```

**Java Model:**
```java
@Data
public class User {
    @JsonProperty("user_id")
    private Long userId;           // Maps user_id → userId
    
    @JsonProperty("first_name")
    private String firstName;      // Maps first_name → firstName
    
    @JsonProperty("last_name")
    private String lastName;       // Maps last_name → lastName
    
    @JsonProperty("created_at")
    private LocalDateTime createdAt; // Maps created_at → createdAt
}
```

**Why needed:** API uses snake_case, Java uses camelCase

---

### Example 2: Third-Party API with Different Conventions

**Scenario:** Integrating with external API (e.g., payment gateway)

**Stripe API Response:**
```json
{
  "customer_id": "cus_123",
  "payment_method": "card",
  "amount_total": 1000,
  "currency_code": "USD"
}
```

**Java Model:**
```java
@Data
public class Payment {
    @JsonProperty("customer_id")
    private String customerId;
    
    @JsonProperty("payment_method")
    private String paymentMethod;
    
    @JsonProperty("amount_total")
    private Integer amountTotal;
    
    @JsonProperty("currency_code")
    private String currencyCode;
}
```

**Why needed:** Third-party APIs often use different naming conventions

---

### Example 3: Your Current Booking API

**API Response (from OpenAPI spec):**
```json
{
  "roomid": 1,
  "firstname": "John",
  "lastname": "Doe",
  "depositpaid": true,
  "bookingdates": {
    "checkin": "2025-01-15",
    "checkout": "2025-01-20"
  }
}
```

**Your Java Model:**
```java
@Data
public class Booking {
    @JsonProperty("roomid")
    private Integer roomId;        // roomid → roomId
    
    @JsonProperty("firstname")
    private String firstName;      // firstname → firstName
    
    @JsonProperty("lastname")
    private String lastName;       // lastname → lastName
    
    @JsonProperty("depositpaid")
    private Boolean depositPaid;   // depositpaid → depositPaid
    
    @JsonProperty("bookingdates")
    private BookingDates bookingDates; // bookingdates → bookingDates
}
```

**Why needed:** API uses lowercase, Java uses camelCase

---

## 🤔 Can We Just Use Variables Without @JsonProperty?

### Option 1: Match API Field Names Exactly (❌ Not Recommended)

```java
public class Booking {
    private Integer roomid;      // ❌ Not camelCase (bad Java practice)
    private String firstname;    // ❌ Not camelCase (bad Java practice)
    private String lastname;     // ❌ Not camelCase (bad Java practice)
}
```

**Problems:**
- ❌ Violates Java naming conventions
- ❌ Code review will reject it
- ❌ Hard to read and maintain
- ❌ Doesn't follow best practices

### Option 2: Use @JsonProperty (✅ Recommended)

```java
public class Booking {
    @JsonProperty("roomid")
    private Integer roomId;      // ✅ camelCase (good Java practice)
    
    @JsonProperty("firstname")
    private String firstName;    // ✅ camelCase (good Java practice)
}
```

**Benefits:**
- ✅ Follows Java naming conventions
- ✅ Clean, readable code
- ✅ Maps correctly to API
- ✅ Best practice

---

## 📝 When @JsonProperty is NOT Needed

### Case 1: Field Names Match Exactly

**API Response:**
```json
{
  "email": "john@example.com",
  "phone": "1234567890"
}
```

**Java Model:**
```java
public class Booking {
    private String email;  // ✅ No @JsonProperty needed (names match)
    private String phone;  // ✅ No @JsonProperty needed (names match)
}
```

**Why:** Field names already match, Jackson maps automatically

### Case 2: Using Jackson Naming Strategy

**Configuration:**
```java
ObjectMapper mapper = new ObjectMapper();
mapper.setPropertyNamingStrategy(PropertyNamingStrategies.SNAKE_CASE);
```

**Java Model:**
```java
public class User {
    private Long userId;      // Automatically maps to "user_id"
    private String firstName; // Automatically maps to "first_name"
}
```

**Why:** Global naming strategy handles mapping

---

## 🎯 Summary

### When to Use @JsonProperty:

1. ✅ **API uses different naming convention** (snake_case, lowercase, kebab-case)
2. ✅ **Java uses camelCase** (best practice)
3. ✅ **Field names don't match** between API and Java
4. ✅ **Legacy API integration** with non-standard naming

### When NOT Needed:

1. ✅ Field names match exactly
2. ✅ Using global naming strategy
3. ✅ API follows Java naming conventions

---

## 🔍 Your Current Code Analysis

### Fields That NEED @JsonProperty:

```java
@JsonProperty("roomid")      // API: roomid → Java: roomId
private Integer roomId;

@JsonProperty("firstname")   // API: firstname → Java: firstName
private String firstName;

@JsonProperty("bookingid")   // API: bookingid → Java: bookingId
private Integer bookingId;
```

**Reason:** API uses lowercase, Java uses camelCase

### Fields That DON'T Need @JsonProperty:

```java
@JsonProperty("email")      // Could be removed (names match)
private String email;

@JsonProperty("phone")      // Could be removed (names match)
private String phone;
```

**Reason:** Field names already match, but keeping it is fine for consistency

---

## 💡 Best Practice Recommendation

**Keep @JsonProperty for ALL fields** because:
1. ✅ **Explicit is better than implicit** (readability)
2. ✅ **Consistency** across all fields
3. ✅ **Future-proof** if API changes
4. ✅ **Self-documenting** code (shows API field names)

---

## 🧪 Test It Yourself

### Test Without @JsonProperty:

```java
// Remove @JsonProperty
public class Booking {
    private Integer roomId;  // No annotation
}

// API returns: {"roomid": 1}
// Result: roomId = null ❌ (mismatch!)
```

### Test With @JsonProperty:

```java
// With @JsonProperty
public class Booking {
    @JsonProperty("roomid")
    private Integer roomId;  // With annotation
}

// API returns: {"roomid": 1}
// Result: roomId = 1 ✅ (mapped correctly!)
```

---

## ✅ Conclusion

**@JsonProperty is essential when:**
- API field names ≠ Java field names
- API uses non-standard naming (lowercase, snake_case)
- You want to follow Java camelCase conventions

**In your case:** The API uses lowercase (`roomid`, `firstname`) while Java uses camelCase (`roomId`, `firstName`), so `@JsonProperty` is **required** for proper mapping!

