# Step-by-Step Guide: API Testing Framework

This guide explains the entire test framework step-by-step, from project structure to execution.

---

## Step 1: Understanding the Project Structure

### 1.1 Project Layout
```
API_Testing_Kata-main/
├── pom.xml                                    # Maven configuration
├── src/
│   └── test/
│       ├── java/
│       │   └── com/booking/
│       │       ├── TestRunner.java           # Test execution entry point
│       │       ├── api/                       # API client classes
│       │       │   ├── AuthClient.java
│       │       │   └── BookingClient.java
│       │       ├── config/                    # Configuration
│       │       │   └── Config.java
│       │       ├── models/                    # Data models (POJOs)
│       │       │   ├── Booking.java
│       │       │   ├── BookingDates.java
│       │       │   ├── AuthRequest.java
│       │       │   └── ...
│       │       ├── stepdefinitions/           # Cucumber step definitions
│       │       │   ├── BookingStepDefinitions.java
│       │       │   ├── AuthStepDefinitions.java
│       │       │   └── GetMessages.java
│       │       ├── hooks/                    # Cucumber hooks
│       │       │   └── Hooks.java
│       │       └── utils/                    # Utility classes
│       │           ├── BookingBuilder.java
│       │           └── TestContext.java
│       └── resources/
│           ├── features/                     # Feature files (Gherkin)
│           │   ├── booking.feature
│           │   ├── auth.feature
│           │   └── messages.feature
│           └── spec/
│               └── booking.yaml              # API specification
```

### 1.2 Key Components Explained

**TestRunner.java**: Entry point that:
- Uses JUnit Platform Suite
- Scans for Cucumber tests in `com.booking` package
- Reads feature files from `features` directory
- Generates HTML and JSON reports

**Feature Files**: Written in Gherkin syntax:
- Define test scenarios in plain English
- Use tags to categorize tests
- Contain step definitions that map to Java code

**Step Definitions**: Java classes that:
- Implement the actual test logic
- Map Gherkin steps to API calls
- Perform assertions and validations

**API Clients**: Encapsulate API calls:
- `BookingClient`: Handles booking CRUD operations
- `AuthClient`: Handles authentication

**Models**: POJO classes representing:
- Request/response data structures
- Used for JSON serialization/deserialization

---

## Step 2: Understanding Tags and Test Identification

### 2.1 What are Tags?

Tags are labels attached to scenarios in feature files. They allow you to:
- Group related tests
- Filter which tests to run
- Categorize tests (sanity, regression, positive, negative, etc.)

### 2.2 Tag Syntax

Tags are placed **above** the scenario:
```gherkin
@sanity @regression @create @positive
Scenario Outline: Create booking with valid data combinations
  Given I have a booking...
  When I create a booking...
  Then the booking should be created successfully
```

### 2.3 How Tags Work

1. **Multiple Tags**: A scenario can have multiple tags
   ```gherkin
   @sanity @regression @create @positive
   ```
   This scenario will run when you filter by:
   - `@sanity` OR `@regression` OR `@create` OR `@positive`

2. **Tag Combinations**: Use AND/OR logic
   ```bash
   # Run tests with BOTH tags
   @sanity and @booking
   
   # Run tests with EITHER tag
   @sanity or @regression
   ```

3. **Tag Exclusion**: Use NOT to exclude
   ```bash
   # All tests EXCEPT regression
   not @regression
   ```

---

## Step 3: Sanity vs Regression Test Identification

### 3.1 Sanity Tests (Quick Validation)

**Purpose**: Verify critical functionality works after deployment  
**Execution Time**: 2-3 minutes  
**Count**: ~9 scenarios

**How to Identify**:
- Look for `@sanity` tag in feature files
- These are critical path tests
- Usually have `@critical` tag as well

**Example**:
```gherkin
@sanity @regression @health @positive @critical
Scenario: Health check returns UP status
  When I check the health of the booking API
  Then the health check should return status "UP"
```

**Sanity Test List**:
1. ✅ Health check
2. ✅ Create booking (basic)
3. ✅ Read booking (get by ID)
4. ✅ Update booking (full update)
5. ✅ Partial update booking
6. ✅ Delete booking
7. ✅ Invalid email validation
8. ✅ Login with valid credentials
9. ✅ Get messages

### 3.2 Regression Tests (Comprehensive Coverage)

**Purpose**: Verify all functionality works  
**Execution Time**: 15-20 minutes  
**Count**: ~100+ scenarios

**How to Identify**:
- Look for `@regression` tag in feature files
- Includes all test types: positive, negative, boundary, security

**Example**:
```gherkin
@regression @create @validation @negative
Scenario Outline: Create booking with invalid firstname
  Given I have a booking with firstname "<firstname>"...
  When I create a booking
  Then I should receive a validation error
```

**Regression Test Coverage**:
- ✅ All CRUD operations with multiple data combinations
- ✅ Boundary value testing
- ✅ All validation scenarios
- ✅ Negative test scenarios
- ✅ Unauthorized access scenarios
- ✅ Security testing (SQL injection, XSS)
- ✅ Edge cases

---

## Step 4: How Tests Are Executed

### 4.1 Test Execution Flow

```
1. TestRunner.java is invoked
   ↓
2. JUnit Platform Suite scans for Cucumber tests
   ↓
3. Cucumber reads feature files from resources/features/
   ↓
4. Cucumber filters scenarios based on tags (if specified)
   ↓
5. For each scenario, Cucumber finds matching step definitions
   ↓
6. Step definitions execute Java code (API calls, assertions)
   ↓
7. Results are collected and reports generated
```

### 4.2 Step Definition Mapping

**Feature File (Gherkin)**:
```gherkin
When I create a booking
Then the booking should be created successfully
```

**Step Definition (Java)**:
```java
@When("I create a booking")
public void iCreateABooking() {
    Booking booking = testContext.getBooking();
    Response response = bookingClient.createBookingWithResponse(booking);
    testContext.setResponse(response);
    // ... more code
}

@Then("the booking should be created successfully")
public void theBookingShouldBeCreatedSuccessfully() {
    CreateBookingResponse createResponse = testContext.getCreateBookingResponse();
    assertNotNull(createResponse, "Create booking response should not be null");
    // ... more assertions
}
```

**How Mapping Works**:
1. Cucumber reads the Gherkin step: `"I create a booking"`
2. Searches for `@When` annotation with matching text
3. Executes the Java method
4. Repeats for next step

---

## Step 5: Running Tests - Step by Step

### 5.1 Prerequisites

1. **Java 17** installed
2. **Maven** installed
3. **Internet connection** (tests hit real API)

### 5.2 Running All Tests

**Command**:
```bash
mvn test
```

**What Happens**:
1. Maven compiles Java code
2. Runs TestRunner.java
3. Executes ALL scenarios in all feature files
4. Generates reports in `target/` directory

**Output**:
- Console output showing test progress
- HTML report: `target/cucumber-reports.html`
- JSON report: `target/cucumber.json`

### 5.3 Running Sanity Tests Only

**Command**:
```bash
mvn test -Dcucumber.filter.tags="@sanity"
```

**What Happens**:
1. Maven compiles code
2. Cucumber reads feature files
3. **Filters** scenarios with `@sanity` tag
4. Executes only those scenarios (~9 tests)
5. Generates reports

**Example Output**:
```
Running: Health check returns UP status
Running: Create booking with valid data (John Doe)
Running: Get booking by ID
Running: Update booking
Running: Delete booking
Running: Login with valid credentials
Running: Get messages
...
9 scenarios passed
```

### 5.4 Running Regression Tests Only

**Command**:
```bash
mvn test -Dcucumber.filter.tags="@regression"
```

**What Happens**:
1. Maven compiles code
2. Cucumber reads feature files
3. **Filters** scenarios with `@regression` tag
4. Executes all regression scenarios (~100+ tests)
5. Generates reports

**Example Output**:
```
Running: Create booking with valid data (John Doe)
Running: Create booking with valid data (Jane Smith)
Running: Create booking with boundary values...
Running: Create booking with invalid firstname...
... (100+ scenarios)
```

### 5.5 Running Specific Feature Tests

**Command**:
```bash
# Only booking tests
mvn test -Dcucumber.filter.tags="@booking"

# Only authentication tests
mvn test -Dcucumber.filter.tags="@auth"

# Only message tests
mvn test -Dcucumber.filter.tags="@message"
```

### 5.6 Running Tests with Multiple Tags

**Command**:
```bash
# Sanity tests for booking only
mvn test -Dcucumber.filter.tags="@sanity and @booking"

# Regression tests for authentication
mvn test -Dcucumber.filter.tags="@regression and @auth"

# Positive tests only
mvn test -Dcucumber.filter.tags="@positive"

# Negative tests only
mvn test -Dcucumber.filter.tags="@negative"
```

### 5.7 Excluding Tests

**Command**:
```bash
# All tests except regression
mvn test -Dcucumber.filter.tags="not @regression"

# All tests except negative
mvn test -Dcucumber.filter.tags="not @negative"
```

---

## Step 6: Understanding a Complete Test Flow

### 6.1 Example: Create Booking Test

**Step 1: Feature File** (`booking.feature`)
```gherkin
@sanity @regression @create @positive
Scenario Outline: Create booking with valid data combinations
  Given I have a booking with firstname "<firstname>", lastname "<lastname>"...
  When I create a booking
  Then the booking should be created successfully
  And the booking should have booking id

  Examples:
    | firstname | lastname | email                  |
    | John      | Doe      | john.doe@example.com   |
```

**Step 2: Step Definition** (`BookingStepDefinitions.java`)
```java
@Given("I have a booking with firstname {string}, lastname {string}...")
public void iHaveABookingWithAllFields(String firstname, String lastname, ...) {
    Booking booking = new BookingBuilder()
        .withFirstName(firstname)
        .withLastName(lastname)
        .withEmail(email)
        // ... build booking
        .build();
    testContext.setBooking(booking);
}

@When("I create a booking")
public void iCreateABooking() {
    Booking booking = testContext.getBooking();
    Response response = bookingClient.createBookingWithResponse(booking);
    testContext.setResponse(response);
    // Store response in context
}

@Then("the booking should be created successfully")
public void theBookingShouldBeCreatedSuccessfully() {
    CreateBookingResponse createResponse = testContext.getCreateBookingResponse();
    assertNotNull(createResponse, "Response should not be null");
    assertNotNull(createResponse.getBookingid(), "Booking ID should not be null");
}
```

**Step 3: API Client** (`BookingClient.java`)
```java
public Response createBookingWithResponse(Booking booking) {
    return given()
        .contentType(ContentType.JSON)
        .body(booking)
        .when()
        .post(Config.BOOKING_ENDPOINT)
        .then()
        .extract()
        .response();
}
```

**Step 4: Execution Flow**
```
1. Cucumber reads scenario
2. Executes @Given step → Creates booking object
3. Executes @When step → Calls API via BookingClient
4. API returns response
5. Executes @Then step → Validates response
6. Test passes/fails based on assertions
```

---

## Step 7: Viewing Test Results

### 7.1 Console Output

When you run tests, you'll see:
```
Scenario: Create booking with valid data combinations
  Given I have a booking with firstname "John"...
  When I create a booking
  Then the booking should be created successfully
  ✓ PASSED

1 scenario (1 passed)
```

### 7.2 HTML Report

**Location**: `target/cucumber-reports.html`

**How to View**:
```bash
# On Mac/Linux
open target/cucumber-reports.html

# On Windows
start target/cucumber-reports.html
```

**Report Contains**:
- Test summary (passed/failed/skipped)
- Detailed scenario results
- Step-by-step execution details
- Screenshots (if configured)
- Duration for each test

### 7.3 JSON Report

**Location**: `target/cucumber.json`

**Use Cases**:
- Integration with CI/CD tools
- Custom report generation
- Test result analysis

---

## Step 8: Common Workflows

### 8.1 Daily Development Workflow

```bash
# 1. Make code changes
# 2. Run sanity tests to verify critical functionality
mvn test -Dcucumber.filter.tags="@sanity"

# 3. If sanity passes, run full regression
mvn test -Dcucumber.filter.tags="@regression"

# 4. View results
open target/cucumber-reports.html
```

### 8.2 CI/CD Pipeline Workflow

```yaml
# Example CI/CD steps
1. Pre-commit: Run sanity tests
   mvn test -Dcucumber.filter.tags="@sanity"

2. Pull Request: Run sanity + critical regression
   mvn test -Dcucumber.filter.tags="@sanity or (@regression and @critical)"

3. Nightly Build: Run full regression
   mvn test -Dcucumber.filter.tags="@regression"

4. Release Build: Run all tests
   mvn test
```

### 8.3 Debugging Failed Tests

```bash
# 1. Run specific failing test
mvn test -Dcucumber.filter.tags="@create and @positive"

# 2. Check console output for errors
# 3. Review HTML report for details
open target/cucumber-reports.html

# 4. Check API logs (if available)
# 5. Verify test data and API responses
```

---

## Step 9: Tag Reference Guide

### 9.1 Suite Tags
- `@sanity` - Quick validation tests
- `@regression` - Comprehensive tests

### 9.2 Feature Tags
- `@booking` - Booking API tests
- `@auth` - Authentication API tests
- `@message` - Messages API tests

### 9.3 Operation Tags
- `@create` - Create operations
- `@read` - Read operations
- `@update` - Update operations
- `@delete` - Delete operations
- `@partial` - Partial update operations

### 9.4 Test Type Tags
- `@positive` - Positive test scenarios
- `@negative` - Negative test scenarios
- `@validation` - Validation test scenarios
- `@boundary` - Boundary value tests
- `@unauthorized` - Unauthorized access tests
- `@security` - Security tests
- `@critical` - Critical path tests

### 9.5 Special Tags
- `@sql_injection` - SQL injection test scenarios
- `@xss` - XSS attack test scenarios
- `@health` - Health check tests
- `@dates` - Date-related tests

---

## Step 10: Troubleshooting

### 10.1 Tests Not Running

**Problem**: No tests execute
**Solution**:
```bash
# Check if feature files are in correct location
ls src/test/resources/features/

# Check if step definitions are in correct package
ls src/test/java/com/booking/stepdefinitions/

# Verify TestRunner configuration
cat src/test/java/com/booking/TestRunner.java
```

### 10.2 Tag Filter Not Working

**Problem**: Wrong tests are running
**Solution**:
```bash
# Verify tag syntax (no spaces, case-sensitive)
# Correct: @sanity
# Wrong: @ sanity or @Sanity

# Check tag placement (must be above scenario)
# Correct:
@sanity
Scenario: Test

# Wrong:
Scenario: Test @sanity
```

### 10.3 API Connection Issues

**Problem**: Tests fail with connection errors
**Solution**:
```bash
# Check internet connection
ping automationintesting.online

# Verify API is accessible
curl https://automationintesting.online/api/booking/actuator/health

# Check Config.java for correct URLs
cat src/test/java/com/booking/config/Config.java
```

### 10.4 Compilation Errors

**Problem**: Maven build fails
**Solution**:
```bash
# Clean and rebuild
mvn clean test

# Check Java version (must be 17)
java -version

# Verify Maven is working
mvn -version
```

---

## Summary

1. **Project Structure**: Organized with models, API clients, step definitions, and feature files
2. **Tags**: Used to categorize and filter tests (`@sanity`, `@regression`, etc.)
3. **Test Execution**: Run via Maven with tag filters
4. **Reports**: Generated in `target/` directory (HTML and JSON)
5. **Workflow**: Sanity for quick checks, regression for comprehensive testing

This framework provides a scalable, maintainable approach to API testing with clear separation between test definitions (Gherkin) and implementation (Java).

