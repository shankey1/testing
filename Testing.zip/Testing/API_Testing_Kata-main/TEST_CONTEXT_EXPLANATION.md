# TestContext Explained - Step by Step

## What is TestContext?

**TestContext** is a **shared data storage** mechanism that allows different step definitions to share data during a test scenario execution. It's like a "memory box" that stores information created in one step and makes it available to other steps in the same scenario.

---

## Why Do We Need TestContext?

### Problem Without TestContext

In Cucumber, each step definition method is a **separate Java method**. By default, they **cannot share variables** directly.

**Example Problem**:
```java
// Step 1: Create booking
@When("I create a booking")
public void iCreateABooking() {
    Booking booking = new Booking();  // Local variable
    CreateBookingResponse response = bookingClient.createBooking(booking);
    Integer bookingId = response.getBookingid();  // Local variable - LOST!
}

// Step 2: Get booking by ID
@When("I get the booking by id")
public void iGetTheBookingById() {
    // ❌ PROBLEM: bookingId is not accessible here!
    // It was created in the previous method and is now gone
    Booking booking = bookingClient.getBookingById(bookingId, token);  // ERROR!
}
```

### Solution With TestContext

TestContext acts as a **shared storage** that persists data across all step definitions in the same scenario.

**Example Solution**:
```java
// Step 1: Create booking
@When("I create a booking")
public void iCreateABooking() {
    Booking booking = testContext.getBooking();  // Get from context
    CreateBookingResponse response = bookingClient.createBooking(booking);
    testContext.setBookingId(response.getBookingid());  // Store in context
}

// Step 2: Get booking by ID
@When("I get the booking by id")
public void iGetTheBookingById() {
    Integer bookingId = testContext.getBookingId();  // ✅ Get from context
    String token = testContext.getAuthToken();      // ✅ Get from context
    Booking booking = bookingClient.getBookingById(bookingId, token);
    testContext.setBooking(booking);  // Store result in context
}
```

---

## How TestContext Works

### 1. Singleton Pattern with ThreadLocal

TestContext uses **Singleton Pattern** with **ThreadLocal** to ensure:
- **One instance per thread** (important for parallel test execution)
- **Thread-safe** (each test runs in its own thread)
- **Isolated** (tests don't interfere with each other)

```java
public class TestContext {
    // ThreadLocal ensures each thread has its own instance
    private static final ThreadLocal<TestContext> instance = new ThreadLocal<>();
    
    // Private constructor - prevents direct instantiation
    private TestContext() {
        contextData = new HashMap<>();
    }
    
    // Get singleton instance (creates if doesn't exist)
    public static TestContext getInstance() {
        if (instance.get() == null) {
            instance.set(new TestContext());
        }
        return instance.get();
    }
}
```

### 2. Lifecycle Management

**Initialization**: Created before each scenario (via Hooks)
```java
@Before
public void setUp() {
    TestContext.getInstance();  // Initialize context
}
```

**Cleanup**: Reset after each scenario (via Hooks)
```java
@After
public void tearDown() {
    TestContext.reset();  // Clear context for next scenario
}
```

---

## What Data Does TestContext Store?

### Stored Data Types

```java
public class TestContext {
    private Response response;                    // API response
    private String authToken;                     // Authentication token
    private Booking booking;                      // Booking object
    private CreateBookingResponse createBookingResponse;  // Create response
    private Integer bookingId;                    // Booking ID
    private Map<String, Object> contextData;      // Generic key-value storage
}
```

### Data Flow Example

Let's trace a complete scenario:

```gherkin
Scenario: Create and retrieve booking
  Given I am authenticated with valid credentials
  And I have a valid booking
  When I create a booking
  And I get the booking by id
  Then the booking should be retrieved successfully
```

**Step-by-Step Data Flow**:

```
Step 1: "I am authenticated with valid credentials"
  → authClient.getToken()
  → testContext.setAuthToken("abc123token")
  → Context: { authToken: "abc123token" }

Step 2: "I have a valid booking"
  → BookingBuilder creates booking
  → testContext.setBooking(booking)
  → Context: { authToken: "abc123token", booking: {...} }

Step 3: "I create a booking"
  → booking = testContext.getBooking()  // Get from context
  → bookingClient.createBooking(booking)
  → response = { bookingid: 10, booking: {...} }
  → testContext.setBookingId(10)
  → testContext.setCreateBookingResponse(response)
  → Context: { authToken: "abc123token", booking: {...}, bookingId: 10, createBookingResponse: {...} }

Step 4: "I get the booking by id"
  → bookingId = testContext.getBookingId()  // Get from context
  → token = testContext.getAuthToken()     // Get from context
  → bookingClient.getBookingById(10, "abc123token")
  → testContext.setBooking(retrievedBooking)
  → Context: { authToken: "abc123token", booking: {retrieved}, bookingId: 10, ... }

Step 5: "the booking should be retrieved successfully"
  → booking = testContext.getBooking()  // Get from context
  → assertNotNull(booking)
```

---

## Real Examples from Code

### Example 1: Creating a Booking

**Feature File**:
```gherkin
Given I have a valid booking
When I create a booking
Then the booking should be created successfully
```

**Step Definitions**:

```java
@Given("I have a valid booking")
public void iHaveAValidBooking() {
    // Create booking object
    Booking booking = new BookingBuilder()
            .withDefaultValues()
            .build();
    
    // Store in TestContext
    testContext.setBooking(booking);
    // Now other steps can access this booking
}

@When("I create a booking")
public void iCreateABooking() {
    // Retrieve booking from TestContext
    Booking booking = testContext.getBooking();
    
    // Make API call
    Response response = bookingClient.createBookingWithResponse(booking);
    testContext.setResponse(response);
    
    // Extract and store booking ID
    if (response.getStatusCode() == 200) {
        CreateBookingResponse createResponse = response.as(CreateBookingResponse.class);
        testContext.setCreateBookingResponse(createResponse);
        testContext.setBookingId(createResponse.getBookingid());
    }
}

@Then("the booking should be created successfully")
public void theBookingShouldBeCreatedSuccessfully() {
    // Retrieve data from TestContext
    CreateBookingResponse createResponse = testContext.getCreateBookingResponse();
    
    // Validate
    assertNotNull(createResponse, "Response should not be null");
    assertNotNull(createResponse.getBookingid(), "Booking ID should not be null");
}
```

### Example 2: Update Booking (Using Previous Data)

**Feature File**:
```gherkin
Given I have a valid booking
When I create a booking
And I have a booking with firstname "Updated" and lastname "Name"
And I update the booking
Then the booking should have firstname "Updated"
```

**Step Definitions**:

```java
@When("I update the booking")
public void iUpdateTheBooking() {
    // Get booking ID from previous step
    Integer bookingId = testContext.getBookingId();
    
    // Get updated booking object (set in previous step)
    Booking booking = testContext.getBooking();
    
    // Get auth token from context
    String token = testContext.getAuthToken();
    
    if (token == null) {
        token = authClient.getToken();
        testContext.setAuthToken(token);
    }
    
    // Make API call
    Booking updatedBooking = bookingClient.updateBooking(bookingId, booking, token);
    
    // Store updated booking back to context
    testContext.setBooking(updatedBooking);
}

@Then("the booking should have firstname {string}")
public void theBookingShouldHaveFirstname(String expectedFirstname) {
    // Get updated booking from context
    Booking booking = testContext.getBooking();
    
    // Validate
    assertEquals(expectedFirstname, booking.getFirstname());
}
```

### Example 3: Authentication Token Sharing

**Feature File**:
```gherkin
Background:
  Given I am authenticated with valid credentials

Scenario: Get booking by ID
  Given I have a valid booking
  When I create a booking
  And I get the booking by id
```

**Step Definitions**:

```java
// Background step - runs before each scenario
@Given("I am authenticated with valid credentials")
public void iAmAuthenticatedWithValidCredentials() {
    String token = authClient.getToken();
    testContext.setAuthToken(token);  // Store token
    // Now ALL steps in this scenario can use this token
}

@When("I get the booking by id")
public void iGetTheBookingById() {
    Integer bookingId = testContext.getBookingId();
    String token = testContext.getAuthToken();  // Get token from context
    
    // Use token for authenticated API call
    Booking booking = bookingClient.getBookingById(bookingId, token);
    testContext.setBooking(booking);
}
```

---

## Key Benefits of TestContext

### 1. **Data Sharing Across Steps**
- Store data in one step, use in another
- No need to pass parameters between steps

### 2. **Thread Safety**
- Each test thread has its own context
- Parallel test execution is safe

### 3. **Clean Separation**
- Step definitions don't need to know about each other
- Each step focuses on its own responsibility

### 4. **Flexible Storage**
- Store any type of data
- Generic `contextData` map for custom data

### 5. **Automatic Cleanup**
- Context is reset after each scenario
- No data leakage between tests

---

## Common Patterns

### Pattern 1: Store → Retrieve → Use

```java
// Step 1: Store
testContext.setBooking(booking);

// Step 2: Retrieve and use
Booking booking = testContext.getBooking();
bookingClient.updateBooking(booking);
```

### Pattern 2: Chain Operations

```java
// Create booking
testContext.setBookingId(createResponse.getBookingid());

// Later: Use booking ID
Integer id = testContext.getBookingId();
bookingClient.getBookingById(id, token);
```

### Pattern 3: Conditional Storage

```java
// Check if token exists, if not, get and store
String token = testContext.getAuthToken();
if (token == null) {
    token = authClient.getToken();
    testContext.setAuthToken(token);
}
```

### Pattern 4: Generic Data Storage

```java
// Store any custom data
testContext.setContextData("customKey", customObject);

// Retrieve later
Object data = testContext.getContextData("customKey");
```

---

## Important Points to Remember

### ✅ DO:
- Use TestContext to share data between steps
- Reset context after each scenario (handled by Hooks)
- Store all relevant test data in context
- Use meaningful getter/setter names

### ❌ DON'T:
- Don't create new TestContext instances (use `getInstance()`)
- Don't forget to store data after API calls
- Don't assume data exists (check for null if needed)
- Don't share context between scenarios (it's automatically reset)

---

## Summary

**TestContext** is:
- ✅ A **shared storage** for test data
- ✅ **Thread-safe** (one per thread)
- ✅ **Automatically managed** (created/reset by Hooks)
- ✅ **Essential** for multi-step scenarios
- ✅ **Simple to use** (get/set methods)

**Without TestContext**: Steps cannot share data  
**With TestContext**: Steps can easily share data across the entire scenario

This makes it possible to write complex, multi-step test scenarios where each step builds upon the previous one!

