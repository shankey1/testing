# Test Coverage Summary - Based on API Specification

This document outlines the test cases covered in the feature files, aligned with the API specification defined in `booking.yaml`.

## API Endpoints Covered

### 1. Health Check - `GET /booking/actuator/health`
**Specification**: Returns 200 with status "UP"

**Test Coverage**:
- ✅ Verify API health status returns "UP"

---

### 2. Create Booking - `POST /booking`
**Specification**: 
- Success: 200 with bookingid and booking object
- Validation Errors: 400 with errors array

**Test Coverage**:
- ✅ Successfully create booking with valid information
- ✅ Reject booking when firstname validation fails (size must be between 3 and 18)
- ✅ Reject booking when lastname validation fails (size must be between 3 and 18)
- ✅ Reject booking when email format is invalid (must be a well-formed email address)
- ✅ Reject booking when phone validation fails (size must be between 11 and 21)
- ✅ Reject booking when checkout date is before checkin date (Failed to create booking)

**Validation Rules from Spec**:
- firstname: size must be between 3 and 18
- lastname: size must be between 3 and 18
- phone: size must be between 11 and 21
- email: must be a well-formed email address
- bookingdates: checkout must be after checkin

---

### 3. Get Booking - `GET /booking/{id}`
**Specification**:
- Success: 200 with booking object (requires authentication)
- Unauthorized: 401 with error message

**Test Coverage**:
- ✅ Successfully retrieve booking details by ID (with authentication)
- ✅ Prevent unauthorized access when retrieving booking (401 error)

---

### 4. Update Booking - `PUT /booking/{id}`
**Specification**:
- Success: 200 with updated booking object (requires authentication)
- Unauthorized: 401 with error message

**Test Coverage**:
- ✅ Successfully update entire booking information (with authentication)
- ✅ Prevent unauthorized access when updating booking (401 error)

---

### 5. Partial Update Booking - `PATCH /booking/{id}`
**Specification**:
- Success: 200 with updated booking object (requires authentication)
- Unauthorized: 401 with error message
- Can update: depositpaid, firstname, lastname

**Test Coverage**:
- ✅ Successfully partially update booking firstname
- ✅ Successfully partially update booking lastname
- ✅ Successfully partially update multiple booking fields
- ✅ Prevent unauthorized access when partially updating booking (401 error)

---

### 6. Delete Booking - `DELETE /booking/{id}`
**Specification**:
- Success: 201 (requires authentication)
- Unauthorized: 401 with error message

**Test Coverage**:
- ✅ Successfully delete an existing booking (with authentication)
- ✅ Prevent unauthorized access when deleting booking (401 error)

---

## Test Case Summary

| Endpoint | Method | Success Cases | Error Cases | Total |
|----------|--------|---------------|-------------|-------|
| Health Check | GET | 1 | 0 | 1 |
| Create Booking | POST | 1 | 5 | 6 |
| Get Booking | GET | 1 | 1 | 2 |
| Update Booking | PUT | 1 | 1 | 2 |
| Partial Update | PATCH | 3 | 1 | 4 |
| Delete Booking | DELETE | 1 | 1 | 2 |
| **TOTAL** | | **8** | **9** | **17** |

---

## Test Categories

### Sanity Tests (`@sanity`)
- Health check
- Create booking (basic)
- Get booking
- Update booking
- Partial update (firstname)
- Delete booking

**Total**: 6 scenarios

### Regression Tests (`@regression`)
- All scenarios including validation and error cases

**Total**: 17 scenarios

---

## Validation Test Coverage

Based on specification examples:

1. ✅ **Firstname validation**: Too short (2 chars) and too long (19 chars)
2. ✅ **Lastname validation**: Too short (2 chars) and too long (19 chars)
3. ✅ **Email validation**: Invalid format (missing @, missing domain)
4. ✅ **Phone validation**: Too short (10 digits) and too long (22 digits)
5. ✅ **Date validation**: Checkout before checkin

---

## Authentication Test Coverage

All protected endpoints (GET, PUT, PATCH, DELETE) are tested for:
- ✅ Success with valid authentication token
- ✅ Failure with 401 Unauthorized when token is missing

---

## Required Fields Coverage

Based on specification schema, all required fields are tested:
- ✅ roomid (integer)
- ✅ firstname (string, 3-18 chars)
- ✅ lastname (string, 3-18 chars)
- ✅ depositpaid (boolean)
- ✅ bookingdates (object with checkin/checkout)
- ✅ email (string, email format)
- ✅ phone (string, 11-21 chars)

---

## What's NOT Included (Intentionally)

The following are **not** in the specification, so they're excluded:

- ❌ Boundary value testing beyond spec examples
- ❌ Multiple data combinations (only essential cases)
- ❌ Security testing (SQL injection, XSS) - not in spec
- ❌ Edge cases not mentioned in spec
- ❌ Performance testing
- ❌ Load testing

---

## Alignment with Specification

✅ **All endpoints** from spec are covered  
✅ **All response codes** (200, 201, 400, 401) are tested  
✅ **All validation errors** mentioned in spec examples are tested  
✅ **All authentication requirements** are verified  
✅ **All required fields** are validated  

This focused test suite ensures **100% coverage** of the API specification while maintaining **clarity and maintainability**.

