# Test Suites Documentation

This document describes how to identify and execute sanity and regression tests using tags in the feature files.

## Test Suite Identification

Tests are identified using **tags** (`@sanity` and `@regression`) in the feature files. No separate feature files are created - all tests are in the existing feature files with appropriate tags.

### Tag Strategy

- **`@sanity`**: Critical path tests for quick validation (~9 scenarios)
- **`@regression`**: Comprehensive test coverage (~100+ scenarios)
- **Both tags**: Tests that are part of both suites (critical tests that should run in both)

---

## Sanity Test Suite

**Purpose**: Quick validation of critical functionality after deployment  
**Execution Time**: ~2-3 minutes  
**Test Count**: ~9 scenarios  
**When to Run**: After every deployment, before major releases

### Sanity Test Scenarios (Tagged with `@sanity`)

#### Booking API (`booking.feature`)
1. ✅ **Health check** - `@sanity @regression @health @positive @critical`
2. ✅ **Create booking** - `@sanity @regression @create @positive` (first example only)
3. ✅ **Read booking** - `@sanity @regression @read @positive` (first example only)
4. ✅ **Update booking** - `@sanity @regression @update @positive` (first example only)
5. ✅ **Partial update** - `@sanity @regression @update @partial @positive` (first example only)
6. ✅ **Delete booking** - `@sanity @regression @delete @positive`
7. ✅ **Invalid email validation** - `@sanity @regression @create @validation @negative` (first example only)

#### Authentication API (`auth.feature`)
8. ✅ **Login with valid credentials** - `@sanity @regression @login @positive @critical`

#### Messages API (`messages.feature`)
9. ✅ **Get messages** - `@sanity @regression @message @positive @critical`

---

## Regression Test Suite

**Purpose**: Comprehensive test coverage to verify all functionality  
**Execution Time**: ~15-20 minutes  
**Test Count**: ~100+ scenarios  
**When to Run**: Before major releases, after significant changes, weekly regression runs

### Regression Test Scenarios (Tagged with `@regression`)

#### Booking API (`booking.feature`)
- ✅ All create operations with multiple data combinations
- ✅ Boundary value testing (names, dates)
- ✅ All validation scenarios (firstname, lastname, email, phone, dates, missing fields)
- ✅ All read operations with multiple examples
- ✅ All update operations (full and partial)
- ✅ All delete operations
- ✅ Unauthorized access scenarios
- ✅ Health check

#### Authentication API (`auth.feature`)
- ✅ Login with valid credentials (all examples)
- ✅ Invalid credentials (all examples)
- ✅ Boundary value testing
- ✅ SQL injection attempts
- ✅ XSS attempts

#### Messages API (`messages.feature`)
- ✅ Get messages (all examples)
- ✅ Message structure validation

---

## Execution Commands

### Run Sanity Tests Only
```bash
mvn test -Dcucumber.filter.tags="@sanity"
```

### Run Regression Tests Only
```bash
mvn test -Dcucumber.filter.tags="@regression"
```

### Run All Tests
```bash
mvn test
```

### Run Specific Feature with Sanity
```bash
# Sanity tests for booking only
mvn test -Dcucumber.filter.tags="@sanity and @booking"

# Sanity tests for authentication only
mvn test -Dcucumber.filter.tags="@sanity and @auth"
```

### Run Specific Feature with Regression
```bash
# Regression tests for booking only
mvn test -Dcucumber.filter.tags="@regression and @booking"

# Regression tests for authentication only
mvn test -Dcucumber.filter.tags="@regression and @auth"
```

### Run Critical Tests (Both Sanity and Regression)
```bash
mvn test -Dcucumber.filter.tags="@critical"
```

### Run Positive Tests Only
```bash
mvn test -Dcucumber.filter.tags="@positive"
```

### Run Negative Tests Only
```bash
mvn test -Dcucumber.filter.tags="@negative"
```

### Run Security Tests
```bash
mvn test -Dcucumber.filter.tags="@security"
```

### Exclude Tags
```bash
# All tests except regression
mvn test -Dcucumber.filter.tags="not @regression"

# All tests except negative
mvn test -Dcucumber.filter.tags="not @negative"
```

---

## Test Tags Reference

### Suite Tags
- `@sanity` - Sanity test suite (critical path)
- `@regression` - Regression test suite (comprehensive)

### Feature Tags
- `@booking` - Booking API tests
- `@auth` - Authentication API tests
- `@message` - Messages API tests

### Operation Tags
- `@create` - Create operations
- `@read` - Read operations
- `@update` - Update operations
- `@delete` - Delete operations
- `@partial` - Partial update operations

### Test Type Tags
- `@positive` - Positive test scenarios
- `@negative` - Negative test scenarios
- `@validation` - Validation test scenarios
- `@boundary` - Boundary value tests
- `@unauthorized` - Unauthorized access tests
- `@security` - Security tests
- `@critical` - Critical path tests

### Special Tags
- `@sql_injection` - SQL injection test scenarios
- `@xss` - XSS attack test scenarios
- `@health` - Health check tests
- `@dates` - Date-related tests

---

## Test Suite Comparison

| Aspect | Sanity Suite | Regression Suite |
|--------|-------------|------------------|
| **Purpose** | Quick validation | Comprehensive coverage |
| **Execution Time** | 2-3 minutes | 15-20 minutes |
| **Test Count** | ~9 scenarios | ~100+ scenarios |
| **Coverage** | Critical path only | All features + edge cases |
| **When to Run** | After deployment | Before releases, weekly |
| **Includes** | Basic happy paths | Positive, negative, boundary, security |
| **Tag** | `@sanity` | `@regression` |

---

## CI/CD Integration

### Recommended Test Execution Strategy

1. **Pre-commit/Pre-push**: Run sanity tests
   ```bash
   mvn test -Dcucumber.filter.tags="@sanity"
   ```

2. **Pull Request**: Run sanity + critical regression tests
   ```bash
   mvn test -Dcucumber.filter.tags="@sanity or (@regression and @critical)"
   ```

3. **Nightly Build**: Run full regression suite
   ```bash
   mvn test -Dcucumber.filter.tags="@regression"
   ```

4. **Release Build**: Run all tests
   ```bash
   mvn test
   ```

---

## Test Reports

After execution, test reports are generated in:
- **HTML Report**: `target/cucumber-reports.html`
- **JSON Report**: `target/cucumber.json`

View HTML report:
```bash
open target/cucumber-reports.html
```

---

## How Tags Work

### Scenario-Level Tags
Tags are applied at the scenario level. For example:
```gherkin
@sanity @regression @create @positive
Scenario Outline: Create booking with valid data combinations
```

### Example-Level Selection
For scenario outlines with multiple examples:
- **Sanity**: First example only (marked in comments)
- **Regression**: All examples

### Multiple Tags
Scenarios can have multiple tags:
- `@sanity @regression` - Runs in both suites
- `@sanity` only - Runs only in sanity suite
- `@regression` only - Runs only in regression suite

---

## Maintenance

### Adding New Tests

1. **Sanity Tests**: Add `@sanity` tag to critical path scenarios
2. **Regression Tests**: Add `@regression` tag to comprehensive scenarios
3. **Both**: Add both `@sanity @regression` tags if test should run in both suites

### Best Practices

- Keep sanity tests minimal and fast (~10% of total tests)
- Ensure regression tests are comprehensive (~90% of total tests)
- Use scenario outlines for data-driven tests
- Tag tests appropriately for easy filtering
- Document any special test requirements in comments
