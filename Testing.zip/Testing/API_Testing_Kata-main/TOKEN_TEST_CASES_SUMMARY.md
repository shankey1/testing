# Token Test Cases Summary

## Overview

Comprehensive test cases have been added for token-related scenarios covering:
- Invalid tokens
- Expired tokens
- Empty tokens
- Malformed tokens
- Valid tokens (for comparison)
- Edge cases

---

## Test Coverage

### 1. GET Operations with Token Scenarios

✅ **Invalid Token**
- Scenario: `Prevent access when using invalid token to retrieve booking`
- Step: `I try to get booking with id {int} using invalid token`

✅ **Expired Token**
- Scenario: `Prevent access when using expired token to retrieve booking`
- Step: `I try to get booking with id {int} using expired token`

✅ **Empty Token**
- Scenario: `Prevent access when using empty token to retrieve booking`
- Step: `I try to get booking with id {int} using empty token`

✅ **Malformed Token**
- Scenario: `Prevent access when using malformed token to retrieve booking`
- Step: `I try to get booking with id {int} using malformed token`

✅ **Various Invalid Token Types** (Scenario Outline)
- Plain invalid token
- Expired token
- Wrong token format
- Empty string token
- Whitespace token
- Null token
- Token with special characters
- Very long token
- Numeric token
- Alphanumeric invalid token

✅ **Valid Token** (Positive Test)
- Scenario: `Successfully retrieve booking with valid token`
- Step: `I get booking with id {int} using valid token`

---

### 2. UPDATE Operations (PUT) with Token Scenarios

✅ **Invalid Token**
- Scenario: `Prevent access when using invalid token to update booking`
- Step: `I try to update booking with id {int} using invalid token`

✅ **Expired Token**
- Scenario: `Prevent access when using expired token to update booking`
- Step: `I try to update booking with id {int} using expired token`

✅ **Various Invalid Token Types** (Scenario Outline)
- Invalid token
- Expired token
- Empty token
- Whitespace token

✅ **Valid Token** (Positive Test)
- Scenario: `Successfully update booking with valid token`
- Step: `I update booking with id {int} using valid token`

---

### 3. PARTIAL UPDATE Operations (PATCH) with Token Scenarios

✅ **Invalid Token**
- Scenario: `Prevent access when using invalid token to partially update booking`
- Step: `I try to partially update booking with id {int} using invalid token`

✅ **Expired Token**
- Scenario: `Prevent access when using expired token to partially update booking`
- Step: `I try to partially update booking with id {int} using expired token`

✅ **Various Invalid Token Types** (Scenario Outline)
- Invalid token
- Expired token
- Empty token
- Whitespace token

✅ **Valid Token** (Positive Test)
- Scenario: `Successfully partially update booking with valid token`
- Step: `I partially update booking firstname to {string} with id {int} using valid token`

---

### 4. DELETE Operations with Token Scenarios

✅ **Invalid Token**
- Scenario: `Prevent access when using invalid token to delete booking`
- Step: `I try to delete booking with id {int} using invalid token`

✅ **Expired Token**
- Scenario: `Prevent access when using expired token to delete booking`
- Step: `I try to delete booking with id {int} using expired token`

✅ **Various Invalid Token Types** (Scenario Outline)
- Invalid token
- Expired token
- Empty token
- Whitespace token

✅ **Valid Token** (Positive Test)
- Scenario: `Successfully delete booking with valid token`
- Step: `I delete booking with id {int} using valid token`

---

### 5. Comprehensive Token Testing

✅ **Token Validation Matrix** (Scenario Outline)
Tests all CRUD operations with different token types:
- GET with valid/invalid/expired/empty tokens
- UPDATE with valid/invalid/expired tokens
- PATCH with valid/invalid/expired tokens
- DELETE with valid/invalid/expired tokens

---

### 6. Edge Cases

✅ **Special Characters Token**
- Scenario: `Test token with only special characters`
- Token: `!@#$%^&*()`

✅ **Unicode Characters Token**
- Scenario: `Test token with unicode characters`
- Token: `token_测试_123`

✅ **JWT-like Invalid Token**
- Scenario: `Test token that looks like JWT but is invalid`
- Token: `eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.invalid.signature`

---

## Step Definitions Added

### Token Type Steps

1. **Invalid Token**
   - `I try to get booking with id {int} using invalid token`
   - `I try to update booking with id {int} using invalid token`
   - `I try to partially update booking with id {int} using invalid token`
   - `I try to delete booking with id {int} using invalid token`

2. **Expired Token**
   - `I try to get booking with id {int} using expired token`
   - `I try to update booking with id {int} using expired token`
   - `I try to partially update booking with id {int} using expired token`
   - `I try to delete booking with id {int} using expired token`

3. **Empty Token**
   - `I try to get booking with id {int} using empty token`

4. **Malformed Token**
   - `I try to get booking with id {int} using malformed token`

5. **Generic Token** (for Scenario Outlines)
   - `I try to get booking with id {int} using token {string}`
   - `I try to update booking with id {int} using token {string}`
   - `I try to partially update booking with id {int} using token {string}`
   - `I try to delete booking with id {int} using token {string}`

6. **Valid Token** (Positive Tests)
   - `I get booking with id {int} using valid token`
   - `I update booking with id {int} using valid token`
   - `I partially update booking firstname to {string} with id {int} using valid token`
   - `I delete booking with id {int} using valid token`

7. **Comprehensive Operation**
   - `I perform {string} on booking with id {int} using token {string}`

### Validation Steps

- `the request should succeed with valid token`
- `I should receive {string}` (handles "success" and "unauthorized")

---

## Token String Conversion

The step definitions include a helper method `convertTokenString()` that handles special token values:

| Feature File Value | Actual Token Value |
|-------------------|-------------------|
| `valid_token` | Gets valid token from AuthClient |
| `invalid_token` | `"invalid_token_12345"` |
| `expired_token` | `"expired_token"` |
| `empty_string` | `""` (empty string) |
| `whitespace_token` | `" "` (single space) |
| `null` | `null` (no token) |
| Any other string | Used as-is |

---

## Feature File

**Location**: `src/test/resources/features/invalid_token.feature`

**Tags**:
- `@token` - All token-related tests
- `@authentication` - Authentication tests
- `@security` - Security tests
- `@negative` - Negative test cases
- `@positive` - Positive test cases
- `@unauthorized` - Unauthorized access tests
- `@comprehensive` - Comprehensive test scenarios
- `@edge_case` - Edge case tests

---

## Test Execution

### Run All Token Tests
```bash
mvn test -Dcucumber.filter.tags="@token"
```

### Run Only Invalid Token Tests
```bash
mvn test -Dcucumber.filter.tags="@token and @negative"
```

### Run Only Positive Token Tests
```bash
mvn test -Dcucumber.filter.tags="@token and @positive"
```

### Run Comprehensive Token Tests
```bash
mvn test -Dcucumber.filter.tags="@token and @comprehensive"
```

---

## Summary

✅ **Total Scenarios Added**: 30+ scenarios
✅ **Operations Covered**: GET, PUT, PATCH, DELETE
✅ **Token Types Tested**: 
   - Invalid tokens
   - Expired tokens
   - Empty tokens
   - Malformed tokens
   - Valid tokens
   - Edge cases

✅ **Step Definitions Added**: 20+ new step definitions
✅ **Feature File**: Comprehensive `invalid_token.feature` with all scenarios

All test cases are ready to execute and will validate proper authentication handling across all booking operations!

