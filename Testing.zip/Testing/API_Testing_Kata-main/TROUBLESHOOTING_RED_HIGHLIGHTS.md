# Troubleshooting Red Highlights in Feature Files and Step Definitions

## Why Red Highlights Appear

Red highlights in Cucumber feature files and step definitions typically indicate one of these issues:

### 1. **Missing Step Definitions** (Most Common)
- **Feature File**: Step text doesn't match any `@Given`, `@When`, or `@Then` annotation
- **Step Definition**: Method exists but the regex pattern doesn't match any feature file steps

### 2. **IDE/Plugin Issues**
- Cucumber plugin not properly configured
- IDE hasn't indexed the step definitions
- Plugin cache needs refresh

### 3. **Compilation Errors**
- Java code has syntax errors
- Missing dependencies
- Classpath issues

### 4. **Pattern Mismatch**
- Step text in feature file doesn't exactly match the regex in step definition
- Parameter types don't match (e.g., `{int}` vs `{string}`)

---

## Common Causes and Solutions

### Issue 1: Step Definition Not Found

**Symptom**: Red highlight in feature file on a step line

**Example**:
```gherkin
When I create a booking  # ← Red highlight
```

**Possible Causes**:
1. Step definition doesn't exist
2. Pattern doesn't match exactly
3. Step definition in wrong package

**Solution**:
1. Check if step definition exists:
   ```java
   @When("I create a booking")
   public void iCreateABooking() { ... }
   ```

2. Verify exact text match (case-sensitive, spaces matter)

3. Check package structure:
   - Step definitions should be in `com.booking.stepdefinitions`
   - TestRunner should scan this package

---

### Issue 2: Unused Step Definition

**Symptom**: Red highlight in step definition file on method

**Example**:
```java
@When("I do something that doesn't exist")  // ← Red highlight
public void iDoSomething() { ... }
```

**Possible Causes**:
1. Step is not used in any feature file
2. Step text in feature file doesn't match

**Solution**:
1. Either use the step in a feature file, OR
2. Remove the unused step definition

**Note**: This is often just a warning, not an error. The code will still compile.

---

### Issue 3: Pattern Mismatch

**Symptom**: Step exists but still shows red

**Example**:
```gherkin
Given I have a booking with room id 5  # ← Red highlight
```

**Step Definition**:
```java
@Given("I have a booking with room id {int}")  // Should match
```

**Possible Causes**:
1. Extra spaces in feature file
2. Parameter type mismatch
3. Special characters not escaped

**Solution**:
1. Check for exact spacing match
2. Verify parameter types: `{int}`, `{string}`, `{float}`
3. Escape special regex characters if needed

---

### Issue 4: IDE Plugin Not Configured

**Symptom**: All steps show red, but code compiles and runs fine

**Possible Causes**:
1. Cucumber plugin not installed
2. Plugin not configured for project
3. Plugin cache corrupted

**Solution**:

#### For IntelliJ IDEA:
1. **Install Cucumber Plugin**:
   - File → Settings → Plugins
   - Search "Cucumber for Java"
   - Install and restart

2. **Configure Cucumber**:
   - File → Settings → Tools → Cucumber
   - Set Glue code location: `com.booking`
   - Set Feature files location: `src/test/resources/features`

3. **Refresh Project**:
   - File → Invalidate Caches / Restart
   - Select "Invalidate and Restart"

4. **Re-index Project**:
   - File → Reload Project from Disk

#### For VS Code:
1. Install "Cucumber (Gherkin) Full Support" extension
2. Install "Cucumber for Java" extension
3. Reload window: `Cmd+Shift+P` → "Reload Window"

#### For Eclipse:
1. Install "Cucumber Eclipse Plugin"
2. Right-click project → Configure → Convert to Cucumber Project
3. Refresh project

---

### Issue 5: Classpath/Compilation Issues

**Symptom**: Red highlights with compilation errors

**Possible Causes**:
1. Missing dependencies in `pom.xml`
2. Java version mismatch
3. Maven not synced

**Solution**:
1. **Sync Maven**:
   ```bash
   mvn clean install
   ```

2. **Refresh Maven Project** (IntelliJ):
   - Right-click `pom.xml` → Maven → Reload Project

3. **Check Dependencies**:
   - Verify Cucumber dependencies in `pom.xml`
   - Verify Java version matches (should be 17)

4. **Rebuild Project**:
   - Build → Rebuild Project

---

## Step-by-Step Troubleshooting Guide

### Step 1: Verify Step Definition Exists

**Check if step definition exists**:
```bash
# Search for the step definition
grep -r "I create a booking" src/test/java/com/booking/stepdefinitions/
```

**Expected Output**:
```
BookingStepDefinitions.java:@When("I create a booking")
```

### Step 2: Verify Exact Text Match

**Feature File**:
```gherkin
When I create a booking
```

**Step Definition** (must match exactly):
```java
@When("I create a booking")  // ✅ Matches
// NOT: @When("I create booking")  // ❌ Missing "a"
// NOT: @When("I create a Booking")  // ❌ Wrong case
```

### Step 3: Check Package Structure

**Verify TestRunner scans correct package**:
```java
@SelectPackages("com.booking")  // Should include stepdefinitions
@ConfigurationParameter(key = GLUE_PROPERTY_NAME, value = "com.booking")
```

**Verify step definitions are in correct package**:
```java
package com.booking.stepdefinitions;  // ✅ Correct
// NOT: package com.booking;  // ❌ Wrong
```

### Step 4: Verify Feature File Location

**Feature files should be in**:
```
src/test/resources/features/
```

**TestRunner should reference**:
```java
@SelectClasspathResource("features")
```

### Step 5: Run Tests to Verify

**If tests run successfully**, the red highlights are likely just IDE issues:

```bash
mvn test
```

**If tests fail with "Undefined step"**, then step definition is actually missing.

---

## Common Pattern Issues

### Issue: Parameter Type Mismatch

**Feature File**:
```gherkin
Given I have a booking with room id 5
```

**Wrong Step Definition**:
```java
@Given("I have a booking with room id {string}")  // ❌ Wrong type
```

**Correct Step Definition**:
```java
@Given("I have a booking with room id {int}")  // ✅ Correct
```

### Issue: Optional Parameters

**Feature File**:
```gherkin
Given I have a booking with firstname "John"
```

**Step Definition** (if parameter is optional):
```java
@Given("I have a booking with firstname {string}( and lastname {string})?")
// Use regex for optional parameters
```

### Issue: Special Characters

**Feature File**:
```gherkin
Given I have a booking with checkin "2025-01-15" and checkout "2025-01-20"
```

**Step Definition**:
```java
@Given("I have a booking with checkin {string} and checkout {string}")
// Special characters like "-" are fine in {string}
```

---

## Quick Fix Checklist

### For Feature File Red Highlights:

- [ ] Check if step definition exists in stepdefinitions package
- [ ] Verify exact text match (case, spaces, punctuation)
- [ ] Check parameter types match (`{int}`, `{string}`, etc.)
- [ ] Verify TestRunner scans correct package
- [ ] Refresh IDE cache (Invalidate Caches / Restart)
- [ ] Rebuild project
- [ ] Run tests to verify (if tests pass, it's just IDE issue)

### For Step Definition Red Highlights:

- [ ] Check if step is used in any feature file
- [ ] Verify step text matches feature file exactly
- [ ] Check for typos in annotation text
- [ ] Verify method compiles without errors
- [ ] Check if step is in correct package

---

## IDE-Specific Solutions

### IntelliJ IDEA

1. **Enable Cucumber Support**:
   - Right-click feature file → "Mark Directory as" → "Test Resources Root"
   - File → Settings → Languages & Frameworks → Cucumber
   - Set Glue: `com.booking`

2. **Refresh Cucumber Steps**:
   - Right-click feature file → "Run 'Cucumber'"
   - Or: Tools → Cucumber → Refresh Steps

3. **Invalidate Caches**:
   - File → Invalidate Caches / Restart
   - Select "Invalidate and Restart"

### VS Code

1. **Install Extensions**:
   - Cucumber (Gherkin) Full Support
   - Cucumber for Java

2. **Configure Settings**:
   ```json
   {
     "cucumber.glue": ["com.booking.stepdefinitions"],
     "cucumber.features": ["src/test/resources/features"]
   }
   ```

3. **Reload Window**:
   - `Cmd+Shift+P` → "Developer: Reload Window"

---

## Verification Steps

### 1. Check Step Definition Mapping

**Run this command to see all step definitions**:
```bash
grep -r "@Given\|@When\|@Then" src/test/java/com/booking/stepdefinitions/
```

**Expected**: Should see all your step definitions listed

### 2. Check Feature File Steps

**Run this to see all steps used**:
```bash
grep -E "^\s*(Given|When|Then|And|But)" src/test/resources/features/*.feature
```

**Expected**: Should see all steps from feature files

### 3. Run Tests

**If tests pass, red highlights are IDE issues**:
```bash
mvn test -Dcucumber.filter.tags="@sanity"
```

**If tests fail with "Undefined step"**, step definition is actually missing.

---

## Summary

**Red highlights usually mean**:
1. ✅ **IDE Issue** (most common) - Plugin needs refresh, cache needs clearing
2. ✅ **Step Definition Missing** - Need to create the step definition
3. ✅ **Pattern Mismatch** - Text doesn't match exactly
4. ✅ **Compilation Error** - Java code has errors

**Quick Fix**:
1. Refresh IDE cache
2. Rebuild project
3. Run tests to verify
4. If tests pass → It's just IDE, ignore red highlights
5. If tests fail → Fix the actual issue

**Remember**: Red highlights in IDE don't always mean there's a real problem. If your tests run successfully, the code is correct and it's just an IDE display issue!

