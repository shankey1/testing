package com.booking.api;

import com.booking.config.Config;
import com.booking.models.AuthRequest;
import com.booking.models.AuthResponse;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

import static io.restassured.RestAssured.given;

/**
 * API Client for authentication endpoints
 */
public class AuthClient {
    
    /**
     * Authenticate and get token
     * @param username Username for authentication
     * @param password Password for authentication
     * @return AuthResponse containing the token
     */
    public AuthResponse login(String username, String password) {
        AuthRequest authRequest = new AuthRequest(username, password);
        
        Response response = given()
                .contentType(ContentType.JSON)
                .body(authRequest)
                .when()
                .post(Config.AUTH_ENDPOINT)
                .then()
                .extract()
                .response();
        
        return response.as(AuthResponse.class);
    }
    
    /**
     * Authenticate with default credentials
     * @return AuthResponse containing the token
     */
    public AuthResponse login() {
        return login(Config.USERNAME, Config.PASSWORD);
    }
    
    /**
     * Get authentication token as string
     * @return Token string
     */
    public String getToken() {
        return login().getToken();
    }
}

