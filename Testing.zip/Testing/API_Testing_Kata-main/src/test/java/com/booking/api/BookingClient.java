package com.booking.api;

import com.booking.config.Config;
import com.booking.models.Booking;
import com.booking.models.CreateBookingResponse;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

import static io.restassured.RestAssured.given;

/**
 * API Client for booking endpoints
 * 
 * Best Practice: Response-First Design
 * - Primary methods always return Response (flexible error handling)
 * - Optional token parameter (null = no authentication)
 * - Optional helper methods for convenience in success cases
 */
public class BookingClient {
    
    // ============================================
    // PRIMARY METHODS - Always return Response
    // ============================================
    
    /**
     * Create a new booking
     * @param booking Booking object to create
     * @return Response - caller handles success/error cases
     */
    public Response createBooking(Booking booking) {
        return given()
                .contentType(ContentType.JSON)
                .body(booking)
                .when()
                .post(Config.BOOKING_ENDPOINT)
                .then()
                .extract()
                .response();
    }
    
    /**
     * Get booking by ID
     * @param bookingId Booking ID
     * @param token Authentication token:
     *              - Valid token string: authenticated request
     *              - Invalid token string: will return 401 Unauthorized
     *              - null: no authentication (for negative testing)
     * @return Response - caller handles success/error cases
     */
    public Response getBookingById(Integer bookingId, String token) {
        if (token != null) {
            return given()
                    .cookie("token", token)
                    .when()
                    .get(Config.BOOKING_ENDPOINT + "/" + bookingId)
                    .then()
                    .extract()
                    .response();
        } else {
            return given()
                    .when()
                    .get(Config.BOOKING_ENDPOINT + "/" + bookingId)
                    .then()
                    .extract()
                    .response();
        }
    }
    
    /**
     * Update entire booking (PUT)
     * @param bookingId Booking ID to update
     * @param booking Updated booking object
     * @param token Authentication token (null for no authentication)
     * @return Response - caller handles success/error cases
     */
    public Response updateBooking(Integer bookingId, Booking booking, String token) {
        if (token != null) {
            return given()
                    .contentType(ContentType.JSON)
                    .cookie("token", token)
                    .body(booking)
                    .when()
                    .put(Config.BOOKING_ENDPOINT + "/" + bookingId)
                    .then()
                    .extract()
                    .response();
        } else {
            return given()
                    .contentType(ContentType.JSON)
                    .body(booking)
                    .when()
                    .put(Config.BOOKING_ENDPOINT + "/" + bookingId)
                    .then()
                    .extract()
                    .response();
        }
    }
    
    /**
     * Partially update booking (PATCH)
     * @param bookingId Booking ID to update
     * @param booking Partial booking object with fields to update
     * @param token Authentication token (null for no authentication)
     * @return Response - caller handles success/error cases
     */
    public Response partialUpdateBooking(Integer bookingId, Booking booking, String token) {
        if (token != null) {
            return given()
                    .contentType(ContentType.JSON)
                    .cookie("token", token)
                    .body(booking)
                    .when()
                    .patch(Config.BOOKING_ENDPOINT + "/" + bookingId)
                    .then()
                    .extract()
                    .response();
        } else {
            return given()
                    .contentType(ContentType.JSON)
                    .body(booking)
                    .when()
                    .patch(Config.BOOKING_ENDPOINT + "/" + bookingId)
                    .then()
                    .extract()
                    .response();
        }
    }
    
    /**
     * Delete booking
     * @param bookingId Booking ID to delete
     * @param token Authentication token (null for no authentication)
     * @return Response - caller handles success/error cases
     */
    public Response deleteBooking(Integer bookingId, String token) {
        if (token != null) {
            return given()
                    .cookie("token", token)
                    .when()
                    .delete(Config.BOOKING_ENDPOINT + "/" + bookingId)
                    .then()
                    .extract()
                    .response();
        } else {
            return given()
                    .when()
                    .delete(Config.BOOKING_ENDPOINT + "/" + bookingId)
                    .then()
                    .extract()
                    .response();
        }
    }
    
    /**
     * Health check
     * @return Response object
     */
    public Response healthCheck() {
        return given()
                .when()
                .get(Config.HEALTH_ENDPOINT)
                .then()
                .extract()
                .response();
    }
    
    // ============================================
    // OPTIONAL: Helper methods for convenience
    // Use only when you're certain of success
    // ============================================
    
    /**
     * Helper: Create booking and return parsed response
     * Throws exception if status code is not 200
     * @param booking Booking object to create
     * @return CreateBookingResponse
     */
    public CreateBookingResponse createBookingAsObject(Booking booking) {
        Response response = createBooking(booking);
        response.then().statusCode(200);
        return response.as(CreateBookingResponse.class);
    }
    
    /**
     * Helper: Get booking as object
     * Throws exception if status code is not 200
     * @param bookingId Booking ID
     * @param token Authentication token
     * @return Booking object
     */
    public Booking getBookingByIdAsObject(Integer bookingId, String token) {
        Response response = getBookingById(bookingId, token);
        response.then().statusCode(200);
        return response.as(Booking.class);
    }
    
    /**
     * Helper: Update booking and return parsed response
     * Throws exception if status code is not 200
     * @param bookingId Booking ID
     * @param booking Updated booking
     * @param token Authentication token
     * @return Updated Booking object
     */
    public Booking updateBookingAsObject(Integer bookingId, Booking booking, String token) {
        Response response = updateBooking(bookingId, booking, token);
        response.then().statusCode(200);
        return response.as(Booking.class);
    }
    
    /**
     * Helper: Partially update booking and return parsed response
     * Throws exception if status code is not 200
     * @param bookingId Booking ID
     * @param booking Partial booking
     * @param token Authentication token
     * @return Updated Booking object
     */
    public Booking partialUpdateBookingAsObject(Integer bookingId, Booking booking, String token) {
        Response response = partialUpdateBooking(bookingId, booking, token);
        response.then().statusCode(200);
        return response.as(Booking.class);
    }
}
