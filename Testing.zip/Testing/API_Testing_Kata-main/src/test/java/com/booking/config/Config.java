package com.booking.config;

import java.io.InputStream;
import java.util.Properties;

/**
 * Configuration class that reads from application.properties file
 * Supports:
 * - Properties file configuration
 * - System property overrides
 * - Environment variable overrides
 * - Default fallback values
 */
public class Config {
    private static final Properties properties = new Properties();
    
    static {
        loadProperties();
    }
    
    /**
     * Load properties from application.properties file and system properties
     */
    private static void loadProperties() {
        // 1. Load properties from application.properties
        loadPropertiesFile("application.properties");
        
        // 2. System properties override file properties (highest priority)
        overrideWithSystemProperties();
    }
    
    /**
     * Load properties from application.properties file
     */
    private static void loadPropertiesFile(String filename) {
        try (InputStream input = Config.class.getClassLoader()
                .getResourceAsStream(filename)) {
            if (input == null) {
                // If properties file not found, use defaults
                return;
            }
            properties.load(input);
        } catch (Exception e) {
            // If error loading, use defaults
        }
    }
    
    /**
     * Override with system properties (for runtime overrides)
     */
    private static void overrideWithSystemProperties() {
        Properties systemProps = System.getProperties();
        for (String key : systemProps.stringPropertyNames()) {
            if (key.startsWith("api.") || key.startsWith("auth.")) {
                properties.setProperty(key, systemProps.getProperty(key));
            }
        }
    }
    
    /**
     * Get property with default value
     */
    private static String getProperty(String key, String defaultValue) {
        // Check system properties first (highest priority)
        String systemValue = System.getProperty(key);
        if (systemValue != null) {
            return systemValue;
        }
        
        // Check environment variables (second priority)
        String envValue = System.getenv(key.toUpperCase().replace(".", "_"));
        if (envValue != null) {
            return envValue;
        }
        
        // Check properties file (third priority)
        return properties.getProperty(key, defaultValue);
    }
    
    // ============================================================================
    // API Endpoints
    // ============================================================================
    
    public static String getBaseUrl() {
        return getProperty("api.base.url", "https://automationintesting.online");
    }
    
    public static String getApiBaseUrl() {
        return getBaseUrl() + "/api";
    }
    
    public static String getBookingEndpoint() {
        return getApiBaseUrl() + getProperty("api.booking.endpoint", "/booking");
    }
    
    public static String getAuthEndpoint() {
        return getApiBaseUrl() + getProperty("api.auth.endpoint", "/auth/login");
    }
    
    public static String getMessageEndpoint() {
        return getApiBaseUrl() + getProperty("api.message.endpoint", "/message");
    }
    
    public static String getHealthEndpoint() {
        return getBookingEndpoint() + getProperty("api.health.endpoint", "/actuator/health");
    }
    
    // ============================================================================
    // Authentication
    // ============================================================================
    
    public static String getUsername() {
        return getProperty("auth.username", "admin");
    }
    
    public static String getPassword() {
        // For security, prefer environment variable
        String envPassword = System.getenv("AUTH_PASSWORD");
        if (envPassword != null) {
            return envPassword;
        }
        return getProperty("auth.password", "password");
    }
    
    // ============================================================================
    // Legacy Constants for Backward Compatibility
    // Initialized after properties are loaded
    // ============================================================================
    public static final String BASE_URL;
    public static final String API_BASE_URL;
    public static final String BOOKING_ENDPOINT;
    public static final String AUTH_ENDPOINT;
    public static final String MESSAGE_ENDPOINT;
    public static final String HEALTH_ENDPOINT;
    public static final String USERNAME;
    public static final String PASSWORD;
    
    static {
        // Initialize constants after properties are loaded
        BASE_URL = getBaseUrl();
        API_BASE_URL = getApiBaseUrl();
        BOOKING_ENDPOINT = getBookingEndpoint();
        AUTH_ENDPOINT = getAuthEndpoint();
        MESSAGE_ENDPOINT = getMessageEndpoint();
        HEALTH_ENDPOINT = getHealthEndpoint();
        USERNAME = getUsername();
        PASSWORD = getPassword();
    }
    
    private Config() {
        // Utility class - prevent instantiation
    }
}

