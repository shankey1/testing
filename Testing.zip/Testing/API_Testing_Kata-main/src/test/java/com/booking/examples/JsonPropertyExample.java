package com.booking.examples;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Data;

/**
 * Example demonstrating why @JsonProperty is needed
 * 
 * This shows the difference between:
 * 1. Without @JsonProperty (field names must match exactly)
 * 2. With @JsonProperty (maps between different naming conventions)
 */
public class JsonPropertyExample {
    
    // ============================================================================
    // Example 1: WITHOUT @JsonProperty (field names must match)
    // ============================================================================
    
    @Data
    static class BookingWithoutAnnotation {
        // Field names MUST match JSON exactly
        private Integer roomid;      // Must be "roomid" (lowercase) to match API
        private String firstname;    // Must be "firstname" (lowercase) to match API
    }
    
    // Problem: Violates Java naming conventions (should be camelCase)
    
    // ============================================================================
    // Example 2: WITH @JsonProperty (maps between conventions)
    // ============================================================================
    
    @Data
    static class BookingWithAnnotation {
        @JsonProperty("roomid")     // Maps JSON "roomid" → Java roomId
        private Integer roomId;      // ✅ Follows Java camelCase convention
        
        @JsonProperty("firstname")   // Maps JSON "firstname" → Java firstName
        private String firstName;    // ✅ Follows Java camelCase convention
    }
    
    // Solution: Follows Java best practices while mapping to API
    
    // ============================================================================
    // Real-World Example: Your Booking API
    // ============================================================================
    
    public static void main(String[] args) throws Exception {
        ObjectMapper mapper = new ObjectMapper();
        
        // API Response (what you receive from server)
        String apiResponse = """
            {
              "roomid": 1,
              "firstname": "John",
              "lastname": "Doe",
              "depositpaid": true,
              "bookingdates": {
                "checkin": "2025-01-15",
                "checkout": "2025-01-20"
              },
              "email": "john@example.com",
              "phone": "1234567890"
            }
            """;
        
        // ========================================================================
        // Test 1: Without @JsonProperty (using exact field names)
        // ========================================================================
        System.out.println("=== Test 1: Without @JsonProperty ===");
        BookingWithoutAnnotation booking1 = mapper.readValue(apiResponse, BookingWithoutAnnotation.class);
        System.out.println("roomid: " + booking1.getRoomid());      // ✅ Works (but bad Java style)
        System.out.println("firstname: " + booking1.getFirstname()); // ✅ Works (but bad Java style)
        System.out.println();
        
        // ========================================================================
        // Test 2: With @JsonProperty (using camelCase)
        // ========================================================================
        System.out.println("=== Test 2: With @JsonProperty ===");
        BookingWithAnnotation booking2 = mapper.readValue(apiResponse, BookingWithAnnotation.class);
        System.out.println("roomId: " + booking2.getRoomId());      // ✅ Works (good Java style)
        System.out.println("firstName: " + booking2.getFirstName()); // ✅ Works (good Java style)
        System.out.println();
        
        // ========================================================================
        // Test 3: What happens if we remove @JsonProperty?
        // ========================================================================
        System.out.println("=== Test 3: What if we remove @JsonProperty? ===");
        System.out.println("If we remove @JsonProperty from roomId:");
        System.out.println("  - Jackson looks for 'roomId' in JSON");
        System.out.println("  - API provides 'roomid' (lowercase)");
        System.out.println("  - Result: roomId = null ❌ (mismatch!)");
        System.out.println();
        System.out.println("With @JsonProperty(\"roomid\"):");
        System.out.println("  - Jackson looks for 'roomid' in JSON (from annotation)");
        System.out.println("  - API provides 'roomid' (lowercase)");
        System.out.println("  - Maps to Java field 'roomId'");
        System.out.println("  - Result: roomId = 1 ✅ (mapped correctly!)");
    }
}

