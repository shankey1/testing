package com.booking.hooks;

import com.booking.utils.TestContext;
import io.cucumber.java.After;
import io.cucumber.java.Before;

/**
 * Cucumber hooks for setup and teardown operations
 */
public class Hooks {
    
    @Before
    public void setUp() {
        // Initialize test context for each scenario
        TestContext.getInstance();
    }
    
    @After
    public void tearDown() {
        // Clean up test context after each scenario
        TestContext.reset();
    }
}

