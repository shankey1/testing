package com.booking.models;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Model class representing authentication request
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class AuthRequest {
    @JsonProperty("username")
    private String username;
    
    @JsonProperty("password")
    private String password;
}

