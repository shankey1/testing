package com.booking.models;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Model class representing authentication response
 */
@Data
@NoArgsConstructor
public class AuthResponse {
    @JsonProperty("token")
    private String token;
}

