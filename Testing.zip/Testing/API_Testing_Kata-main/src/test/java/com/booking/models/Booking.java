package com.booking.models;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Model class representing a booking entity
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Booking {
    @JsonProperty("roomid")
    private Integer roomId;
    
    @JsonProperty("firstname")
    private String firstName;
    
    @JsonProperty("lastname")
    private String lastName;
    
    @JsonProperty("depositpaid")
    private Boolean depositPaid;
    
    @JsonProperty("bookingdates")
    private BookingDates bookingDates;
    
    @JsonProperty("email")
    private String email;
    
    @JsonProperty("phone")
    private String phone;
}

