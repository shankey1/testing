package com.booking.models;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Model class representing booking dates (check-in and check-out)
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class BookingDates {
    @JsonProperty("checkin")
    private String checkIn;
    
    @JsonProperty("checkout")
    private String checkOut;
}

