package com.booking.models;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Model class representing the response when creating a booking
 */
@Data
@NoArgsConstructor
public class CreateBookingResponse {
    @JsonProperty("bookingid")
    private Integer bookingId;
    
    @JsonProperty("booking")
    private Booking booking;
}

