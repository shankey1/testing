package com.booking.models;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * Model class representing error response
 */
@Data
@NoArgsConstructor
public class ErrorResponse {
    @JsonProperty("error")
    private String error;
    
    @JsonProperty("errors")
    private List<String> errors;
}

