package com.booking.stepdefinitions;

import com.booking.api.AuthClient;
import com.booking.config.Config;
import com.booking.utils.TestContext;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import io.cucumber.java.en.Then;
import io.restassured.response.Response;

import static org.hamcrest.Matchers.*;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Step definitions for authentication scenarios
 */
public class AuthStepDefinitions {
    private AuthClient authClient;
    private TestContext testContext;
    private Response response;

    public AuthStepDefinitions() {
        authClient = new AuthClient();
        testContext = TestContext.getInstance();
    }

    @Given("I am authenticated with valid credentials")
    public void iAmAuthenticatedWithValidCredentials() {
        String token = authClient.getToken();
        testContext.setAuthToken(token);
        assertNotNull(token, "Authentication token should not be null");
    }

    @When("I authenticate with username {string} and password {string}")
    public void iAuthenticateWithUsernameAndPassword(String username, String password) {
        response = io.restassured.RestAssured.given()
                .contentType(io.restassured.http.ContentType.JSON)
                .body(String.format("{\"username\":\"%s\",\"password\":\"%s\"}", username, password))
                .when()
                .post(Config.AUTH_ENDPOINT);
        testContext.setResponse(response);
    }

    @When("I authenticate with default credentials")
    public void iAuthenticateWithDefaultCredentials() {
        String token = authClient.login().getToken();
        testContext.setAuthToken(token);
    }

    @Then("I should receive an authentication token")
    public void iShouldReceiveAnAuthenticationToken() {
        response = testContext.getResponse();
        response.then()
                .statusCode(200)
                .body("token", notNullValue())
                .body("token", not(isEmptyOrNullString()));
        
        String token = response.jsonPath().getString("token");
        testContext.setAuthToken(token);
    }

    @Then("I should receive an authentication error")
    public void iShouldReceiveAnAuthenticationError() {
        response = testContext.getResponse();
        response.then()
                .statusCode(401)
                .body("error", notNullValue());
    }
}

