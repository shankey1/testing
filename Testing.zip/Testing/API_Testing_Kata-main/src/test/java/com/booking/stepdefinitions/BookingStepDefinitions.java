package com.booking.stepdefinitions;

import com.booking.api.AuthClient;
import com.booking.api.BookingClient;
import com.booking.models.Booking;
import com.booking.models.BookingDates;
import com.booking.models.CreateBookingResponse;
import com.booking.utils.BookingBuilder;
import com.booking.utils.TestContext;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import io.cucumber.java.en.Then;
import io.restassured.response.Response;

import static org.hamcrest.Matchers.*;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Step definitions for booking scenarios
 */
public class BookingStepDefinitions {
    private BookingClient bookingClient;
    private AuthClient authClient;
    private TestContext testContext;

    public BookingStepDefinitions() {
        bookingClient = new BookingClient();
        authClient = new AuthClient();
        testContext = TestContext.getInstance();
    }

    @Given("I have a valid booking")
    public void iHaveAValidBooking() {
        Booking booking = new BookingBuilder()
                .withDefaultValues()
                .build();
        testContext.setBooking(booking);
    }

    @Given("I have a booking with room id {int}")
    public void iHaveABookingWithRoomId(Integer roomId) {
        Booking booking = new BookingBuilder()
                .withDefaultValues()
                .withRoomId(roomId)
                .build();
        testContext.setBooking(booking);
    }

    @Given("I have a booking with firstname {string} and lastname {string}")
    public void iHaveABookingWithFirstnameAndLastname(String firstname, String lastname) {
        Booking booking = new BookingBuilder()
                .withDefaultValues()
                .withFirstName(firstname)
                .withLastName(lastname)
                .build();
        testContext.setBooking(booking);
    }

    @Given("I have a booking with checkin {string} and checkout {string}")
    public void iHaveABookingWithCheckinAndCheckout(String checkin, String checkout) {
        Booking booking = new BookingBuilder()
                .withDefaultValues()
                .withBookingDates(checkin, checkout)
                .build();
        testContext.setBooking(booking);
    }

    @Given("I have a booking with email {string}")
    public void iHaveABookingWithEmail(String email) {
        Booking booking = new BookingBuilder()
                .withDefaultValues()
                .withEmail(email)
                .build();
        testContext.setBooking(booking);
    }

    @Given("I have a booking with phone {string}")
    public void iHaveABookingWithPhone(String phone) {
        Booking booking = new BookingBuilder()
                .withDefaultValues()
                .withPhone(phone)
                .build();
        testContext.setBooking(booking);
    }

    @Given("I have a booking with firstname {string}, lastname {string}, email {string}, phone {string}, roomid {int}, depositpaid {string}, checkin {string}, and checkout {string}")
    public void iHaveABookingWithAllFields(String firstname, String lastname, String email, String phone, 
                                          Integer roomid, String depositpaid, String checkin, String checkout) {
        BookingBuilder builder = new BookingBuilder();
        
        if (firstname != null && !firstname.isEmpty() && !firstname.equals("null")) {
            builder.withFirstName(firstname);
        }
        if (lastname != null && !lastname.isEmpty() && !lastname.equals("null")) {
            builder.withLastName(lastname);
        }
        if (email != null && !email.isEmpty() && !email.equals("null")) {
            builder.withEmail(email);
        }
        if (phone != null && !phone.isEmpty() && !phone.equals("null")) {
            builder.withPhone(phone);
        }
        if (roomid != null && roomid > 0) {
            builder.withRoomId(roomid);
        }
        if (depositpaid != null && !depositpaid.isEmpty() && !depositpaid.equals("null")) {
            builder.withDepositPaid(Boolean.parseBoolean(depositpaid));
        }
        if (checkin != null && !checkin.isEmpty() && !checkin.equals("null") && 
            checkout != null && !checkout.isEmpty() && !checkout.equals("null")) {
            builder.withBookingDates(checkin, checkout);
        }
        
        // Set defaults for any missing required fields to avoid null pointer
        Booking booking = builder.build();
        
        // If any required field is missing, set a default value (will be validated by API)
        if (booking.getRoomId() == null) {
            booking.setRoomId(1);
        }
        if (booking.getFirstName() == null || booking.getFirstName().isEmpty()) {
            booking.setFirstName("");
        }
        if (booking.getLastName() == null || booking.getLastName().isEmpty()) {
            booking.setLastName("");
        }
        if (booking.getEmail() == null || booking.getEmail().isEmpty()) {
            booking.setEmail("");
        }
        if (booking.getPhone() == null || booking.getPhone().isEmpty()) {
            booking.setPhone("");
        }
        if (booking.getDepositPaid() == null) {
            booking.setDepositPaid(true);
        }
        if (booking.getBookingDates() == null) {
            booking.setBookingDates(new BookingDates("2025-01-15", "2025-01-20"));
        }
        
        testContext.setBooking(booking);
    }

    @Given("I have a booking with depositpaid {string}")
    public void iHaveABookingWithDepositpaid(String depositpaid) {
        Booking booking = new BookingBuilder()
                .withDefaultValues()
                .withDepositPaid(Boolean.parseBoolean(depositpaid))
                .build();
        testContext.setBooking(booking);
    }

    @When("I partially update the booking lastname to {string}")
    public void iPartiallyUpdateTheBookingLastnameTo(String lastname) {
        Integer bookingId = testContext.getBookingId();
        Booking partialUpdate = new Booking();
        partialUpdate.setLastName(lastname);
        String token = testContext.getAuthToken();
        
        if (token == null) {
            token = authClient.getToken();
            testContext.setAuthToken(token);
        }
        
        Booking updatedBooking = bookingClient.partialUpdateBookingAsObject(bookingId, partialUpdate, token);
        testContext.setBooking(updatedBooking);
    }

    @When("I partially update the booking with firstname {string} and lastname {string}")
    public void iPartiallyUpdateTheBookingWithFirstnameAndLastname(String firstname, String lastname) {
        Integer bookingId = testContext.getBookingId();
        Booking partialUpdate = new Booking();
        partialUpdate.setFirstName(firstname);
        partialUpdate.setLastName(lastname);
        String token = testContext.getAuthToken();
        
        if (token == null) {
            token = authClient.getToken();
            testContext.setAuthToken(token);
        }
        
        Booking updatedBooking = bookingClient.partialUpdateBookingAsObject(bookingId, partialUpdate, token);
        testContext.setBooking(updatedBooking);
    }

    @When("I try to get booking with id {int} without authentication")
    public void iTryToGetBookingWithIdWithoutAuthentication(Integer bookingId) {
        Response response = bookingClient.getBookingById(bookingId, null);
        testContext.setResponse(response);
    }

    @When("I try to update booking with id {int} without authentication")
    public void iTryToUpdateBookingWithIdWithoutAuthentication(Integer bookingId) {
        Booking booking = testContext.getBooking();
        if (booking == null) {
            booking = new BookingBuilder().withDefaultValues().build();
        }
        Response response = bookingClient.updateBooking(bookingId, booking, null);
        testContext.setResponse(response);
    }

    @When("I try to delete booking with id {int} without authentication")
    public void iTryToDeleteBookingWithIdWithoutAuthentication(Integer bookingId) {
        Response response = bookingClient.deleteBooking(bookingId, null);
        testContext.setResponse(response);
    }

    @Then("the booking should have roomid {int}")
    public void theBookingShouldHaveRoomid(Integer expectedRoomId) {
        Booking booking = testContext.getBooking();
        assertEquals(expectedRoomId, booking.getRoomId(), "Room ID should match");
    }

    @Then("the booking should have email {string}")
    public void theBookingShouldHaveEmail(String expectedEmail) {
        Booking booking = testContext.getBooking();
        assertEquals(expectedEmail, booking.getEmail(), "Email should match");
    }

    @Then("the booking should have phone {string}")
    public void theBookingShouldHavePhone(String expectedPhone) {
        Booking booking = testContext.getBooking();
        assertEquals(expectedPhone, booking.getPhone(), "Phone should match");
    }

    @Then("the booking should have depositpaid {string}")
    public void theBookingShouldHaveDepositpaid(String expectedDepositPaid) {
        Booking booking = testContext.getBooking();
        assertEquals(Boolean.parseBoolean(expectedDepositPaid), booking.getDepositPaid(), "Deposit paid should match");
    }

    @Then("the booking should have checkin {string} and checkout {string}")
    public void theBookingShouldHaveCheckinAndCheckout(String expectedCheckin, String expectedCheckout) {
        Booking booking = testContext.getBooking();
        assertNotNull(booking.getBookingDates(), "Booking dates should not be null");
        assertEquals(expectedCheckin, booking.getBookingDates().getCheckIn(), "Checkin date should match");
        assertEquals(expectedCheckout, booking.getBookingDates().getCheckOut(), "Checkout date should match");
    }

    @Then("the validation error should contain {string}")
    public void theValidationErrorShouldContain(String expectedError) {
        Response response = testContext.getResponse();
        response.then()
                .statusCode(400)
                .body("errors", notNullValue());
        
        java.util.List<String> errors = response.jsonPath().getList("errors");
        assertTrue(errors.toString().contains(expectedError) || 
                  errors.stream().anyMatch(e -> e.contains(expectedError)),
                  "Error message should contain: " + expectedError);
    }

    @When("I create a booking")
    public void iCreateABooking() {
        Booking booking = testContext.getBooking();
        Response response = bookingClient.createBooking(booking);
        testContext.setResponse(response);
        
        if (response.getStatusCode() == 200) {
            CreateBookingResponse createResponse = response.as(CreateBookingResponse.class);
            testContext.setCreateBookingResponse(createResponse);
            if (createResponse != null && createResponse.getBookingId() != null) {
                testContext.setBookingId(createResponse.getBookingId());
            }
        }
    }

    @When("I get the booking by id")
    public void iGetTheBookingById() {
        Integer bookingId = testContext.getBookingId();
        String token = testContext.getAuthToken();
        
        if (token == null) {
            token = authClient.getToken();
            testContext.setAuthToken(token);
        }
        
        Booking booking = bookingClient.getBookingByIdAsObject(bookingId, token);
        testContext.setBooking(booking);
    }

    @When("I update the booking")
    public void iUpdateTheBooking() {
        Integer bookingId = testContext.getBookingId();
        Booking booking = testContext.getBooking();
        String token = testContext.getAuthToken();
        
        if (token == null) {
            token = authClient.getToken();
            testContext.setAuthToken(token);
        }
        
        Booking updatedBooking = bookingClient.updateBookingAsObject(bookingId, booking, token);
        testContext.setBooking(updatedBooking);
    }

    @When("I partially update the booking firstname to {string}")
    public void iPartiallyUpdateTheBookingFirstnameTo(String firstname) {
        Integer bookingId = testContext.getBookingId();
        Booking partialUpdate = new Booking();
        partialUpdate.setFirstName(firstname);
        String token = testContext.getAuthToken();
        
        if (token == null) {
            token = authClient.getToken();
            testContext.setAuthToken(token);
        }
        
        Booking updatedBooking = bookingClient.partialUpdateBookingAsObject(bookingId, partialUpdate, token);
        testContext.setBooking(updatedBooking);
    }

    @When("I delete the booking")
    public void iDeleteTheBooking() {
        Integer bookingId = testContext.getBookingId();
        String token = testContext.getAuthToken();
        
        if (token == null) {
            token = authClient.getToken();
            testContext.setAuthToken(token);
        }
        
        Response response = bookingClient.deleteBooking(bookingId, token);
        testContext.setResponse(response);
    }

    @When("I check the health of the booking API")
    public void iCheckTheHealthOfTheBookingAPI() {
        Response response = bookingClient.healthCheck();
        testContext.setResponse(response);
    }

    @Then("the booking should be created successfully")
    public void theBookingShouldBeCreatedSuccessfully() {
        CreateBookingResponse createResponse = testContext.getCreateBookingResponse();
        assertNotNull(createResponse, "Create booking response should not be null");
        assertNotNull(createResponse.getBookingId(), "Booking ID should not be null");
        assertNotNull(createResponse.getBooking(), "Booking should not be null");
    }

    @Then("the booking should have booking id")
    public void theBookingShouldHaveBookingId() {
        CreateBookingResponse createResponse = testContext.getCreateBookingResponse();
        assertNotNull(createResponse.getBookingId(), "Booking ID should not be null");
    }

    @Then("the booking should be retrieved successfully")
    public void theBookingShouldBeRetrievedSuccessfully() {
        Booking booking = testContext.getBooking();
        assertNotNull(booking, "Booking should not be null");
        assertNotNull(booking.getFirstName(), "Firstname should not be null");
        assertNotNull(booking.getLastName(), "Lastname should not be null");
    }

    @Then("the booking should have firstname {string}")
    public void theBookingShouldHaveFirstname(String expectedFirstname) {
        Booking booking = testContext.getBooking();
        assertEquals(expectedFirstname, booking.getFirstName(), "Firstname should match");
    }

    @Then("the booking should have lastname {string}")
    public void theBookingShouldHaveLastname(String expectedLastname) {
        Booking booking = testContext.getBooking();
        assertEquals(expectedLastname, booking.getLastName(), "Lastname should match");
    }

    @Then("the booking should be updated successfully")
    public void theBookingShouldBeUpdatedSuccessfully() {
        Booking booking = testContext.getBooking();
        assertNotNull(booking, "Updated booking should not be null");
    }

    @Then("the booking should be deleted successfully")
    public void theBookingShouldBeDeletedSuccessfully() {
        Response response = testContext.getResponse();
        response.then().statusCode(201);
    }

    @Then("the health check should return status {string}")
    public void theHealthCheckShouldReturnStatus(String expectedStatus) {
        Response response = testContext.getResponse();
        response.then()
                .statusCode(200)
                .body("status", equalTo(expectedStatus));
    }

    @Then("I should receive a validation error")
    public void iShouldReceiveAValidationError() {
        Response response = testContext.getResponse();
        response.then()
                .statusCode(400)
                .body("errors", notNullValue());
    }

    @Then("I should receive an unauthorized error")
    public void iShouldReceiveAnUnauthorizedError() {
        Response response = testContext.getResponse();
        response.then()
                .statusCode(401)
                .body("error", notNullValue());
    }

    // ============================================================================
    // TOKEN-RELATED STEP DEFINITIONS
    // ============================================================================

    // GET with various token types
    @When("I try to get booking with id {int} using invalid token")
    public void iTryToGetBookingWithIdUsingInvalidToken(Integer bookingId) {
        String invalidToken = "invalid_token_12345";
        Response response = bookingClient.getBookingById(bookingId, invalidToken);
        testContext.setResponse(response);
    }

    @When("I try to get booking with id {int} using expired token")
    public void iTryToGetBookingWithIdUsingExpiredToken(Integer bookingId) {
        String expiredToken = "expired_token";
        Response response = bookingClient.getBookingById(bookingId, expiredToken);
        testContext.setResponse(response);
    }

    @When("I try to get booking with id {int} using empty token")
    public void iTryToGetBookingWithIdUsingEmptyToken(Integer bookingId) {
        String emptyToken = "";
        Response response = bookingClient.getBookingById(bookingId, emptyToken);
        testContext.setResponse(response);
    }

    @When("I try to get booking with id {int} using malformed token")
    public void iTryToGetBookingWithIdUsingMalformedToken(Integer bookingId) {
        String malformedToken = "!@#$%^&*()";
        Response response = bookingClient.getBookingById(bookingId, malformedToken);
        testContext.setResponse(response);
    }

    @When("I try to get booking with id {int} using token {string}")
    public void iTryToGetBookingWithIdUsingToken(Integer bookingId, String token) {
        // Handle special token values
        String actualToken = convertTokenString(token);
        Response response = bookingClient.getBookingById(bookingId, actualToken);
        testContext.setResponse(response);
    }

    @When("I get booking with id {int} using valid token")
    public void iGetBookingWithIdUsingValidToken(Integer bookingId) {
        String token = testContext.getAuthToken();
        if (token == null) {
            token = authClient.getToken();
            testContext.setAuthToken(token);
        }
        Booking booking = bookingClient.getBookingByIdAsObject(bookingId, token);
        testContext.setBooking(booking);
        // Also store response for validation
        Response response = bookingClient.getBookingById(bookingId, token);
        testContext.setResponse(response);
    }

    // UPDATE with various token types
    @When("I try to update booking with id {int} using invalid token")
    public void iTryToUpdateBookingWithIdUsingInvalidToken(Integer bookingId) {
        Booking booking = testContext.getBooking();
        if (booking == null) {
            booking = new BookingBuilder().withDefaultValues().build();
        }
        String invalidToken = "invalid_token";
        Response response = bookingClient.updateBooking(bookingId, booking, invalidToken);
        testContext.setResponse(response);
    }

    @When("I try to update booking with id {int} using expired token")
    public void iTryToUpdateBookingWithIdUsingExpiredToken(Integer bookingId) {
        Booking booking = testContext.getBooking();
        if (booking == null) {
            booking = new BookingBuilder().withDefaultValues().build();
        }
        String expiredToken = "expired_token";
        Response response = bookingClient.updateBooking(bookingId, booking, expiredToken);
        testContext.setResponse(response);
    }

    @When("I try to update booking with id {int} using token {string}")
    public void iTryToUpdateBookingWithIdUsingToken(Integer bookingId, String token) {
        Booking booking = testContext.getBooking();
        if (booking == null) {
            booking = new BookingBuilder().withDefaultValues().build();
        }
        String actualToken = convertTokenString(token);
        Response response = bookingClient.updateBooking(bookingId, booking, actualToken);
        testContext.setResponse(response);
    }

    @When("I update booking with id {int} using valid token")
    public void iUpdateBookingWithIdUsingValidToken(Integer bookingId) {
        Booking booking = testContext.getBooking();
        String token = testContext.getAuthToken();
        if (token == null) {
            token = authClient.getToken();
            testContext.setAuthToken(token);
        }
        Booking updatedBooking = bookingClient.updateBookingAsObject(bookingId, booking, token);
        testContext.setBooking(updatedBooking);
        // Also store response for validation
        Response response = bookingClient.updateBooking(bookingId, booking, token);
        testContext.setResponse(response);
    }

    // PATCH with various token types
    @When("I try to partially update booking with id {int} using invalid token")
    public void iTryToPartiallyUpdateBookingWithIdUsingInvalidToken(Integer bookingId) {
        Booking partialUpdate = new Booking();
        partialUpdate.setFirstName("Updated");
        String invalidToken = "invalid_token";
        Response response = bookingClient.partialUpdateBooking(bookingId, partialUpdate, invalidToken);
        testContext.setResponse(response);
    }

    @When("I try to partially update booking with id {int} using expired token")
    public void iTryToPartiallyUpdateBookingWithIdUsingExpiredToken(Integer bookingId) {
        Booking partialUpdate = new Booking();
        partialUpdate.setFirstName("Updated");
        String expiredToken = "expired_token";
        Response response = bookingClient.partialUpdateBooking(bookingId, partialUpdate, expiredToken);
        testContext.setResponse(response);
    }

    @When("I try to partially update booking with id {int} using token {string}")
    public void iTryToPartiallyUpdateBookingWithIdUsingToken(Integer bookingId, String token) {
        Booking partialUpdate = new Booking();
        partialUpdate.setFirstName("Updated");
        String actualToken = convertTokenString(token);
        Response response = bookingClient.partialUpdateBooking(bookingId, partialUpdate, actualToken);
        testContext.setResponse(response);
    }

    @When("I partially update booking firstname to {string} with id {int} using valid token")
    public void iPartiallyUpdateBookingFirstnameWithIdUsingValidToken(String firstname, Integer bookingId) {
        Booking partialUpdate = new Booking();
        partialUpdate.setFirstName(firstname);
        String token = testContext.getAuthToken();
        if (token == null) {
            token = authClient.getToken();
            testContext.setAuthToken(token);
        }
        Booking updatedBooking = bookingClient.partialUpdateBookingAsObject(bookingId, partialUpdate, token);
        testContext.setBooking(updatedBooking);
        // Also store response for validation
        Response response = bookingClient.partialUpdateBooking(bookingId, partialUpdate, token);
        testContext.setResponse(response);
    }

    // DELETE with various token types
    @When("I try to delete booking with id {int} using invalid token")
    public void iTryToDeleteBookingWithIdUsingInvalidToken(Integer bookingId) {
        String invalidToken = "invalid_token";
        Response response = bookingClient.deleteBooking(bookingId, invalidToken);
        testContext.setResponse(response);
    }

    @When("I try to delete booking with id {int} using expired token")
    public void iTryToDeleteBookingWithIdUsingExpiredToken(Integer bookingId) {
        String expiredToken = "expired_token";
        Response response = bookingClient.deleteBooking(bookingId, expiredToken);
        testContext.setResponse(response);
    }

    @When("I try to delete booking with id {int} using token {string}")
    public void iTryToDeleteBookingWithIdUsingToken(Integer bookingId, String token) {
        String actualToken = convertTokenString(token);
        Response response = bookingClient.deleteBooking(bookingId, actualToken);
        testContext.setResponse(response);
    }

    @When("I delete booking with id {int} using valid token")
    public void iDeleteBookingWithIdUsingValidToken(Integer bookingId) {
        String token = testContext.getAuthToken();
        if (token == null) {
            token = authClient.getToken();
            testContext.setAuthToken(token);
        }
        Response response = bookingClient.deleteBooking(bookingId, token);
        testContext.setResponse(response);
    }

    // Comprehensive operation method
    @When("I perform {string} on booking with id {int} using token {string}")
    public void iPerformOperationOnBookingWithIdUsingToken(String operation, Integer bookingId, String token) {
        String actualToken = convertTokenString(token);
        Response response;
        
        switch (operation.toUpperCase()) {
            case "GET":
                response = bookingClient.getBookingById(bookingId, actualToken);
                break;
            case "UPDATE":
                Booking booking = testContext.getBooking();
                if (booking == null) {
                    booking = new BookingBuilder().withDefaultValues().build();
                }
                response = bookingClient.updateBooking(bookingId, booking, actualToken);
                break;
            case "PATCH":
                Booking partialUpdate = new Booking();
                partialUpdate.setFirstName("Updated");
                response = bookingClient.partialUpdateBooking(bookingId, partialUpdate, actualToken);
                break;
            case "DELETE":
                response = bookingClient.deleteBooking(bookingId, actualToken);
                break;
            default:
                throw new IllegalArgumentException("Unknown operation: " + operation);
        }
        testContext.setResponse(response);
    }

    // Validation steps
    @Then("the request should succeed with valid token")
    public void theRequestShouldSucceedWithValidToken() {
        Response response = testContext.getResponse();
        response.then().statusCode(200);
    }

    @Then("I should receive {string}")
    public void iShouldReceiveExpectedStatus(String expectedStatus) {
        Response response = testContext.getResponse();
        
        switch (expectedStatus.toLowerCase()) {
            case "success":
                response.then().statusCode(200);
                break;
            case "unauthorized":
                response.then()
                        .statusCode(401)
                        .body("error", notNullValue());
                break;
            default:
                throw new IllegalArgumentException("Unknown expected status: " + expectedStatus);
        }
    }

    // Helper method to convert token string values
    private String convertTokenString(String token) {
        if (token == null || "null".equalsIgnoreCase(token)) {
            return null;
        } else if ("empty_string".equals(token)) {
            return "";
        } else if ("whitespace_token".equals(token)) {
            return " ";
        } else if ("valid_token".equals(token)) {
            String validToken = testContext.getAuthToken();
            if (validToken == null) {
                validToken = authClient.getToken();
                testContext.setAuthToken(validToken);
            }
            return validToken;
        } else if ("invalid_token".equals(token)) {
            return "invalid_token_12345";
        } else if ("expired_token".equals(token)) {
            return "expired_token";
        }
        return token;
    }
}

