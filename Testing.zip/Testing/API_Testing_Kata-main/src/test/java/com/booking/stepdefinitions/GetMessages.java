package com.booking.stepdefinitions;

import com.booking.config.Config;
import com.booking.utils.TestContext;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.response.Response;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;

/**
 * Step definitions for message endpoints
 */
public class MessageStepDefinitions {
    private TestContext testContext;

    public MessageStepDefinitions() {
        testContext = TestContext.getInstance();
    }

    @When("I want to read the messages")
    public void iWantToReadTheMessages() {
        Response response = given()
                .when()
                .get(Config.MESSAGE_ENDPOINT);
        testContext.setResponse(response);
    }

    @Then("I should receive all existing messages")
    public void iShouldReceiveAllExistingMessages() {
        Response response = testContext.getResponse();
        response.then()
                .statusCode(200)
                .body("messages.size()", greaterThan(0))
                .body("messages.id", everyItem(notNullValue()))
                .body("messages.name", everyItem(not(isEmptyOrNullString())))
                .body("messages.subject", everyItem(not(isEmptyOrNullString())))
                .body("messages.read", everyItem(notNullValue()));
    }
}
