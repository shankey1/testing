package com.booking.stepdefinitions;

import com.booking.api.AuthClient;
import com.booking.api.BookingClient;
import com.booking.models.Booking;
import com.booking.utils.BookingBuilder;
import com.booking.utils.TestContext;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import io.cucumber.java.en.Then;
import io.restassured.response.Response;

import static org.hamcrest.Matchers.*;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Step definitions for testing invalid token scenarios
 * Demonstrates how to use BookingClient for invalid token testing
 */
public class InvalidTokenStepDefinitions {
    private BookingClient bookingClient;
    private AuthClient authClient;
    private TestContext testContext;

    public InvalidTokenStepDefinitions() {
        bookingClient = new BookingClient();
        authClient = new AuthClient();
        testContext = TestContext.getInstance();
    }

    // ============================================
    // GET with Invalid Token
    // ============================================

    @When("I try to get booking with id {int} using invalid token")
    public void iTryToGetBookingWithIdUsingInvalidToken(Integer bookingId) {
        String invalidToken = "invalid_token_12345";
        Response response = bookingClient.getBookingById(bookingId, invalidToken);
        testContext.setResponse(response);
    }

    @When("I try to get booking with id {int} using token {string}")
    public void iTryToGetBookingWithIdUsingToken(Integer bookingId, String token) {
        // Handles both valid and invalid tokens
        Response response = bookingClient.getBookingById(bookingId, token);
        testContext.setResponse(response);
    }

    // ============================================
    // UPDATE with Invalid Token
    // ============================================

    @When("I try to update booking with id {int} using invalid token")
    public void iTryToUpdateBookingWithIdUsingInvalidToken(Integer bookingId) {
        Booking booking = testContext.getBooking();
        if (booking == null) {
            booking = new BookingBuilder().withDefaultValues().build();
        }
        
        String invalidToken = "expired_token";
        Response response = bookingClient.updateBooking(bookingId, booking, invalidToken);
        testContext.setResponse(response);
    }

    @When("I try to update booking with id {int} using token {string}")
    public void iTryToUpdateBookingWithIdUsingToken(Integer bookingId, String token) {
        Booking booking = testContext.getBooking();
        if (booking == null) {
            booking = new BookingBuilder().withDefaultValues().build();
        }
        
        Response response = bookingClient.updateBooking(bookingId, booking, token);
        testContext.setResponse(response);
    }

    // ============================================
    // PATCH with Invalid Token
    // ============================================

    @When("I try to partially update booking with id {int} using invalid token")
    public void iTryToPartiallyUpdateBookingWithIdUsingInvalidToken(Integer bookingId) {
        Booking partialUpdate = new Booking();
        partialUpdate.setFirstName("Updated");
        
        String invalidToken = "wrong_token";
        Response response = bookingClient.partialUpdateBooking(bookingId, partialUpdate, invalidToken);
        testContext.setResponse(response);
    }

    @When("I try to partially update booking with id {int} using token {string}")
    public void iTryToPartiallyUpdateBookingWithIdUsingToken(Integer bookingId, String token) {
        Booking partialUpdate = new Booking();
        partialUpdate.setFirstName("Updated");
        
        Response response = bookingClient.partialUpdateBooking(bookingId, partialUpdate, token);
        testContext.setResponse(response);
    }

    // ============================================
    // DELETE with Invalid Token
    // ============================================

    @When("I try to delete booking with id {int} using invalid token")
    public void iTryToDeleteBookingWithIdUsingInvalidToken(Integer bookingId) {
        String invalidToken = "invalid_token";
        Response response = bookingClient.deleteBooking(bookingId, invalidToken);
        testContext.setResponse(response);
    }

    @When("I try to delete booking with id {int} using token {string}")
    public void iTryToDeleteBookingWithIdUsingToken(Integer bookingId, String token) {
        Response response = bookingClient.deleteBooking(bookingId, token);
        testContext.setResponse(response);
    }

    // ============================================
    // Validation Steps
    // ============================================

    @Then("I should receive an unauthorized error")
    public void iShouldReceiveAnUnauthorizedError() {
        Response response = testContext.getResponse();
        response.then()
                .statusCode(401)
                .body("error", notNullValue());
    }

    @Then("I should receive an unauthorized error with message containing {string}")
    public void iShouldReceiveAnUnauthorizedErrorWithMessage(String expectedMessage) {
        Response response = testContext.getResponse();
        response.then()
                .statusCode(401)
                .body("error", notNullValue());
        
        String errorMessage = response.jsonPath().getString("error");
        assertTrue(errorMessage.contains(expectedMessage), 
                "Error message should contain: " + expectedMessage);
    }

    @Then("the request should succeed with valid token")
    public void theRequestShouldSucceedWithValidToken() {
        Response response = testContext.getResponse();
        response.then().statusCode(200);
    }

    // ============================================
    // Comparison: Valid vs Invalid Token
    // ============================================

    @When("I get booking with id {int} using valid token")
    public void iGetBookingWithIdUsingValidToken(Integer bookingId) {
        String validToken = authClient.getToken();
        Response response = bookingClient.getBookingById(bookingId, validToken);
        testContext.setResponse(response);
    }

    @When("I get booking with id {int} using invalid token")
    public void iGetBookingWithIdUsingInvalidToken(Integer bookingId) {
        String invalidToken = "invalid_token";
        Response response = bookingClient.getBookingById(bookingId, invalidToken);
        testContext.setResponse(response);
    }

    @Then("valid token should succeed and invalid token should fail")
    public void validTokenShouldSucceedAndInvalidTokenShouldFail() {
        // This step would be used in a scenario that tests both
        // The actual validation happens in Then steps
    }
}

