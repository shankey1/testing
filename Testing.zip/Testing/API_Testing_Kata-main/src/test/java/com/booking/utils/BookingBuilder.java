package com.booking.utils;

import com.booking.models.Booking;
import com.booking.models.BookingDates;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

/**
 * Builder pattern for creating Booking objects
 */
public class BookingBuilder {
    private Booking booking;
    
    public BookingBuilder() {
        booking = new Booking();
    }
    
    public BookingBuilder withRoomId(Integer roomId) {
        booking.setRoomId(roomId);
        return this;
    }
    
    public BookingBuilder withFirstName(String firstName) {
        booking.setFirstName(firstName);
        return this;
    }
    
    public BookingBuilder withLastName(String lastName) {
        booking.setLastName(lastName);
        return this;
    }
    
    public BookingBuilder withDepositPaid(Boolean depositPaid) {
        booking.setDepositPaid(depositPaid);
        return this;
    }
    
    public BookingBuilder withEmail(String email) {
        booking.setEmail(email);
        return this;
    }
    
    public BookingBuilder withPhone(String phone) {
        booking.setPhone(phone);
        return this;
    }
    
    public BookingBuilder withBookingDates(String checkIn, String checkOut) {
        BookingDates dates = new BookingDates(checkIn, checkOut);
        booking.setBookingDates(dates);
        return this;
    }
    
    public BookingBuilder withBookingDates(LocalDate checkIn, LocalDate checkOut) {
        DateTimeFormatter formatter = DateTimeFormatter.ISO_DATE;
        BookingDates dates = new BookingDates(
            checkIn.format(formatter),
            checkOut.format(formatter)
        );
        booking.setBookingDates(dates);
        return this;
    }
    
    public BookingBuilder withBookingDates(BookingDates dates) {
        booking.setBookingDates(dates);
        return this;
    }
    
    /**
     * Build a valid booking with default values
     */
    public BookingBuilder withDefaultValues() {
        LocalDate today = LocalDate.now();
        LocalDate tomorrow = today.plusDays(1);
        
        return withRoomId(1)
                .withFirstName("John")
                .withLastName("Doe")
                .withDepositPaid(true)
                .withEmail("john.doe@example.com")
                .withPhone("1234567890")
                .withBookingDates(today, tomorrow);
    }
    
    public Booking build() {
        return booking;
    }
}

