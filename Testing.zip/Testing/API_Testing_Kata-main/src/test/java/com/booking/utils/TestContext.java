package com.booking.utils;

import com.booking.models.Booking;
import com.booking.models.CreateBookingResponse;
import io.restassured.response.Response;

import java.util.HashMap;
import java.util.Map;

/**
 * Test context to share data between step definitions
 */
public class TestContext {
    private static final ThreadLocal<TestContext> instance = new ThreadLocal<>();
    
    private Response response;
    private String authToken;
    private Booking booking;
    private CreateBookingResponse createBookingResponse;
    private Integer bookingId;
    private Map<String, Object> contextData;
    
    private TestContext() {
        contextData = new HashMap<>();
    }
    
    public static TestContext getInstance() {
        if (instance.get() == null) {
            instance.set(new TestContext());
        }
        return instance.get();
    }
    
    public static void reset() {
        instance.remove();
    }
    
    public Response getResponse() {
        return response;
    }
    
    public void setResponse(Response response) {
        this.response = response;
    }
    
    public String getAuthToken() {
        return authToken;
    }
    
    public void setAuthToken(String authToken) {
        this.authToken = authToken;
    }
    
    public Booking getBooking() {
        return booking;
    }
    
    public void setBooking(Booking booking) {
        this.booking = booking;
    }
    
    public CreateBookingResponse getCreateBookingResponse() {
        return createBookingResponse;
    }
    
    public void setCreateBookingResponse(CreateBookingResponse createBookingResponse) {
        this.createBookingResponse = createBookingResponse;
    }
    
    public Integer getBookingId() {
        return bookingId;
    }
    
    public void setBookingId(Integer bookingId) {
        this.bookingId = bookingId;
    }
    
    public void setContextData(String key, Object value) {
        contextData.put(key, value);
    }
    
    public Object getContextData(String key) {
        return contextData.get(key);
    }
}

